package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Una pagina del visore: foto (con zoom) oppure video che parte subito

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.view.Surface;
import android.view.TextureView;
import android.widget.FrameLayout;

public class Pagina extends FrameLayout {

    public interface VideoCb { void onVideoState(Pagina p); }

    public final ZoomImageView img;
    final TextureView tex;
    Media.Item item;
    int token = 0;
    boolean fullLoaded = false;
    MediaPlayer mp;
    Surface surface;
    boolean prepared = false, playWhenReady = false, active = false;
    int vw, vh;
    static boolean muted = false;
    static VideoCb videoCb;

    public Pagina(Context c) {
        super(c);
        img = new ZoomImageView(c);
        addView(img, new LayoutParams(-1, -1));
        tex = new TextureView(c);
        tex.setAlpha(0f);
        addView(tex, new LayoutParams(-1, -1));
        tex.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                surface = new Surface(st);
                if (mp != null) try { mp.setSurface(surface); } catch (Exception ignored) { }
                fitVideo();
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { fitVideo(); }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                if (mp != null) try { mp.setSurface(null); } catch (Exception ignored) { }
                if (surface != null) surface.release();
                surface = null;
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }
        });
    }

    /** Mostra l'elemento; full=false durante lo scorrimento veloce (solo miniatura) */
    public void bind(Media.Item it, boolean full) {
        if (it == null) {
            item = null;
            releaseVideo();
            img.setImageDrawable(null);
            setVisibility(INVISIBLE);
            return;
        }
        setVisibility(VISIBLE);
        if (it != item) {
            item = it;
            fullLoaded = false;
            token++;
            releaseVideo();
            img.reset();
            img.zoomEnabled = !it.video;
            Bitmap ph = Thumbs.anyCached(it);
            if (ph != null) img.setBitmap(ph); else img.setImageDrawable(null);
            if (ph == null) {
                final int t = token;
                Thumbs.request(getContext(), it, 256, () -> {
                    if (t == token && !fullLoaded) {
                        Bitmap b = Thumbs.cached(it, 256);
                        if (b != null) img.setBitmap(b);
                    }
                });
            }
        }
        if (full && !fullLoaded) loadFull();
    }

    void loadFull() {
        fullLoaded = true;
        final Media.Item it = item;
        final int t = token;
        final Context c = getContext();
        if (it.video) {
            Thumbs.asyncBig(() -> {
                Bitmap b = Thumbs.thumbNow(c, it, 1024);
                post(() -> { if (t == token && b != null) img.setBitmap(b); });
            });
            prepareVideo();
            return;
        }
        int scr = Math.max(getResources().getDisplayMetrics().widthPixels, getResources().getDisplayMetrics().heightPixels);
        final int maxSide = Math.min(2560, scr);
        Thumbs.asyncBig(() -> {
            if (t != token) return;
            Drawable anim = null;
            Bitmap b = null;
            if ("image/gif".equals(it.mime) || "image/webp".equals(it.mime)) {
                try { anim = ImageDecoder.decodeDrawable(ImageDecoder.createSource(c.getContentResolver(), it.uri)); } catch (Exception ignored) { }
            }
            if (anim == null) b = Thumbs.full(c, it.uri, maxSide, true);
            final Bitmap fb = b;
            final Drawable fa = anim;
            post(() -> {
                if (t != token) return;
                float z = img.zoom();
                if (fa != null) {
                    img.setDrawableFit(fa);
                    if (fa instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) fa).start();
                } else if (fb != null && z <= 1.02f) img.setBitmap(fb);
                else if (fb != null) img.setBitmap(fb);
            });
        });
    }

    // ---------- Video ----------

    void prepareVideo() {
        releaseVideo();
        final Media.Item it = item;
        try {
            mp = new MediaPlayer();
            mp.setDataSource(getContext(), it.uri);
            if (surface != null) mp.setSurface(surface);
            mp.setVolume(muted ? 0 : 1, muted ? 0 : 1);
            final MediaPlayer p = mp;
            mp.setOnPreparedListener(x -> {
                if (p != mp) return;
                prepared = true;
                vw = x.getVideoWidth(); vh = x.getVideoHeight();
                fitVideo();
                if (playWhenReady || active) x.start();
                else x.seekTo(1);
                notifyState();
            });
            mp.setOnInfoListener((x, what, extra) -> {
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) tex.animate().alpha(1).setDuration(120).start();
                return false;
            });
            mp.setOnSeekCompleteListener(x -> { if (p == mp) tex.setAlpha(1f); });
            mp.setOnVideoSizeChangedListener((x, w, h) -> { vw = w; vh = h; fitVideo(); });
            mp.setOnCompletionListener(x -> notifyState());
            mp.setOnErrorListener((x, w, e) -> { notifyState(); return true; });
            mp.prepareAsync();
        } catch (Exception e) {
            mp = null;
        }
    }

    void fitVideo() {
        int w = tex.getWidth(), h = tex.getHeight();
        if (w == 0 || h == 0 || vw == 0 || vh == 0) return;
        float s = Math.min(w / (float) vw, h / (float) vh);
        Matrix mx = new Matrix();
        mx.setScale(vw * s / w, vh * s / h, w / 2f, h / 2f);
        tex.setTransform(mx);
    }

    void notifyState() { if (active && videoCb != null) videoCb.onVideoState(this); }

    public void activate() {
        active = true;
        if (item != null && item.video) {
            if (mp == null) prepareVideo();
            playWhenReady = true;
            if (prepared && mp != null && !mp.isPlaying()) {
                try { mp.start(); } catch (Exception ignored) { }
            }
        }
        notifyState();
    }

    public void deactivate() {
        active = false;
        playWhenReady = false;
        img.reset();
        if (mp != null && prepared) {
            try { if (mp.isPlaying()) mp.pause(); mp.seekTo(1); } catch (Exception ignored) { }
        }
    }

    public boolean isPlaying() { try { return mp != null && prepared && mp.isPlaying(); } catch (Exception e) { return false; } }

    public void togglePlay() {
        if (mp == null || !prepared) return;
        try {
            if (mp.isPlaying()) mp.pause();
            else mp.start();
        } catch (Exception ignored) { }
        notifyState();
    }

    public int position() { try { return mp != null && prepared ? mp.getCurrentPosition() : 0; } catch (Exception e) { return 0; } }
    public int duration() { try { return mp != null && prepared ? mp.getDuration() : (item != null ? (int) item.duration : 0); } catch (Exception e) { return 0; } }
    public void seek(int ms) { try { if (mp != null && prepared) mp.seekTo(ms); } catch (Exception ignored) { } }

    public void setMuted(boolean m) {
        muted = m;
        if (mp != null) try { mp.setVolume(m ? 0 : 1, m ? 0 : 1); } catch (Exception ignored) { }
    }

    public void pauseVideo() {
        if (mp != null && prepared) try { if (mp.isPlaying()) mp.pause(); } catch (Exception ignored) { }
    }

    public void releaseVideo() {
        prepared = false;
        playWhenReady = false;
        tex.setAlpha(0f);
        vw = vh = 0;
        if (mp != null) {
            final MediaPlayer old = mp;
            mp = null;
            try { old.reset(); old.release(); } catch (Exception ignored) { }
        }
    }
}
