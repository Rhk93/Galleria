package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Editor foto stile iPhone: Regola, Filtri, Ritaglia

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;

public class EditorActivity extends Activity {

    static final int YELLOW = 0xFFFFD60A;
    static final String[] ADJ = {"Esposizione", "Luminosità", "Contrasto", "Saturazione", "Calore", "Tinta", "Vignettatura"};
    static final String[] FIL = {"Originale", "Vivace", "Vivace caldo", "Vivace freddo", "Drammatico", "Drammatico caldo", "Drammatico freddo", "Mono", "Argento", "Noir"};
    static final String[] ASP = {"Originale", "Libero", "Quadrato", "4:3", "3:4", "16:9", "9:16"};
    static final float[] ASPV = {0, 0, 1, 4f / 3f, 3f / 4f, 16f / 9f, 9f / 16f};

    Uri uri;
    Bitmap src, small, prev;
    Overlay overlay;
    final java.util.ArrayList<Bitmap> undo = new java.util.ArrayList<>();
    boolean aiUsed = false, erasing = false, busy = false;
    float brushDp = 34;
    LinearLayout topBar;
    ImageView preview;
    SeekBar seek;
    TextView valueLbl, resetBtn;
    LinearLayout strip;
    LinearLayout tabs;
    int tab = 0, tool = 0;
    final float[] adj = new float[ADJ.length];
    int filter = 0, rot = 0, aspect = 0;
    boolean flip = false;
    float straight = 0;
    boolean showOriginal = false;
    final Handler h = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        uri = getIntent().getData();
        if (uri == null) { finish(); return; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF000000);

        LinearLayout top = new LinearLayout(this);
        topBar = top;
        top.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 14);
        top.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 10));
        TextView cancel = Ui.text(this, "Annulla", 17, 0xFFFFFFFF, false);
        cancel.setOnClickListener(v -> askCancel());
        resetBtn = Ui.text(this, "RIPRISTINA", 13, 0xFFFF453A, true);
        resetBtn.setVisibility(View.INVISIBLE);
        resetBtn.setOnClickListener(v -> resetAll());
        TextView done = Ui.text(this, "Fine", 17, YELLOW, true);
        done.setOnClickListener(v -> save());
        top.addView(cancel);
        top.addView(Ui.space(this));
        top.addView(resetBtn);
        top.addView(Ui.space(this));
        top.addView(done);
        root.addView(top);

        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setPadding(p, p, p, p);
        // tieni premuto per vedere l'originale, come su iPhone
        preview.setOnTouchListener((v, e) -> {
            if (tab == 3) return false;
            if (e.getAction() == MotionEvent.ACTION_DOWN) { showOriginal = true; refresh(); }
            else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { showOriginal = false; refresh(); }
            return true;
        });
        FrameLayout pbox = new FrameLayout(this);
        pbox.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        overlay = new Overlay(this);
        pbox.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        root.addView(pbox, new LinearLayout.LayoutParams(-1, 0, 1f));

        valueLbl = Ui.text(this, "", 13, 0xFFFFFFFF, true);
        valueLbl.setGravity(Gravity.CENTER);
        root.addView(valueLbl, new LinearLayout.LayoutParams(-1, -2));
        seek = new SeekBar(this);
        seek.setMax(200);
        seek.setPadding(Ui.dp(this, 28), Ui.dp(this, 6), Ui.dp(this, 28), Ui.dp(this, 6));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                if (!user) return;
                float val = (v - 100) / 100f;
                if (tab == 0) {
                    if (tool == 6) val = Math.max(0, val);
                    adj[tool] = val;
                } else if (tab == 2) {
                    straight = val * 45f;
                } else if (tab == 3) {
                    brushDp = 14 + (v / 200f) * 60;
                    overlay.invalidate();
                }
                updateLabel();
                refresh();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { buildStrip(); }
        });
        root.addView(seek);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        strip = new LinearLayout(this);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
        hs.addView(strip);
        root.addView(hs, new LinearLayout.LayoutParams(-1, Ui.dp(this, 112)));

        tabs = new LinearLayout(this);
        tabs.setGravity(Gravity.CENTER);
        tabs.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 16));
        String[] tn = {"Regola", "Filtri", "Ritaglia", "✨ IA"};
        for (int i = 0; i < tn.length; i++) {
            final int k = i;
            TextView t = Ui.text(this, tn[i].toUpperCase(), 13, 0xFF8E8E93, true);
            t.setPadding(Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18), Ui.dp(this, 8));
            t.setOnClickListener(v -> { tab = k; if (k != 3) { erasing = false; overlay.compare = null; } buildStrip(); refresh(); });
            tabs.addView(t);
        }
        root.addView(tabs);

        setContentView(root);
        Ui.bars(this, 0xFF000000, true);

        Thumbs.async(() -> {
            Bitmap s = Thumbs.full(this, uri, 2048);
            h.post(() -> {
                if (s == null) { Toast.makeText(this, "Impossibile aprire la foto", Toast.LENGTH_SHORT).show(); finish(); return; }
                setBase(s);
                buildStrip();
                refresh();
                enterAnim();
            });
        });
    }

    // ---------- Interfaccia ----------

    void buildStrip() {
        for (int i = 0; i < tabs.getChildCount(); i++)
            ((TextView) tabs.getChildAt(i)).setTextColor(i == tab ? YELLOW : 0xFF8E8E93);
        strip.removeAllViews();
        if (src == null) return;
        if (tab == 0) {
            for (int i = 0; i < ADJ.length; i++) {
                final int k = i;
                LinearLayout col = new LinearLayout(this);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setGravity(Gravity.CENTER_HORIZONTAL);
                col.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
                TextView circ = Ui.text(this, adj[i] == 0 ? "○" : String.valueOf(Math.round(adj[i] * 100)), 14, i == tool ? YELLOW : 0xFFFFFFFF, true);
                circ.setGravity(Gravity.CENTER);
                int s = Ui.dp(this, 52);
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                g.setStroke(Ui.dp(this, 2), i == tool ? YELLOW : (adj[i] != 0 ? 0xFFFFFFFF : 0xFF636366));
                g.setColor(0xFF1C1C1E);
                circ.setBackground(g);
                col.addView(circ, new LinearLayout.LayoutParams(s, s));
                TextView lbl = Ui.text(this, ADJ[i], 11, i == tool ? YELLOW : 0xFF8E8E93, false);
                lbl.setPadding(0, Ui.dp(this, 6), 0, 0);
                col.addView(lbl);
                col.setOnClickListener(v -> { tool = k; buildStrip(); });
                strip.addView(col);
            }
            seek.setVisibility(View.VISIBLE);
            seek.setProgress(Math.round(adj[tool] * 100) + 100);
        } else if (tab == 1) {
            for (int i = 0; i < FIL.length; i++) {
                final int k = i;
                LinearLayout col = new LinearLayout(this);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setGravity(Gravity.CENTER_HORIZONTAL);
                col.setPadding(Ui.dp(this, 5), 0, Ui.dp(this, 5), 0);
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageBitmap(applyColor(small, filterMatrix(i), 0));
                int s = Ui.dp(this, 64);
                if (i == filter) {
                    iv.setPadding(Ui.dp(this, 2), Ui.dp(this, 2), Ui.dp(this, 2), Ui.dp(this, 2));
                    iv.setBackgroundColor(YELLOW);
                }
                col.addView(iv, new LinearLayout.LayoutParams(s, s));
                TextView lbl = Ui.text(this, FIL[i], 11, i == filter ? YELLOW : 0xFF8E8E93, false);
                lbl.setPadding(0, Ui.dp(this, 6), 0, 0);
                col.addView(lbl);
                col.setOnClickListener(v -> { filter = k; buildStrip(); refresh(); });
                strip.addView(col);
            }
            seek.setVisibility(View.INVISIBLE);
        } else if (tab == 3) {
            buildAiStrip();
        } else {
            strip.addView(cropBtn("rotate", "Ruota", () -> { rot = (rot + 3) % 4; refresh(); }));
            strip.addView(cropBtn("flip", "Specchia", () -> { flip = !flip; refresh(); }));
            for (int i = 0; i < ASP.length; i++) {
                if (i == 1) continue;
                final int k = i;
                TextView t = Ui.text(this, ASP[i], 13, i == aspect ? 0xFF000000 : 0xFFFFFFFF, true);
                t.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7));
                t.setBackground(Ui.round(i == aspect ? YELLOW : 0xFF2C2C2E, Ui.dp(this, 16)));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                lp.leftMargin = Ui.dp(this, 6);
                t.setLayoutParams(lp);
                t.setOnClickListener(v -> { aspect = k; buildStrip(); refresh(); });
                strip.addView(t);
            }
            seek.setVisibility(View.VISIBLE);
            seek.setProgress(Math.round(straight / 45f * 100) + 100);
        }
        updateLabel();
    }

    View cropBtn(String icon, String label, Runnable r) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        col.addView(Ui.icon(this, icon, 0xFFFFFFFF, 30));
        TextView l = Ui.text(this, label, 11, 0xFF8E8E93, false);
        l.setPadding(0, Ui.dp(this, 6), 0, 0);
        col.addView(l);
        col.setOnClickListener(v -> r.run());
        return col;
    }

    void updateLabel() {
        if (tab == 0) valueLbl.setText(ADJ[tool].toUpperCase() + "  " + Math.round(adj[tool] * 100));
        else if (tab == 2) valueLbl.setText("RADDRIZZA  " + Math.round(straight) + "°");
        else if (tab == 3) valueLbl.setText(erasing ? "DIMENSIONE PENNELLO" : "STRUMENTI IA");
        else valueLbl.setText(FIL[filter].toUpperCase());
        resetBtn.setVisibility(changed() ? View.VISIBLE : View.INVISIBLE);
    }

    boolean changed() {
        for (float a : adj) if (a != 0) return true;
        return aiUsed || filter != 0 || rot != 0 || flip || straight != 0 || aspect != 0;
    }

    void resetAll() {
        for (int i = 0; i < adj.length; i++) adj[i] = 0;
        filter = 0; rot = 0; flip = false; straight = 0; aspect = 0;
        if (!undo.isEmpty()) { setBase(undo.get(0)); undo.clear(); }
        aiUsed = false;
        overlay.compare = null;
        buildStrip();
        refresh();
    }

    void askCancel() {
        if (!changed()) { finish(); return; }
        new AlertDialog.Builder(this).setMessage("Vuoi annullare le modifiche?")
                .setPositiveButton("Annulla modifiche", (d, w) -> finish())
                .setNegativeButton("Continua", null).show();
    }

    @Override public void onBackPressed() { askCancel(); }

    void setBase(Bitmap s) {
        src = s;
        float pc = Math.min(1f, 1100f / Math.max(s.getWidth(), s.getHeight()));
        prev = pc < 1f ? Bitmap.createScaledBitmap(s, Math.max(1, (int) (s.getWidth() * pc)), Math.max(1, (int) (s.getHeight() * pc)), true) : s;
        float sc = 160f / Math.max(s.getWidth(), s.getHeight());
        small = Bitmap.createScaledBitmap(s, Math.max(1, (int) (s.getWidth() * sc)), Math.max(1, (int) (s.getHeight() * sc)), true);
    }

    void refresh() {
        if (src == null) return;
        if (tab == 3) { preview.setImageBitmap(prev); overlay.invalidate(); return; }
        preview.setImageBitmap(showOriginal ? prev : render(prev));
    }

    /** Ingresso dell'editor: foto e barre che scivolano al loro posto, come iOS */
    void enterAnim() {
        preview.setAlpha(0f);
        preview.setScaleX(0.94f); preview.setScaleY(0.94f);
        preview.animate().alpha(1).scaleX(1).scaleY(1).setDuration(480).setInterpolator(Ui.EASE).start();
        topBar.setTranslationY(-Ui.dp(this, 60));
        topBar.animate().translationY(0).setDuration(450).setInterpolator(Ui.EASE).start();
        View[] lows = {valueLbl, seek, strip, tabs};
        for (int i = 0; i < lows.length; i++) {
            View v = lows[i];
            v.setTranslationY(Ui.dp(this, 120));
            v.setAlpha(0f);
            v.animate().translationY(0).alpha(1).setStartDelay(40L * i).setDuration(480).setInterpolator(Ui.EASE).start();
        }
    }

    // ---------- IA: Gomma magica e Rimasterizza ----------

    void buildAiStrip() {
        TextView er = aiBtn("Gomma magica", "Passa il dito su ciò che vuoi cancellare", erasing);
        er.setOnClickListener(v -> {
            erasing = !erasing;
            overlay.compare = null;
            buildStrip();
            if (erasing) {
                eMode = 0;
                buildStrip();
                segment();
                Toast.makeText(this, "Tocca un soggetto per eliminarlo, oppure disegnaci intorno", Toast.LENGTH_SHORT).show();
            }
        });
        strip.addView(er);
        if (erasing) {
            String[][] modes = {{"Automatico", "Tocca un soggetto"}, {"Contorno", "Disegna intorno"}, {"Pennello", "Passa sopra"}};
            for (int i = 0; i < modes.length; i++) {
                final int k = i;
                TextView mb = aiBtn(modes[i][0], modes[i][1], eMode == i);
                mb.setOnClickListener(v -> {
                    eMode = k;
                    buildStrip();
                    if (k == 0) segment();
                    overlay.invalidate();
                });
                strip.addView(mb);
            }
        }
        TextView rm = aiBtn("Rimasterizza", "Migliora automaticamente la foto", false);
        rm.setOnClickListener(v -> remaster());
        strip.addView(rm);
        if (!undo.isEmpty()) {
            TextView un = aiBtn("Annulla", "Torna al passo precedente", false);
            un.setOnClickListener(v -> {
                if (busy || undo.isEmpty()) return;
                setBase(undo.remove(undo.size() - 1));
                aiUsed = !undo.isEmpty();
                overlay.compare = null;
                buildStrip();
                refresh();
            });
            strip.addView(un);
        }
        seek.setVisibility(erasing && eMode == 2 ? View.VISIBLE : View.INVISIBLE);
        seek.setProgress(Math.round((brushDp - 14) / 60f * 200));
    }

    TextView aiBtn(String title, String sub, boolean on) {
        TextView t = Ui.text(this, title + "\n" + sub, 13, on ? 0xFF000000 : 0xFFFFFFFF, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxWidth(Ui.dp(this, 170));
        int p = Ui.dp(this, 14);
        t.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 10));
        t.setBackground(Ui.round(on ? YELLOW : 0xFF2C2C2E, Ui.dp(this, 16)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = Ui.dp(this, 8);
        t.setLayoutParams(lp);
        Ui.press(t);
        return t;
    }

    void pushUndo() {
        undo.add(src);
        while (undo.size() > 4) undo.remove(0);
    }

    // ---------- Gomma magica: soggetti automatici, contorno, pennello ----------

    int eMode = 0; // 0 automatico, 1 contorno, 2 pennello
    int[] labels;
    Bitmap labTint, selTint;
    boolean segRunning = false;

    /** Riconosce i soggetti della foto (ML Kit); se non disponibile si usa la selezione per colore */
    void segment() {
        labels = null; labTint = null;
        if (prev == null || segRunning) return;
        segRunning = true;
        overlay.invalidate();
        final Bitmap p = prev;
        try {
            com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions opt =
                    new com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions.Builder()
                            .enableForegroundConfidenceMask()
                            .build();
            com.google.mlkit.vision.segmentation.subject.SubjectSegmenter seg =
                    com.google.mlkit.vision.segmentation.subject.SubjectSegmentation.getClient(opt);
            seg.process(com.google.mlkit.vision.common.InputImage.fromBitmap(p, 0))
                    .addOnSuccessListener(res -> {
                        java.nio.FloatBuffer fb = res.getForegroundConfidenceMask();
                        if (fb == null || p != prev) { segRunning = false; overlay.invalidate(); return; }
                        int w = p.getWidth(), hh = p.getHeight();
                        Thumbs.async(() -> {
                            boolean[] fg = new boolean[w * hh];
                            fb.rewind();
                            for (int i = 0; i < fg.length && fb.hasRemaining(); i++) fg[i] = fb.get() > 0.5f;
                            int[] cnt = new int[1];
                            int[] lab = AI.components(fg, w, hh, cnt);
                            Bitmap t = cnt[0] > 0 ? AI.tint(null, lab, w, hh, 0, 0x66FFFFFF) : null;
                            h.post(() -> {
                                segRunning = false;
                                if (p != prev) return;
                                labels = cnt[0] > 0 ? lab : null;
                                labTint = t;
                                if (labels == null) Toast.makeText(this, "Nessun soggetto trovato: tocca un oggetto o disegnaci intorno", Toast.LENGTH_SHORT).show();
                                overlay.invalidate();
                            });
                        });
                    })
                    .addOnFailureListener(e -> { segRunning = false; overlay.invalidate(); });
        } catch (Throwable t) {
            // telefono senza Google Play Services (es. Huawei): selezione per colore al tocco
            segRunning = false;
        }
    }

    /** Tocco in modalità automatica: seleziona il soggetto o l'oggetto sotto il dito e lo elimina */
    void tapSelect(float bx, float by) {
        if (busy || prev == null) return;
        int w = prev.getWidth(), hh = prev.getHeight();
        int x = Math.round(bx), y = Math.round(by);
        if (x < 0 || y < 0 || x >= w || y >= hh) return;
        busy = true;
        overlay.processing = true;
        overlay.invalidate();
        final int[] lab = labels;
        final Bitmap p = prev;
        Thumbs.asyncBig(() -> {
            boolean[] sel = null;
            if (lab != null && lab[y * w + x] != 0) {
                int id = lab[y * w + x];
                sel = new boolean[w * hh];
                for (int i = 0; i < sel.length; i++) sel[i] = lab[i] == id;
                sel = AI.dilate(AI.fillHoles(sel, w, hh), w, hh, Math.max(3, Math.max(w, hh) / 200));
            } else {
                try { sel = AI.grow(p, x, y); } catch (Throwable ignored) { }
            }
            final boolean[] fs = sel;
            final Bitmap tint = fs == null ? null : AI.tint(fs, null, w, hh, 0xAAFFFFFF, 0);
            h.post(() -> {
                busy = false;
                overlay.processing = false;
                if (fs == null) { overlay.invalidate(); Toast.makeText(this, "Non riesco a isolare questo oggetto: prova con Contorno", Toast.LENGTH_SHORT).show(); return; }
                // l'oggetto si illumina, poi viene cancellato
                selTint = tint;
                overlay.invalidate();
                h.postDelayed(() -> runErase(() -> AI.toMask(fs, w, hh), true), 450);
            });
        });
    }

    /** Il dito ha finito il tratto (pennello o contorno): cancella la zona */
    void eraseStroke(android.graphics.Path pathPrev, float widthPrev) {
        final android.graphics.Path pp = new android.graphics.Path(pathPrev);
        final boolean lasso = eMode == 1;
        final int w = prev.getWidth(), hh = prev.getHeight();
        runErase(() -> lasso ? AI.lassoMask(pp, widthPrev, w, hh) : AI.maskFrom(pp, widthPrev, w, hh), false);
    }

    /** Esegue la cancellazione: la maschera è alla risoluzione dell'anteprima e viene portata a quella piena */
    void runErase(java.util.function.Supplier<Bitmap> maskPrev, boolean keepBusyCheck) {
        if (busy) return;
        busy = true;
        overlay.processing = true;
        overlay.invalidate();
        final Bitmap base = src;
        Thumbs.asyncBig(() -> {
            Bitmap res = null;
            try {
                Bitmap mp = maskPrev.get();
                Bitmap mask = Bitmap.createScaledBitmap(mp, base.getWidth(), base.getHeight(), true);
                res = AI.erase(base, mask);
            } catch (Throwable ignored) { }
            final Bitmap fr = res;
            h.post(() -> {
                busy = false;
                overlay.processing = false;
                selTint = null;
                overlay.clearStroke();
                if (fr == null) { Toast.makeText(this, "Non riesco a ricostruire questa zona", Toast.LENGTH_SHORT).show(); return; }
                pushUndo();
                setBase(fr);
                aiUsed = true;
                buildStrip();
                preview.setImageBitmap(prev);
                preview.setAlpha(0.6f);
                preview.animate().alpha(1).setDuration(350).start();
                if (eMode == 0) segment();
            });
        });
    }

    void remaster() {
        if (busy) return;
        busy = true;
        erasing = false;
        buildStrip();
        overlay.processing = true;
        overlay.invalidate();
        final Bitmap base = src, before = prev;
        Thumbs.asyncBig(() -> {
            Bitmap res = null;
            try { res = AI.remaster(base); } catch (Throwable ignored) { }
            final Bitmap fr = res;
            h.post(() -> {
                busy = false;
                overlay.processing = false;
                if (fr == null) { Toast.makeText(this, "Rimasterizzazione non riuscita", Toast.LENGTH_SHORT).show(); return; }
                pushUndo();
                setBase(fr);
                aiUsed = true;
                buildStrip();
                preview.setImageBitmap(prev);
                // confronto Prima / Dopo con la linea trascinabile
                overlay.compare = before;
                overlay.cmp = 0f;
                android.animation.ValueAnimator va = android.animation.ValueAnimator.ofFloat(0f, 0.5f);
                va.setDuration(700);
                va.setInterpolator(Ui.EASE);
                va.addUpdateListener(a -> { overlay.cmp = (float) a.getAnimatedValue(); overlay.invalidate(); });
                va.start();
            });
        });
    }

    /** Livello sopra la foto: pennello della gomma, luccichio durante l'elaborazione, confronto Prima/Dopo */
    class Overlay extends View {
        final android.graphics.Path stroke = new android.graphics.Path();
        boolean has = false, processing = false;
        Bitmap compare;
        float cmp = 0.5f;
        final Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG), lp = new Paint(Paint.ANTI_ALIAS_FLAG), tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        float lastX, lastY;

        Overlay(android.content.Context c) {
            super(c);
            pp.setStyle(Paint.Style.STROKE);
            pp.setStrokeCap(Paint.Cap.ROUND);
            pp.setStrokeJoin(Paint.Join.ROUND);
            lp.setColor(0xFFFFFFFF);
            lp.setStrokeWidth(Ui.dp(c, 2));
            tp.setColor(0xFFFFFFFF);
            tp.setTextSize(Ui.dp(c, 12));
            tp.setFakeBoldText(true);
        }

        android.graphics.Matrix imgMatrix() {
            android.graphics.Matrix m = new android.graphics.Matrix(preview.getImageMatrix());
            m.postTranslate(preview.getPaddingLeft(), preview.getPaddingTop());
            return m;
        }

        void clearStroke() { stroke.reset(); has = false; invalidate(); }

        @Override protected void onDraw(Canvas c) {
            if (tab != 3 || prev == null) return;
            android.graphics.Matrix m = imgMatrix();
            if (compare != null) {
                float x = getWidth() * cmp;
                c.save();
                c.clipRect(0, 0, x, getHeight());
                c.concat(m);
                float k = prev.getWidth() / (float) compare.getWidth();
                c.scale(k, k);
                c.drawBitmap(compare, 0, 0, null);
                c.restore();
                c.drawLine(x, 0, x, getHeight(), lp);
                float cy = getHeight() / 2f, r = Ui.dp(getContext(), 16);
                Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
                bg.setColor(0xFFFFFFFF);
                c.drawCircle(x, cy, r, bg);
                Paint ar = new Paint(Paint.ANTI_ALIAS_FLAG);
                ar.setColor(0xFF000000);
                ar.setTextSize(Ui.dp(getContext(), 14));
                ar.setFakeBoldText(true);
                c.drawText("‹ ›", x - ar.measureText("‹ ›") / 2f, cy + Ui.dp(getContext(), 5), ar);
                drawPill(c, "Prima", Ui.dp(getContext(), 12), Ui.dp(getContext(), 12));
                String d = "Dopo";
                drawPill(c, d, getWidth() - Ui.dp(getContext(), 12) - tp.measureText(d) - Ui.dp(getContext(), 20), Ui.dp(getContext(), 12));
            }
            if (erasing && eMode == 0 && (labTint != null || selTint != null || segRunning)) {
                c.save();
                c.concat(m);
                double tt = (System.nanoTime() / 1e9) * 3;
                Paint sp = new Paint(Paint.FILTER_BITMAP_FLAG);
                if (labTint != null && selTint == null) { sp.setAlpha((int) (150 + 80 * Math.sin(tt))); c.drawBitmap(labTint, 0, 0, sp); }
                if (selTint != null) { sp.setAlpha((int) (190 + 60 * Math.sin(tt * 2))); c.drawBitmap(selTint, 0, 0, sp); }
                c.restore();
                if (segRunning) {
                    Paint sh = new Paint();
                    sh.setColor(Color.argb((int) (30 + 25 * Math.sin(tt)), 255, 255, 255));
                    c.drawRect(0, 0, getWidth(), getHeight(), sh);
                }
                postInvalidateOnAnimation();
            }
            if (has || processing) {
                c.save();
                c.concat(m);
                float s = scaleOf(m);
                pp.setStrokeWidth(brushDp * getResources().getDisplayMetrics().density / s);
                if (processing) {
                    double t = (System.nanoTime() / 1e9) * 4;
                    pp.setColor(Color.argb((int) (120 + 90 * Math.sin(t)), 255, 255, 255));
                    postInvalidateOnAnimation();
                } else pp.setColor(0x88FFFFFF);
                c.drawPath(stroke, pp);
                c.restore();
            }
            if (processing && !has) {
                double t = (System.nanoTime() / 1e9) * 3;
                Paint sh = new Paint();
                sh.setColor(Color.argb((int) (40 + 35 * Math.sin(t)), 255, 255, 255));
                c.drawRect(0, 0, getWidth(), getHeight(), sh);
                postInvalidateOnAnimation();
            }
        }

        void drawPill(Canvas c, String s, float x, float y) {
            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(0x99000000);
            float w = tp.measureText(s) + Ui.dp(getContext(), 20), hh = Ui.dp(getContext(), 24);
            c.drawRoundRect(x, y, x + w, y + hh, hh / 2, hh / 2, bg);
            c.drawText(s, x + Ui.dp(getContext(), 10), y + hh / 2 + Ui.dp(getContext(), 4), tp);
        }

        float scaleOf(android.graphics.Matrix m) { float[] v = new float[9]; m.getValues(v); return v[0]; }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (tab != 3 || busy) return false;
            if (compare != null && !erasing) {
                cmp = Math.max(0, Math.min(1, e.getX() / getWidth()));
                invalidate();
                return true;
            }
            if (!erasing) return false;
            android.graphics.Matrix inv = new android.graphics.Matrix();
            imgMatrix().invert(inv);
            float[] pt = {e.getX(), e.getY()};
            inv.mapPoints(pt);
            if (eMode == 0) {
                if (e.getActionMasked() == MotionEvent.ACTION_UP) tapSelect(pt[0], pt[1]);
                return true;
            }
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    stroke.reset();
                    stroke.moveTo(pt[0], pt[1]);
                    lastX = pt[0]; lastY = pt[1];
                    has = true;
                    break;
                case MotionEvent.ACTION_MOVE:
                    stroke.quadTo(lastX, lastY, (pt[0] + lastX) / 2, (pt[1] + lastY) / 2);
                    lastX = pt[0]; lastY = pt[1];
                    break;
                case MotionEvent.ACTION_UP:
                    stroke.lineTo(pt[0], pt[1]);
                    float wPrev = brushDp * getResources().getDisplayMetrics().density / scaleOf(imgMatrix());
                    eraseStroke(stroke, wPrev);
                    break;
                case MotionEvent.ACTION_CANCEL:
                    clearStroke();
                    break;
            }
            invalidate();
            return true;
        }
    }

    // ---------- Elaborazione ----------

    static ColorMatrix sat(float s) { ColorMatrix m = new ColorMatrix(); m.setSaturation(s); return m; }

    static ColorMatrix con(float k) {
        float t = 128 * (1 - k);
        return new ColorMatrix(new float[]{k, 0, 0, 0, t, 0, k, 0, 0, t, 0, 0, k, 0, t, 0, 0, 0, 1, 0});
    }

    static ColorMatrix off(float r, float g, float b) {
        return new ColorMatrix(new float[]{1, 0, 0, 0, r, 0, 1, 0, 0, g, 0, 0, 1, 0, b, 0, 0, 0, 1, 0});
    }

    static ColorMatrix scale(float k) { ColorMatrix m = new ColorMatrix(); m.setScale(k, k, k, 1); return m; }

    static ColorMatrix chain(ColorMatrix... ms) {
        ColorMatrix o = new ColorMatrix();
        for (ColorMatrix m : ms) o.postConcat(m);
        return o;
    }

    static ColorMatrix filterMatrix(int i) {
        switch (i) {
            case 1: return chain(sat(1.35f), con(1.08f));
            case 2: return chain(sat(1.3f), con(1.08f), off(14, 4, -12));
            case 3: return chain(sat(1.3f), con(1.08f), off(-10, 0, 16));
            case 4: return chain(sat(0.75f), con(1.35f), off(-8, -8, -8));
            case 5: return chain(sat(0.8f), con(1.35f), off(10, -4, -18));
            case 6: return chain(sat(0.75f), con(1.35f), off(-16, -4, 12));
            case 7: return sat(0);
            case 8: return chain(sat(0), con(0.85f), off(18, 18, 18));
            case 9: return chain(sat(0), con(1.6f), off(-22, -22, -22));
            default: return new ColorMatrix();
        }
    }

    ColorMatrix adjustMatrix() {
        ColorMatrix m = filterMatrix(filter);
        if (adj[0] != 0) m.postConcat(scale((float) Math.pow(2, adj[0])));
        if (adj[1] != 0) m.postConcat(off(adj[1] * 60, adj[1] * 60, adj[1] * 60));
        if (adj[2] != 0) m.postConcat(con(1 + adj[2] * 0.7f));
        if (adj[3] != 0) m.postConcat(sat(1 + adj[3]));
        if (adj[4] != 0) m.postConcat(off(adj[4] * 30, adj[4] * 6, -adj[4] * 30));
        if (adj[5] != 0) m.postConcat(off(adj[5] * 12, -adj[5] * 25, adj[5] * 12));
        return m;
    }

    static Bitmap applyColor(Bitmap s, ColorMatrix m, float vignette) {
        Bitmap o = Bitmap.createBitmap(s.getWidth(), s.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(o);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        p.setColorFilter(new ColorMatrixColorFilter(m));
        c.drawBitmap(s, 0, 0, p);
        return o;
    }

    Bitmap render(Bitmap s) {
        int sw = s.getWidth(), sh = s.getHeight();
        boolean odd = rot % 2 == 1;
        float bw = odd ? sh : sw, bh = odd ? sw : sh;
        float r = ASPV[aspect];
        float cw = bw, ch = bh;
        if (r > 0) {
            if (bw / bh > r) { ch = bh; cw = bh * r; }
            else { cw = bw; ch = bw / r; }
        }
        double th = Math.toRadians(Math.abs(straight));
        float co = (float) Math.cos(th), si = (float) Math.sin(th);
        float sc = Math.max((cw * co + ch * si) / bw, (cw * si + ch * co) / bh);
        int ow = Math.max(1, Math.round(cw)), oh = Math.max(1, Math.round(ch));
        Bitmap o = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(o);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        p.setColorFilter(new ColorMatrixColorFilter(adjustMatrix()));
        c.save();
        c.translate(ow / 2f, oh / 2f);
        c.rotate(straight);
        c.scale(flip ? -sc : sc, sc);
        c.rotate(rot * 90);
        c.translate(-sw / 2f, -sh / 2f);
        c.drawBitmap(s, 0, 0, p);
        c.restore();
        if (adj[6] > 0) {
            Paint vp = new Paint(Paint.ANTI_ALIAS_FLAG);
            float rad = (float) Math.hypot(ow, oh) / 2f;
            vp.setShader(new RadialGradient(ow / 2f, oh / 2f, rad, new int[]{0x00000000, 0x00000000, ((int) (adj[6] * 230) << 24)},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, ow, oh, vp);
        }
        return o;
    }

    // ---------- Salvataggio ----------

    void save() {
        if (!changed()) { finish(); return; }
        Toast.makeText(this, "Salvataggio…", Toast.LENGTH_SHORT).show();
        Thumbs.async(() -> {
            boolean ok = false;
            try {
                Bitmap big = aiUsed ? src : Thumbs.full(this, uri, 4096);
                if (big != null) {
                    Bitmap out = render(big);
                    ContentValues cv = new ContentValues();
                    String base = getIntent().getStringExtra("name");
                    if (base == null) base = "IMG";
                    if (base.contains(".")) base = base.substring(0, base.lastIndexOf('.'));
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, base + "_E" + System.currentTimeMillis() % 100000 + ".jpg");
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Galleria");
                    cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    Uri dst = getContentResolver().insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), cv);
                    if (dst != null) {
                        try (OutputStream os = getContentResolver().openOutputStream(dst)) {
                            out.compress(Bitmap.CompressFormat.JPEG, 95, os);
                        }
                        ContentValues d = new ContentValues();
                        d.put(MediaStore.MediaColumns.IS_PENDING, 0);
                        getContentResolver().update(dst, d, null, null);
                        ok = true;
                    }
                }
            } catch (Exception | OutOfMemoryError ignored) { }
            final boolean fok = ok;
            h.post(() -> {
                if (fok) { Media.dirty = true; setResult(RESULT_OK); finish(); }
                else Toast.makeText(this, "Salvataggio non riuscito", Toast.LENGTH_LONG).show();
            });
        });
    }
}
