package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Immagine con zoom a pizzico, doppio tocco animato e trascinamento quando ingrandita

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

public class ZoomImageView extends ImageView {

    public interface Tap { void onTap(); }

    Tap tap;
    final Matrix base = new Matrix(), m = new Matrix();
    final float[] v = new float[9];
    ScaleGestureDetector sg;
    GestureDetector gd;
    public boolean zoomEnabled = true;
    ValueAnimator anim;

    public ZoomImageView(Context c) {
        super(c);
        setScaleType(ScaleType.MATRIX);
        sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                if (!zoomEnabled) return true;
                float z = zoom();
                float f = d.getScaleFactor();
                if (z * f > 8f) f = 8f / z;
                if (z * f < 0.6f) f = 0.6f / z;
                m.postScale(f, f, d.getFocusX(), d.getFocusY());
                fix(false);
                return true;
            }
            @Override public void onScaleEnd(ScaleGestureDetector d) {
                if (zoom() < 1f) animateTo(base);
            }
        });
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { if (anim != null) anim.cancel(); return true; }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) { if (tap != null) tap.onTap(); return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (!zoomEnabled) return true;
                if (zoom() > 1.05f) animateTo(base);
                else {
                    Matrix t = new Matrix(base);
                    t.postScale(2.6f, 2.6f, e.getX(), e.getY());
                    animateTo(clamped(t));
                }
                return true;
            }
            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (zoom() > 1.02f && e2.getPointerCount() == 1) {
                    m.postTranslate(-dx, -dy);
                    fix(false);
                }
                return true;
            }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (zoom() <= 1.02f) return false;
                final float[] vel = {vx / 60f, vy / 60f};
                anim = ValueAnimator.ofFloat(0, 1);
                anim.setDuration(500);
                anim.addUpdateListener(a -> {
                    vel[0] *= 0.9f; vel[1] *= 0.9f;
                    m.postTranslate(vel[0], vel[1]);
                    fix(false);
                });
                anim.start();
                return true;
            }
        });
    }

    public void setTap(Tap t) { tap = t; }

    public void setBitmap(Bitmap b) {
        super.setImageBitmap(b);
        fit();
    }

    public void setDrawableFit(Drawable d) {
        super.setImageDrawable(d);
        fit();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fit();
    }

    void fit() {
        Drawable d = getDrawable();
        if (d == null || getWidth() == 0 || getHeight() == 0) return;
        int dw = d.getIntrinsicWidth(), dh = d.getIntrinsicHeight();
        if (dw <= 0 || dh <= 0) return;
        float s = Math.min(getWidth() / (float) dw, getHeight() / (float) dh);
        base.reset();
        base.postScale(s, s);
        base.postTranslate((getWidth() - dw * s) / 2f, (getHeight() - dh * s) / 2f);
        m.set(base);
        setImageMatrix(m);
    }

    /** Rettangolo dell'immagine adattata allo schermo */
    public RectF fitRect() {
        Drawable d = getDrawable();
        if (d == null) return null;
        RectF r = new RectF(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        base.mapRect(r);
        return r;
    }

    public void reset() {
        if (anim != null) anim.cancel();
        m.set(base);
        setImageMatrix(m);
    }

    float scaleOf(Matrix x) { x.getValues(v); return v[Matrix.MSCALE_X]; }

    public float zoom() {
        float b = scaleOf(base);
        return b == 0 ? 1 : scaleOf(m) / b;
    }

    RectF rect(Matrix x) {
        Drawable d = getDrawable();
        RectF r = new RectF(0, 0, d == null ? 0 : d.getIntrinsicWidth(), d == null ? 0 : d.getIntrinsicHeight());
        x.mapRect(r);
        return r;
    }

    /** Si può passare alla foto vicina trascinando di dx? */
    public boolean canSwipe(float dx) {
        if (zoom() <= 1.02f) return true;
        RectF r = rect(m);
        if (dx > 0) return r.left >= -2;
        return r.right <= getWidth() + 2;
    }

    Matrix clamped(Matrix x) {
        RectF r = rect(x);
        float dx = 0, dy = 0, w = getWidth(), h = getHeight();
        if (r.width() <= w) dx = (w - r.width()) / 2f - r.left;
        else if (r.left > 0) dx = -r.left;
        else if (r.right < w) dx = w - r.right;
        if (r.height() <= h) dy = (h - r.height()) / 2f - r.top;
        else if (r.top > 0) dy = -r.top;
        else if (r.bottom < h) dy = h - r.bottom;
        x.postTranslate(dx, dy);
        return x;
    }

    void fix(boolean unused) {
        clamped(m);
        setImageMatrix(m);
    }

    void animateTo(Matrix target) {
        if (anim != null) anim.cancel();
        final float[] a = new float[9], b = new float[9], o = new float[9];
        m.getValues(a);
        target.getValues(b);
        anim = ValueAnimator.ofFloat(0, 1);
        anim.setDuration(320);
        anim.setInterpolator(Ui.EASE);
        anim.addUpdateListener(an -> {
            float t = (float) an.getAnimatedValue();
            for (int i = 0; i < 9; i++) o[i] = a[i] + (b[i] - a[i]) * t;
            m.setValues(o);
            setImageMatrix(m);
        });
        anim.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        sg.onTouchEvent(e);
        gd.onTouchEvent(e);
        return true;
    }
}
