package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Immagine con zoom a pizzico, doppio tocco, scorrimento laterale e trascinamento in basso per chiudere

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

public class ZoomImageView extends ImageView {

    public interface L {
        void onTap();
        void onNext();
        void onPrev();
        void onClose();
        void onDrag(float frac);
        void onDragEnd();
    }

    L l;
    final Matrix base = new Matrix(), m = new Matrix();
    final float[] v = new float[9];
    ScaleGestureDetector sg;
    GestureDetector gd;
    int axis = 0; // 0 nessuno, 1 orizzontale, 2 verticale
    float dragX = 0, dragY = 0;
    boolean scaling = false;
    float flingX = 0, flingY = 0;
    public boolean swipeEnabled = true;

    public ZoomImageView(Context c) {
        super(c);
        setScaleType(ScaleType.MATRIX);
        sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector d) { scaling = true; return true; }
            @Override public boolean onScale(ScaleGestureDetector d) {
                float z = zoom();
                float f = d.getScaleFactor();
                if (z * f > 8f) f = 8f / z;
                if (z * f < 0.7f) f = 0.7f / z;
                m.postScale(f, f, d.getFocusX(), d.getFocusY());
                fix();
                return true;
            }
            @Override public void onScaleEnd(ScaleGestureDetector d) {
                if (zoom() < 1f) reset();
            }
        });
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { flingX = 0; flingY = 0; return true; }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) { if (l != null) l.onTap(); return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (zoom() > 1.05f) reset();
                else { m.postScale(2.5f, 2.5f, e.getX(), e.getY()); fix(); }
                return true;
            }
            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (scaling || e2.getPointerCount() > 1) return true;
                if (zoom() > 1.02f) {
                    RectF r = rect();
                    boolean atLeft = r.left >= -1, atRight = r.right <= getWidth() + 1;
                    if (axis == 0 && Math.abs(dx) > Math.abs(dy) && ((dx < 0 && atLeft) || (dx > 0 && atRight)) && swipeEnabled) {
                        axis = 1;
                    }
                    if (axis != 1) {
                        m.postTranslate(-dx, -dy);
                        fix();
                        return true;
                    }
                }
                if (axis == 0) axis = Math.abs(dx) >= Math.abs(dy) ? 1 : 2;
                if (!swipeEnabled) return true;
                if (axis == 1) {
                    dragX -= dx;
                    setTranslationX(dragX);
                } else {
                    dragY -= dy;
                    if (dragY < 0) dragY *= 0.3f;
                    setTranslationY(dragY);
                    float s = 1f - Math.min(0.3f, Math.abs(dragY) / (getHeight() * 2f));
                    setScaleX(s); setScaleY(s);
                    if (l != null) l.onDrag(Math.min(1f, Math.abs(dragY) / (getHeight() / 3f)));
                }
                return true;
            }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                flingX = vx; flingY = vy;
                return true;
            }
        });
    }

    public void setListener(L l) { this.l = l; }

    public void setBitmap(Bitmap b) {
        super.setImageBitmap(b);
        fit();
    }

    public void setDrawableFit(Drawable d) {
        super.setImageDrawable(d);
        fit();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fit();
    }

    void fit() {
        Drawable d = getDrawable();
        if (d == null || getWidth() == 0 || getHeight() == 0) return;
        int dw = d.getIntrinsicWidth(), dh = d.getIntrinsicHeight();
        if (dw <= 0 || dh <= 0) return;
        float s = Math.min(getWidth() / (float) dw, getHeight() / (float) dh);
        base.reset();
        base.postScale(s, s);
        base.postTranslate((getWidth() - dw * s) / 2f, (getHeight() - dh * s) / 2f);
        m.set(base);
        setImageMatrix(m);
    }

    public void reset() { m.set(base); setImageMatrix(m); }

    float scaleOf(Matrix x) { x.getValues(v); return v[Matrix.MSCALE_X]; }

    public float zoom() {
        float b = scaleOf(base);
        return b == 0 ? 1 : scaleOf(m) / b;
    }

    RectF rect() {
        Drawable d = getDrawable();
        RectF r = new RectF(0, 0, d == null ? 0 : d.getIntrinsicWidth(), d == null ? 0 : d.getIntrinsicHeight());
        m.mapRect(r);
        return r;
    }

    void fix() {
        RectF r = rect();
        float dx = 0, dy = 0, w = getWidth(), h = getHeight();
        if (r.width() <= w) dx = (w - r.width()) / 2f - r.left;
        else if (r.left > 0) dx = -r.left;
        else if (r.right < w) dx = w - r.right;
        if (r.height() <= h) dy = (h - r.height()) / 2f - r.top;
        else if (r.top > 0) dy = -r.top;
        else if (r.bottom < h) dy = h - r.bottom;
        m.postTranslate(dx, dy);
        setImageMatrix(m);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        sg.onTouchEvent(e);
        gd.onTouchEvent(e);
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            if (axis == 1 && swipeEnabled) {
                float w = getWidth();
                if (dragX < -w / 4f || (flingX < -1200 && dragX < 0)) { if (l != null) l.onNext(); }
                else if (dragX > w / 4f || (flingX > 1200 && dragX > 0)) { if (l != null) l.onPrev(); }
                else animate().translationX(0).setDuration(180).start();
            } else if (axis == 2 && swipeEnabled) {
                if (dragY > getHeight() / 6f || flingY > 1500) { if (l != null) l.onClose(); }
                else {
                    animate().translationY(0).scaleX(1).scaleY(1).setDuration(180).start();
                    if (l != null) l.onDragEnd();
                }
            }
            axis = 0; dragX = 0; dragY = 0;
            scaling = false;
        }
        return true;
    }
}
