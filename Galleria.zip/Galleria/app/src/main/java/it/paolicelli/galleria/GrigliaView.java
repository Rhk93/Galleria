package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Griglia di foto con intestazioni, zoom a pizzico (cambia colonne) e selezione multipla

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;

public class GrigliaView extends ListView {

    public interface Cb {
        void open(ArrayList<Media.Item> list, int index);
        void selChanged(int count);
    }

    public static final int TUTTE = 0, GIORNI = 1;
    static final int[] COLS = {1, 3, 5, 9};
    static int colIdx = 1; // condiviso: come su iPhone la griglia ricorda lo zoom

    ArrayList<Media.Item> items = new ArrayList<>();
    final ArrayList<Object> rows = new ArrayList<>();
    int mode = TUTTE;
    public boolean selecting = false;
    public final HashSet<Long> selected = new HashSet<>();
    Cb cb;
    final Ad ad = new Ad();
    final ScaleGestureDetector sg;
    float scaleAcc = 1f;
    int bottomPad = 0;

    public GrigliaView(Context c) {
        super(c);
        setDivider(null);
        setDividerHeight(0);
        setSelector(new android.graphics.drawable.ColorDrawable(0));
        setBackgroundColor(Ui.BG);
        setClipToPadding(false);
        setAdapter(ad);
        setVerticalScrollBarEnabled(false);
        hp.setColor(Ui.dark ? 0xFF3A3A3C : 0xFFFFFFFF);
        hp.setShadowLayer(Ui.dp(c, 6), 0, Ui.dp(c, 1), 0x44000000);
        lp.setColor(Ui.dark ? 0xFF8E8E93 : 0xFF8E8E93);
        lp.setStrokeWidth(Ui.dp(c, 1.6f));
        lp.setStrokeCap(Paint.Cap.ROUND);
        lp.setStyle(Paint.Style.STROKE);
        bp.setColor(Ui.dark ? 0xF02C2C2E : 0xF2FFFFFF);
        bp.setShadowLayer(Ui.dp(c, 8), 0, Ui.dp(c, 2), 0x33000000);
        tp.setColor(Ui.TEXT);
        tp.setTextSize(Ui.dp(c, 15));
        tp.setFakeBoldText(true);
        setOnScrollListener(new OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView v, int st) { }
            @Override public void onScroll(AbsListView v, int first, int vis, int total) {
                if (total > vis * 3 && vis > 0) showHandle();
            }
        });
        sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector d) { scaleAcc = 1f; return true; }
            @Override public boolean onScale(ScaleGestureDetector d) {
                scaleAcc *= d.getScaleFactor();
                if (scaleAcc > 1.35f && colIdx > 0) { colIdx--; rebuildKeep(); zoomAnim(0.82f); scaleAcc = 1f; }
                else if (scaleAcc < 0.72f && colIdx < COLS.length - 1) { colIdx++; rebuildKeep(); zoomAnim(1.18f); scaleAcc = 1f; }
                return true;
            }
        });
    }

    public void setCb(Cb cb) { this.cb = cb; }

    public void setBottomPadding(int px) {
        bottomPad = px;
        setPadding(0, 0, 0, px);
    }

    public void setItems(ArrayList<Media.Item> list, int mode) {
        items = list;
        this.mode = mode;
        rebuild();
    }

    int cols() { return mode == GIORNI ? Math.max(3, COLS[colIdx]) : COLS[colIdx]; }

    void rebuild() {
        rows.clear();
        int n = cols();
        if (mode == GIORNI) {
            int i = 0;
            Calendar c = Calendar.getInstance();
            while (i < items.size()) {
                c.setTimeInMillis(items.get(i).date);
                int y = c.get(Calendar.YEAR), d = c.get(Calendar.DAY_OF_YEAR);
                rows.add(Ui.cap(Media.dayLabel(items.get(i).date)));
                ArrayList<Integer> day = new ArrayList<>();
                while (i < items.size()) {
                    c.setTimeInMillis(items.get(i).date);
                    if (c.get(Calendar.YEAR) != y || c.get(Calendar.DAY_OF_YEAR) != d) break;
                    day.add(i++);
                }
                for (int k = 0; k < day.size(); k += n) {
                    int[] r = new int[n];
                    for (int j = 0; j < n; j++) r[j] = k + j < day.size() ? day.get(k + j) : -1;
                    rows.add(r);
                }
            }
        } else {
            for (int k = 0; k < items.size(); k += n) {
                int[] r = new int[n];
                for (int j = 0; j < n; j++) r[j] = k + j < items.size() ? k + j : -1;
                rows.add(r);
            }
        }
        ad.notifyDataSetChanged();
    }

    /** Ricostruisce mantenendo visibile lo stesso punto */
    void rebuildKeep() {
        int first = firstItemVisible();
        rebuild();
        if (first >= 0) scrollToIndex(first);
    }

    int firstItemVisible() {
        int p = getFirstVisiblePosition();
        for (int i = p; i < rows.size(); i++) {
            Object o = rows.get(i);
            if (o instanceof int[]) return ((int[]) o)[0];
        }
        return -1;
    }

    public void scrollToIndex(int idx) {
        for (int i = 0; i < rows.size(); i++) {
            Object o = rows.get(i);
            if (o instanceof int[]) {
                for (int v : (int[]) o) if (v == idx) { final int row = (i > 0 && rows.get(i - 1) instanceof String) ? i - 1 : i; setSelection(row); return; }
            }
        }
    }

    public void scrollToItem(Media.Item it) {
        int idx = items.indexOf(it);
        if (idx >= 0) scrollToIndex(idx);
    }

    public void scrollToEnd() {
        post(() -> setSelection(Math.max(0, ad.getCount() - 1)));
    }

    public void setSelecting(boolean s) {
        selecting = s;
        selected.clear();
        ad.notifyDataSetChanged();
        if (cb != null) cb.selChanged(0);
    }

    public ArrayList<Media.Item> selectedItems() {
        ArrayList<Media.Item> o = new ArrayList<>();
        for (Media.Item it : items) if (selected.contains(it.id)) o.add(it);
        return o;
    }

    // ---------- Cursore di scorrimento stile iOS ----------

    final Paint hp = new Paint(Paint.ANTI_ALIAS_FLAG), lp = new Paint(Paint.ANTI_ALIAS_FLAG),
            bp = new Paint(Paint.ANTI_ALIAS_FLAG), tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    float hAlpha = 0;
    boolean hDrag = false;
    android.animation.ValueAnimator hAnim;
    final Runnable hideH = () -> fadeHandle(0);
    static final String[] MESI = {"Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"};

    void showHandle() {
        if (hAlpha < 1 && (hAnim == null || !hAnim.isRunning())) fadeHandle(1);
        removeCallbacks(hideH);
        if (!hDrag) postDelayed(hideH, 1500);
    }

    void fadeHandle(float to) {
        if (hAnim != null) hAnim.cancel();
        hAnim = android.animation.ValueAnimator.ofFloat(hAlpha, to);
        hAnim.setDuration(to > 0 ? 150 : 300);
        hAnim.addUpdateListener(a -> { hAlpha = (float) a.getAnimatedValue(); invalidate(); });
        hAnim.start();
    }

    float trackTop() { return getPaddingTop() + Ui.dp(getContext(), 8); }
    float trackH() { return getHeight() - getPaddingBottom() - Ui.dp(getContext(), 8) - trackTop(); }
    float hh() { return Ui.dp(getContext(), 44); }
    float hw() { return Ui.dp(getContext(), 30); }

    float frac() {
        int vis = getLastVisiblePosition() - getFirstVisiblePosition() + 1;
        int range = Math.max(1, ad.getCount() - vis);
        View c0 = getChildAt(0);
        float partial = (c0 != null && c0.getHeight() > 0) ? -c0.getTop() / (float) c0.getHeight() : 0;
        return Math.max(0, Math.min(1, (getFirstVisiblePosition() + partial) / range));
    }

    float handleY() { return trackTop() + frac() * (trackH() - hh()); }

    String handleLabel() {
        int i = firstItemVisible();
        if (i < 0 || i >= items.size()) return "";
        Media.Item it = items.get(i);
        return MESI[it.month()] + " " + it.year();
    }

    @Override
    protected void dispatchDraw(Canvas c) {
        super.dispatchDraw(c);
        if (hAlpha <= 0.01f) return;
        int a = (int) (255 * hAlpha);
        float y = handleY(), x = getWidth() - hw() - Ui.dp(getContext(), 4);
        hp.setAlpha(a); lp.setAlpha(a);
        RectF r = new RectF(x, y, x + hw(), y + hh());
        c.drawRoundRect(r, hw() / 2f, hw() / 2f, hp);
        float cx = r.centerX(), cy = r.centerY(), d = Ui.dp(getContext(), 4);
        Path pa = new Path();
        pa.moveTo(cx - d, cy - d * 1.2f); pa.lineTo(cx, cy - d * 2.2f); pa.lineTo(cx + d, cy - d * 1.2f);
        pa.moveTo(cx - d, cy + d * 1.2f); pa.lineTo(cx, cy + d * 2.2f); pa.lineTo(cx + d, cy + d * 1.2f);
        c.drawPath(pa, lp);
        if (hDrag) {
            String t = handleLabel();
            float tw = tp.measureText(t), pad = Ui.dp(getContext(), 14), bh = Ui.dp(getContext(), 38);
            RectF b = new RectF(x - tw - pad * 2 - Ui.dp(getContext(), 10), r.centerY() - bh / 2, x - Ui.dp(getContext(), 10), r.centerY() + bh / 2);
            bp.setAlpha(a);
            c.drawRoundRect(b, bh / 2, bh / 2, bp);
            tp.setAlpha(a);
            c.drawText(t, b.left + pad, b.centerY() + tp.getTextSize() / 3f, tp);
        }
    }

    boolean onHandle(MotionEvent e) {
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            float y = handleY();
            if (hAlpha > 0.5f && e.getX() > getWidth() - hw() - Ui.dp(getContext(), 20)
                    && e.getY() > y - Ui.dp(getContext(), 16) && e.getY() < y + hh() + Ui.dp(getContext(), 16)) {
                hDrag = true;
                removeCallbacks(hideH);
                performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                invalidate();
                return true;
            }
            return false;
        }
        if (!hDrag) return false;
        if (act == MotionEvent.ACTION_MOVE) {
            float f = (e.getY() - trackTop() - hh() / 2f) / Math.max(1, trackH() - hh());
            f = Math.max(0, Math.min(1, f));
            int vis = getLastVisiblePosition() - getFirstVisiblePosition() + 1;
            int range = Math.max(1, ad.getCount() - vis);
            setSelection(Math.round(f * range));
            invalidate();
        } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
            hDrag = false;
            postDelayed(hideH, 1200);
            invalidate();
        }
        return true;
    }

    void zoomAnim(float from) {
        setPivotY(getHeight() / 2f);
        setScaleX(from); setScaleY(from); setAlpha(0.6f);
        animate().scaleX(1).scaleY(1).alpha(1).setDuration(260).setInterpolator(Ui.EASE).start();
    }

    /** Posizione sullo schermo della miniatura di un elemento (per l'animazione di apertura/chiusura) */
    public android.graphics.Rect rectOf(Media.Item it) {
        for (int i = 0; i < getChildCount(); i++) {
            View row = getChildAt(i);
            if (!(row instanceof LinearLayout)) continue;
            LinearLayout r = (LinearLayout) row;
            for (int j = 0; j < r.getChildCount(); j++) {
                View cell = r.getChildAt(j);
                Object t = cell.getTag();
                if (cell.getVisibility() == VISIBLE && t instanceof Long && (Long) t == it.id) {
                    int[] loc = new int[2];
                    cell.getLocationOnScreen(loc);
                    android.graphics.Rect rc = new android.graphics.Rect(loc[0], loc[1], loc[0] + cell.getWidth(), loc[1] + cell.getHeight());
                    int[] me = new int[2];
                    getLocationOnScreen(me);
                    if (rc.bottom < me[1] + getPaddingTop() || rc.top > me[1] + getHeight() - getPaddingBottom()) return null;
                    return rc;
                }
            }
        }
        return null;
    }

    public boolean isVisible(Media.Item it) { return rectOf(it) != null; }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        if (onHandle(e)) return true;
        sg.onTouchEvent(e);
        if (e.getPointerCount() > 1) {
            // durante il pizzico non scorrere
            MotionEvent c = MotionEvent.obtain(e);
            c.setAction(MotionEvent.ACTION_CANCEL);
            super.dispatchTouchEvent(c);
            c.recycle();
            return true;
        }
        return super.dispatchTouchEvent(e);
    }

    class Ad extends BaseAdapter {
        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int p) { return rows.get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int p) { return rows.get(p) instanceof String ? 0 : 1; }

        @Override
        public View getView(int pos, View cv, ViewGroup parent) {
            Context c = getContext();
            Object o = rows.get(pos);
            if (o instanceof String) {
                TextView t = cv instanceof TextView ? (TextView) cv : Ui.text(c, "", 17, Ui.TEXT, true);
                t.setText((String) o);
                t.setTextColor(Ui.TEXT);
                t.setPadding(Ui.dp(c, 16), Ui.dp(c, 18), Ui.dp(c, 16), Ui.dp(c, 8));
                return t;
            }
            int[] r = (int[]) o;
            int n = r.length;
            int w = getWidth() > 0 ? getWidth() : getResources().getDisplayMetrics().widthPixels;
            int gap = n == 1 ? 0 : Math.max(1, Ui.dp(c, 1.5f));
            int size = (w - gap * (n - 1)) / n;
            int hh = n == 1 ? (int) (w * 0.75f) : size;
            LinearLayout row;
            if (cv instanceof LinearLayout && ((LinearLayout) cv).getChildCount() == n && cv.getTag() != null && (int) cv.getTag() == size) {
                row = (LinearLayout) cv;
            } else {
                row = new LinearLayout(c);
                row.setTag(size);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, hh + gap));
                row.setPadding(0, 0, 0, gap);
                for (int j = 0; j < n; j++) {
                    FrameLayout cell = new FrameLayout(c);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, hh);
                    if (j > 0) lp.leftMargin = gap;
                    cell.setLayoutParams(lp);
                    ImageView iv = new ImageView(c);
                    iv.setScaleType(n == 1 ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
                    iv.setBackgroundColor(n == 1 ? Ui.BG : Ui.BG2);
                    cell.addView(iv, new FrameLayout.LayoutParams(-1, -1));
                    TextView dur = Ui.text(c, "", n > 5 ? 9 : 12, 0xFFFFFFFF, true);
                    dur.setShadowLayer(4, 0, 0, 0xAA000000);
                    FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
                    dl.setMargins(0, 0, Ui.dp(c, 5), Ui.dp(c, 3));
                    cell.addView(dur, dl);
                    ImageView heart = new ImageView(c);
                    heart.setImageDrawable(new Icon("heartfill", 0xFFFFFFFF));
                    int hs = Ui.dp(c, n > 5 ? 10 : 14);
                    FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(hs, hs, Gravity.BOTTOM | Gravity.START);
                    hl.setMargins(Ui.dp(c, 5), 0, 0, Ui.dp(c, 5));
                    cell.addView(heart, hl);
                    View dim = new View(c);
                    dim.setBackgroundColor(0x55FFFFFF);
                    cell.addView(dim, new FrameLayout.LayoutParams(-1, -1));
                    ImageView chk = new ImageView(c);
                    int cs = Ui.dp(c, n > 5 ? 16 : 22);
                    FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(cs, cs, Gravity.BOTTOM | Gravity.END);
                    cl.setMargins(0, 0, Ui.dp(c, 5), Ui.dp(c, 5));
                    cell.addView(chk, cl);
                    row.addView(cell);
                }
            }
            int px = Math.min(512, Math.max(128, size));
            for (int j = 0; j < n; j++) {
                FrameLayout cell = (FrameLayout) row.getChildAt(j);
                ImageView iv = (ImageView) cell.getChildAt(0);
                TextView dur = (TextView) cell.getChildAt(1);
                View heart = cell.getChildAt(2);
                View dim = cell.getChildAt(3);
                ImageView chk = (ImageView) cell.getChildAt(4);
                final int idx = r[j];
                if (idx < 0) {
                    cell.setVisibility(INVISIBLE);
                    cell.setOnClickListener(null);
                    continue;
                }
                cell.setVisibility(VISIBLE);
                final Media.Item it = items.get(idx);
                cell.setTag(it.id);
                Thumbs.load(c, it, iv, px);
                dur.setText(it.video ? Ui.dur(it.duration) : "");
                heart.setVisibility(it.fav && !selecting ? VISIBLE : GONE);
                boolean sel = selected.contains(it.id);
                dim.setVisibility(selecting && sel ? VISIBLE : GONE);
                chk.setVisibility(selecting ? VISIBLE : GONE);
                if (selecting) chk.setImageDrawable(new Icon(sel ? "check" : "ring", Ui.BLUE));
                cell.setOnClickListener(v -> {
                    if (selecting) {
                        if (!selected.remove(it.id)) selected.add(it.id);
                        notifyDataSetChanged();
                        if (cb != null) cb.selChanged(selected.size());
                    } else if (cb != null) cb.open(items, idx);
                });
                cell.setOnLongClickListener(v -> {
                    if (!selecting) {
                        selecting = true;
                        selected.clear();
                    }
                    selected.add(it.id);
                    notifyDataSetChanged();
                    if (cb != null) cb.selChanged(selected.size());
                    return true;
                });
            }
            return row;
        }
    }

    public static ArrayList<Media.Item> copy(List<Media.Item> l) { return new ArrayList<>(l); }
}
