package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Griglia di foto con intestazioni, zoom a pizzico (cambia colonne) e selezione multipla

import android.content.Context;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;

public class GrigliaView extends ListView {

    public interface Cb {
        void open(ArrayList<Media.Item> list, int index);
        void selChanged(int count);
    }

    public static final int TUTTE = 0, GIORNI = 1;
    static final int[] COLS = {1, 3, 5, 9};
    static int colIdx = 1; // condiviso: come su iPhone la griglia ricorda lo zoom

    ArrayList<Media.Item> items = new ArrayList<>();
    final ArrayList<Object> rows = new ArrayList<>();
    int mode = TUTTE;
    public boolean selecting = false;
    public final HashSet<Long> selected = new HashSet<>();
    Cb cb;
    final Ad ad = new Ad();
    final ScaleGestureDetector sg;
    float scaleAcc = 1f;
    int bottomPad = 0;

    public GrigliaView(Context c) {
        super(c);
        setDivider(null);
        setDividerHeight(0);
        setSelector(new android.graphics.drawable.ColorDrawable(0));
        setBackgroundColor(Ui.BG);
        setClipToPadding(false);
        setFastScrollEnabled(true);
        setAdapter(ad);
        sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector d) { scaleAcc = 1f; return true; }
            @Override public boolean onScale(ScaleGestureDetector d) {
                scaleAcc *= d.getScaleFactor();
                if (scaleAcc > 1.35f && colIdx > 0) { colIdx--; rebuildKeep(); scaleAcc = 1f; }
                else if (scaleAcc < 0.72f && colIdx < COLS.length - 1) { colIdx++; rebuildKeep(); scaleAcc = 1f; }
                return true;
            }
        });
    }

    public void setCb(Cb cb) { this.cb = cb; }

    public void setBottomPadding(int px) {
        bottomPad = px;
        setPadding(0, 0, 0, px);
    }

    public void setItems(ArrayList<Media.Item> list, int mode) {
        items = list;
        this.mode = mode;
        rebuild();
    }

    int cols() { return mode == GIORNI ? Math.max(3, COLS[colIdx]) : COLS[colIdx]; }

    void rebuild() {
        rows.clear();
        int n = cols();
        if (mode == GIORNI) {
            int i = 0;
            Calendar c = Calendar.getInstance();
            while (i < items.size()) {
                c.setTimeInMillis(items.get(i).date);
                int y = c.get(Calendar.YEAR), d = c.get(Calendar.DAY_OF_YEAR);
                rows.add(Ui.cap(Media.dayLabel(items.get(i).date)));
                ArrayList<Integer> day = new ArrayList<>();
                while (i < items.size()) {
                    c.setTimeInMillis(items.get(i).date);
                    if (c.get(Calendar.YEAR) != y || c.get(Calendar.DAY_OF_YEAR) != d) break;
                    day.add(i++);
                }
                for (int k = 0; k < day.size(); k += n) {
                    int[] r = new int[n];
                    for (int j = 0; j < n; j++) r[j] = k + j < day.size() ? day.get(k + j) : -1;
                    rows.add(r);
                }
            }
        } else {
            for (int k = 0; k < items.size(); k += n) {
                int[] r = new int[n];
                for (int j = 0; j < n; j++) r[j] = k + j < items.size() ? k + j : -1;
                rows.add(r);
            }
        }
        ad.notifyDataSetChanged();
    }

    /** Ricostruisce mantenendo visibile lo stesso punto */
    void rebuildKeep() {
        int first = firstItemVisible();
        rebuild();
        if (first >= 0) scrollToIndex(first);
    }

    int firstItemVisible() {
        int p = getFirstVisiblePosition();
        for (int i = p; i < rows.size(); i++) {
            Object o = rows.get(i);
            if (o instanceof int[]) return ((int[]) o)[0];
        }
        return -1;
    }

    public void scrollToIndex(int idx) {
        for (int i = 0; i < rows.size(); i++) {
            Object o = rows.get(i);
            if (o instanceof int[]) {
                for (int v : (int[]) o) if (v == idx) { final int row = (i > 0 && rows.get(i - 1) instanceof String) ? i - 1 : i; setSelection(row); return; }
            }
        }
    }

    public void scrollToItem(Media.Item it) {
        int idx = items.indexOf(it);
        if (idx >= 0) scrollToIndex(idx);
    }

    public void scrollToEnd() {
        post(() -> setSelection(Math.max(0, ad.getCount() - 1)));
    }

    public void setSelecting(boolean s) {
        selecting = s;
        selected.clear();
        ad.notifyDataSetChanged();
        if (cb != null) cb.selChanged(0);
    }

    public ArrayList<Media.Item> selectedItems() {
        ArrayList<Media.Item> o = new ArrayList<>();
        for (Media.Item it : items) if (selected.contains(it.id)) o.add(it);
        return o;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        sg.onTouchEvent(e);
        if (e.getPointerCount() > 1) {
            // durante il pizzico non scorrere
            MotionEvent c = MotionEvent.obtain(e);
            c.setAction(MotionEvent.ACTION_CANCEL);
            super.dispatchTouchEvent(c);
            c.recycle();
            return true;
        }
        return super.dispatchTouchEvent(e);
    }

    class Ad extends BaseAdapter {
        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int p) { return rows.get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int p) { return rows.get(p) instanceof String ? 0 : 1; }

        @Override
        public View getView(int pos, View cv, ViewGroup parent) {
            Context c = getContext();
            Object o = rows.get(pos);
            if (o instanceof String) {
                TextView t = cv instanceof TextView ? (TextView) cv : Ui.text(c, "", 17, Ui.TEXT, true);
                t.setText((String) o);
                t.setTextColor(Ui.TEXT);
                t.setPadding(Ui.dp(c, 16), Ui.dp(c, 18), Ui.dp(c, 16), Ui.dp(c, 8));
                return t;
            }
            int[] r = (int[]) o;
            int n = r.length;
            int w = getWidth() > 0 ? getWidth() : getResources().getDisplayMetrics().widthPixels;
            int gap = n == 1 ? 0 : Math.max(1, Ui.dp(c, 1.5f));
            int size = (w - gap * (n - 1)) / n;
            int hh = n == 1 ? (int) (w * 0.75f) : size;
            LinearLayout row;
            if (cv instanceof LinearLayout && ((LinearLayout) cv).getChildCount() == n && cv.getTag() != null && (int) cv.getTag() == size) {
                row = (LinearLayout) cv;
            } else {
                row = new LinearLayout(c);
                row.setTag(size);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, hh + gap));
                row.setPadding(0, 0, 0, gap);
                for (int j = 0; j < n; j++) {
                    FrameLayout cell = new FrameLayout(c);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, hh);
                    if (j > 0) lp.leftMargin = gap;
                    cell.setLayoutParams(lp);
                    ImageView iv = new ImageView(c);
                    iv.setScaleType(n == 1 ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
                    iv.setBackgroundColor(n == 1 ? Ui.BG : Ui.BG2);
                    cell.addView(iv, new FrameLayout.LayoutParams(-1, -1));
                    TextView dur = Ui.text(c, "", n > 5 ? 9 : 12, 0xFFFFFFFF, true);
                    dur.setShadowLayer(4, 0, 0, 0xAA000000);
                    FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
                    dl.setMargins(0, 0, Ui.dp(c, 5), Ui.dp(c, 3));
                    cell.addView(dur, dl);
                    ImageView heart = new ImageView(c);
                    heart.setImageDrawable(new Icon("heartfill", 0xFFFFFFFF));
                    int hs = Ui.dp(c, n > 5 ? 10 : 14);
                    FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(hs, hs, Gravity.BOTTOM | Gravity.START);
                    hl.setMargins(Ui.dp(c, 5), 0, 0, Ui.dp(c, 5));
                    cell.addView(heart, hl);
                    View dim = new View(c);
                    dim.setBackgroundColor(0x55FFFFFF);
                    cell.addView(dim, new FrameLayout.LayoutParams(-1, -1));
                    ImageView chk = new ImageView(c);
                    int cs = Ui.dp(c, n > 5 ? 16 : 22);
                    FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(cs, cs, Gravity.BOTTOM | Gravity.END);
                    cl.setMargins(0, 0, Ui.dp(c, 5), Ui.dp(c, 5));
                    cell.addView(chk, cl);
                    row.addView(cell);
                }
            }
            int px = Math.min(512, Math.max(128, size));
            for (int j = 0; j < n; j++) {
                FrameLayout cell = (FrameLayout) row.getChildAt(j);
                ImageView iv = (ImageView) cell.getChildAt(0);
                TextView dur = (TextView) cell.getChildAt(1);
                View heart = cell.getChildAt(2);
                View dim = cell.getChildAt(3);
                ImageView chk = (ImageView) cell.getChildAt(4);
                final int idx = r[j];
                if (idx < 0) {
                    cell.setVisibility(INVISIBLE);
                    cell.setOnClickListener(null);
                    continue;
                }
                cell.setVisibility(VISIBLE);
                final Media.Item it = items.get(idx);
                Thumbs.load(c, it, iv, px);
                dur.setText(it.video ? Ui.dur(it.duration) : "");
                heart.setVisibility(it.fav && !selecting ? VISIBLE : GONE);
                boolean sel = selected.contains(it.id);
                dim.setVisibility(selecting && sel ? VISIBLE : GONE);
                chk.setVisibility(selecting ? VISIBLE : GONE);
                if (selecting) chk.setImageDrawable(new Icon(sel ? "check" : "ring", Ui.BLUE));
                cell.setOnClickListener(v -> {
                    if (selecting) {
                        if (!selected.remove(it.id)) selected.add(it.id);
                        notifyDataSetChanged();
                        if (cb != null) cb.selChanged(selected.size());
                    } else if (cb != null) cb.open(items, idx);
                });
                cell.setOnLongClickListener(v -> {
                    if (!selecting) {
                        selecting = true;
                        selected.clear();
                    }
                    selected.add(it.id);
                    notifyDataSetChanged();
                    if (cb != null) cb.selChanged(selected.size());
                    return true;
                });
            }
            return row;
        }
    }

    public static ArrayList<Media.Item> copy(List<Media.Item> l) { return new ArrayList<>(l); }
}
