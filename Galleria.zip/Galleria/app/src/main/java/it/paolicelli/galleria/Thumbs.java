package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.Size;
import android.widget.ImageView;

import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Thumbs {
    static final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 6)) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    // Coda LIFO: carica prima le miniature appena comparse sullo schermo
    static final ThreadPoolExecutor ex = new ThreadPoolExecutor(4, 4, 30, TimeUnit.SECONDS,
            new LinkedBlockingDeque<Runnable>() {
                @Override public boolean offer(Runnable r) { return super.offerFirst(r); }
            });
    static final Handler main = new Handler(Looper.getMainLooper());

    public static Bitmap cached(Media.Item it, int px) {
        return cache.get(it.id + "_" + px);
    }

    public static void load(Context c, Media.Item it, ImageView iv, int px) {
        final String key = it.id + "_" + px;
        iv.setTag(key);
        Bitmap b = cache.get(key);
        if (b != null) { iv.setImageBitmap(b); return; }
        iv.setImageDrawable(null);
        final ContentResolver cr = c.getApplicationContext().getContentResolver();
        ex.execute(() -> {
            if (!key.equals(iv.getTag())) return;
            Bitmap bm = null;
            try { bm = cr.loadThumbnail(it.uri, new Size(px, px), null); } catch (Exception | OutOfMemoryError ignored) { }
            final Bitmap fb = bm;
            if (fb != null) cache.put(key, fb);
            main.post(() -> { if (key.equals(iv.getTag()) && fb != null) iv.setImageBitmap(fb); });
        });
    }

    public interface Cb { void got(Bitmap b); }

    public static void async(Runnable r) { ex.execute(r); }

    /** Decodifica un'immagine intera ridotta a maxSide (software, modificabile) */
    public static Bitmap full(Context c, Uri uri, int maxSide) {
        try {
            ImageDecoder.Source src = ImageDecoder.createSource(c.getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(src, (decoder, info, s) -> {
                int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                float sc = Math.min(1f, maxSide / (float) Math.max(w, h));
                if (sc < 1f) decoder.setTargetSize(Math.max(1, Math.round(w * sc)), Math.max(1, Math.round(h * sc)));
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                decoder.setMutableRequired(false);
            });
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }

    public static Bitmap thumbNow(Context c, Media.Item it, int px) {
        Bitmap b = cached(it, px);
        if (b != null) return b;
        try {
            b = c.getContentResolver().loadThumbnail(it.uri, new Size(px, px), null);
            if (b != null) cache.put(it.id + "_" + px, b);
        } catch (Exception ignored) { }
        return b;
    }
}
