package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.Size;
import android.widget.ImageView;

import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Thumbs {
    static final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 6)) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    static final HashMap<Long, String> lastKey = new HashMap<>();
    static final HashSet<String> pending = new HashSet<>();

    // Coda LIFO: carica prima le miniature appena comparse sullo schermo
    static final ThreadPoolExecutor ex = new ThreadPoolExecutor(4, 4, 30, TimeUnit.SECONDS,
            new LinkedBlockingDeque<Runnable>() {
                @Override public boolean offer(Runnable r) { return super.offerFirst(r); }
            });
    // Coda separata per le immagini a piena risoluzione del visore
    static final ThreadPoolExecutor big = new ThreadPoolExecutor(2, 2, 30, TimeUnit.SECONDS,
            new LinkedBlockingDeque<Runnable>() {
                @Override public boolean offer(Runnable r) { return super.offerFirst(r); }
            });
    static final Handler main = new Handler(Looper.getMainLooper());

    static void put(String key, long id, Bitmap b) {
        cache.put(key, b);
        synchronized (lastKey) { lastKey.put(id, key); }
    }

    public static Bitmap cached(Media.Item it, int px) {
        return cache.get(it.id + "_" + px);
    }

    /** Qualsiasi miniatura già in memoria per questo elemento */
    public static Bitmap anyCached(Media.Item it) {
        String k;
        synchronized (lastKey) { k = lastKey.get(it.id); }
        Bitmap b = k == null ? null : cache.get(k);
        if (b == null) b = cached(it, 256);
        return b;
    }

    public static void load(Context c, Media.Item it, ImageView iv, int px) {
        final String key = it.id + "_" + px;
        iv.setTag(key);
        Bitmap b = cache.get(key);
        if (b != null) { iv.setImageBitmap(b); return; }
        iv.setImageDrawable(null);
        final ContentResolver cr = c.getApplicationContext().getContentResolver();
        ex.execute(() -> {
            if (!key.equals(iv.getTag())) return;
            Bitmap bm = null;
            try { bm = cr.loadThumbnail(it.uri, new Size(px, px), null); } catch (Exception | OutOfMemoryError ignored) { }
            final Bitmap fb = bm;
            if (fb != null) put(key, it.id, fb);
            main.post(() -> { if (key.equals(iv.getTag()) && fb != null) iv.setImageBitmap(fb); });
        });
    }

    /** Carica in cache e avvisa quando è pronta (per la striscia di miniature) */
    public static void request(Context c, Media.Item it, int px, Runnable done) {
        final String key = it.id + "_" + px;
        if (cache.get(key) != null) return;
        synchronized (pending) { if (!pending.add(key)) return; }
        final ContentResolver cr = c.getApplicationContext().getContentResolver();
        ex.execute(() -> {
            try {
                Bitmap bm = cr.loadThumbnail(it.uri, new Size(px, px), null);
                if (bm != null) put(key, it.id, bm);
            } catch (Exception | OutOfMemoryError ignored) { }
            synchronized (pending) { pending.remove(key); }
            if (done != null) main.post(done);
        });
    }

    public static void async(Runnable r) { ex.execute(r); }

    public static void asyncBig(Runnable r) { big.execute(r); }

    /** Decodifica un'immagine intera ridotta a maxSide. hardware=true per il visore (più fluido) */
    public static Bitmap full(Context c, Uri uri, int maxSide, boolean hardware) {
        try {
            ImageDecoder.Source src = ImageDecoder.createSource(c.getContentResolver(), uri);
            Bitmap b = ImageDecoder.decodeBitmap(src, (decoder, info, s) -> {
                int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                float sc = Math.min(1f, maxSide / (float) Math.max(w, h));
                if (sc < 1f) decoder.setTargetSize(Math.max(1, Math.round(w * sc)), Math.max(1, Math.round(h * sc)));
                decoder.setAllocator(hardware ? ImageDecoder.ALLOCATOR_DEFAULT : ImageDecoder.ALLOCATOR_SOFTWARE);
            });
            if (b != null) b.prepareToDraw();
            return b;
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }

    public static Bitmap full(Context c, Uri uri, int maxSide) {
        return full(c, uri, maxSide, false);
    }

    public static Bitmap thumbNow(Context c, Media.Item it, int px) {
        Bitmap b = cached(it, px);
        if (b != null) return b;
        try {
            b = c.getContentResolver().loadThumbnail(it.uri, new Size(px, px), null);
            if (b != null) put(it.id + "_" + px, it.id, b);
        } catch (Exception ignored) { }
        return b;
    }
}
