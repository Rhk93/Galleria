package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Ui {
    public static boolean dark;
    public static int BG, BG2, CARD, TEXT, TEXT2, SEP, BLUE = 0xFF007AFF;
    public static final int RED = 0xFFFF3B30;

    public static void init(Context c) {
        dark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (dark) {
            BG = 0xFF000000; BG2 = 0xFF1C1C1E; CARD = 0xFF2C2C2E; TEXT = 0xFFFFFFFF; TEXT2 = 0xFF8E8E93; SEP = 0xFF38383A; BLUE = 0xFF0A84FF;
        } else {
            BG = 0xFFFFFFFF; BG2 = 0xFFF2F2F7; CARD = 0xFFFFFFFF; TEXT = 0xFF000000; TEXT2 = 0xFF8E8E93; SEP = 0xFFD1D1D6; BLUE = 0xFF007AFF;
        }
    }

    public static void bars(Activity a, int color, boolean lightIcons) {
        Window w = a.getWindow();
        w.setStatusBarColor(color);
        w.setNavigationBarColor(color);
        View d = w.getDecorView();
        int f = 0;
        if (!lightIcons) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        d.setSystemUiVisibility(f);
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    public static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    /** Bottone a capsula stile iOS 18 */
    public static TextView pill(Context c, String s) {
        TextView t = text(c, s, 15, TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 14), dp(c, 7), dp(c, 14), dp(c, 7));
        t.setBackground(round(dark ? 0xCC3A3A3C : 0xE6F2F2F7, dp(c, 20)));
        return t;
    }

    public static ImageView icon(Context c, String type, int color, int sizeDp) {
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Icon(type, color));
        int s = dp(c, sizeDp);
        iv.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        return iv;
    }

    /** Icona dentro un cerchio, per le barre del visore */
    public static ImageView circleIcon(Context c, String type, int color) {
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Icon(type, color));
        int p = dp(c, 9);
        iv.setPadding(p, p, p, p);
        iv.setBackground(round(dark ? 0xCC3A3A3C : 0xE6F2F2F7, dp(c, 22)));
        int s = dp(c, 44);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s, s);
        iv.setLayoutParams(lp);
        return iv;
    }

    public static View space(Context c) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        return v;
    }

    public static View sep(Context c) {
        View v = new View(c);
        v.setBackgroundColor(SEP);
        v.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.5f))));
        return v;
    }

    public static String cap(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    public static String dur(long ms) {
        long s = ms / 1000;
        if (s >= 3600) return String.format(java.util.Locale.ITALY, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
        return String.format(java.util.Locale.ITALY, "%d:%02d", s / 60, s % 60);
    }
}
