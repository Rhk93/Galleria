package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Ui {
    public static boolean dark;
    public static int BG, BG2, CARD, TEXT, TEXT2, SEP, BLUE = 0xFF007AFF;
    public static final int RED = 0xFFFF3B30;

    public static void init(Context c) {
        dark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (dark) {
            BG = 0xFF000000; BG2 = 0xFF1C1C1E; CARD = 0xFF2C2C2E; TEXT = 0xFFFFFFFF; TEXT2 = 0xFF8E8E93; SEP = 0xFF38383A; BLUE = 0xFF0A84FF;
        } else {
            BG = 0xFFFFFFFF; BG2 = 0xFFF2F2F7; CARD = 0xFFFFFFFF; TEXT = 0xFF000000; TEXT2 = 0xFF8E8E93; SEP = 0xFFD1D1D6; BLUE = 0xFF007AFF;
        }
    }

    public static void bars(Activity a, int color, boolean lightIcons) {
        Window w = a.getWindow();
        w.setStatusBarColor(color);
        w.setNavigationBarColor(color);
        View d = w.getDecorView();
        int f = 0;
        if (!lightIcons) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        d.setSystemUiVisibility(f);
    }

    /** Margini delle barre di sistema (impostati dalle activity) */
    public static int top = 0, bottom = 0;
    /** Curva di animazione simile a quella di iOS */
    public static final android.view.animation.Interpolator EASE = new Spring(0.9f);
    /** Molla con un piccolo rimbalzo, come le animazioni di iOS */
    public static final android.view.animation.Interpolator BOUNCE = new Spring(0.68f);

    /** Interpolatore a molla smorzata (fisica delle animazioni iOS) */
    public static class Spring implements android.view.animation.Interpolator {
        final double z, w, wd;
        public Spring(float damping) {
            z = damping;
            w = 7.0 / damping;
            wd = w * Math.sqrt(1 - z * z);
        }
        @Override public float getInterpolation(float t) {
            if (t >= 1f) return 1f;
            double e = Math.exp(-z * w * t);
            return (float) (1 - e * (Math.cos(wd * t) + (z * w / wd) * Math.sin(wd * t)));
        }
    }

    /** Disegna sotto le barre di sistema (come su iPhone) e gestisce i margini a mano */
    public static void edge(Activity a, boolean lightIcons, boolean hideBars) {
        Window w = a.getWindow();
        w.setStatusBarColor(0);
        w.setNavigationBarColor(0);
        w.setNavigationBarContrastEnforced(false);
        w.setStatusBarContrastEnforced(false);
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (!lightIcons) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        if (hideBars) f |= View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        w.getDecorView().setSystemUiVisibility(f);
    }

    /** Legge i margini delle barre; restituisce true se sono cambiati */
    public static boolean readInsets(android.view.WindowInsets ins) {
        int t, b;
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            android.graphics.Insets i = ins.getInsetsIgnoringVisibility(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
            t = i.top; b = i.bottom;
        } else {
            t = ins.getStableInsetTop(); b = ins.getStableInsetBottom();
        }
        boolean ch = t != top || b != bottom;
        top = t; bottom = b;
        return ch;
    }

    /** Effetto pressione stile iOS */
    public static void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == android.view.MotionEvent.ACTION_DOWN)
                x.animate().scaleX(0.94f).scaleY(0.94f).alpha(0.7f).setDuration(90).start();
            else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220).setInterpolator(EASE).start();
            return false;
        });
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    public static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    /** Bottone a capsula stile iOS 18 */
    public static TextView pill(Context c, String s) {
        TextView t = text(c, s, 15, TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 14), dp(c, 7), dp(c, 14), dp(c, 7));
        t.setBackground(round(dark ? 0xCC3A3A3C : 0xE6F2F2F7, dp(c, 20)));
        press(t);
        return t;
    }

    public static ImageView icon(Context c, String type, int color, int sizeDp) {
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Icon(type, color));
        int s = dp(c, sizeDp);
        iv.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        return iv;
    }

    /** Icona dentro un cerchio, per le barre del visore */
    public static ImageView circleIcon(Context c, String type, int color) {
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Icon(type, color));
        int p = dp(c, 9);
        iv.setPadding(p, p, p, p);
        iv.setBackground(round(dark ? 0xCC3A3A3C : 0xE6F2F2F7, dp(c, 22)));
        int s = dp(c, 44);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s, s);
        iv.setLayoutParams(lp);
        press(iv);
        return iv;
    }

    public static View space(Context c) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        return v;
    }

    public static View sep(Context c) {
        View v = new View(c);
        v.setBackgroundColor(SEP);
        v.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.5f))));
        return v;
    }

    public static String cap(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    public static String dur(long ms) {
        long s = ms / 1000;
        if (s >= 3600) return String.format(java.util.Locale.ITALY, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
        return String.format(java.util.Locale.ITALY, "%d:%02d", s / 60, s % 60);
    }
}
