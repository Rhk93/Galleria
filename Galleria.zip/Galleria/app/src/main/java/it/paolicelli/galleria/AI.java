package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Strumenti "IA" che funzionano sul telefono, senza internet:
// - Gomma magica: ricostruisce la zona cancellata copiando lo sfondo (PatchMatch multi-scala)
// - Rimasterizza: bilanciamento automatico, contrasto locale, nitidezza e colori

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

import java.util.Random;

public class AI {

    // =====================================================================
    //  GOMMA MAGICA
    // =====================================================================

    static final int R = 2; // raggio della patch (5x5)

    static final class Img {
        int w, h;
        int[] r, g, b;
        boolean[] hole;
        Img(int w, int h) {
            this.w = w; this.h = h;
            r = new int[w * h]; g = new int[w * h]; b = new int[w * h];
            hole = new boolean[w * h];
        }
    }

    /** src: immagine; mask: stessa dimensione, alpha > 0 = da cancellare. Restituisce una nuova bitmap. */
    public static Bitmap erase(Bitmap src, Bitmap mask) {
        int W = src.getWidth(), H = src.getHeight();
        int[] mp = new int[W * H];
        mask.getPixels(mp, 0, W, 0, 0, W, H);
        int x0 = W, y0 = H, x1 = -1, y1 = -1;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
                if ((mp[y * W + x] >>> 24) > 20) {
                    if (x < x0) x0 = x; if (x > x1) x1 = x;
                    if (y < y0) y0 = y; if (y > y1) y1 = y;
                }
        if (x1 < 0) return null;
        // zona di lavoro: il riquadro della maschera più un ampio margine da cui copiare
        int bw = x1 - x0 + 1, bh = y1 - y0 + 1;
        int m = (int) (Math.max(bw, bh) * 1.6f) + 48;
        Rect reg = new Rect(Math.max(0, x0 - m), Math.max(0, y0 - m), Math.min(W, x1 + m + 1), Math.min(H, y1 + m + 1));
        int rw = reg.width(), rh = reg.height();
        float sc = Math.min(1f, 560f / Math.max(rw, rh));
        int ww = Math.max(8, Math.round(rw * sc)), wh = Math.max(8, Math.round(rh * sc));

        Bitmap crop = Bitmap.createBitmap(src, reg.left, reg.top, rw, rh);
        Bitmap work = Bitmap.createScaledBitmap(crop, ww, wh, true);
        Bitmap mcrop = Bitmap.createBitmap(mask, reg.left, reg.top, rw, rh);
        Bitmap mwork = Bitmap.createScaledBitmap(mcrop, ww, wh, true);

        Img img = new Img(ww, wh);
        int[] px = new int[ww * wh], mk = new int[ww * wh];
        work.getPixels(px, 0, ww, 0, 0, ww, wh);
        mwork.getPixels(mk, 0, ww, 0, 0, ww, wh);
        for (int i = 0; i < px.length; i++) {
            img.r[i] = (px[i] >> 16) & 255; img.g[i] = (px[i] >> 8) & 255; img.b[i] = px[i] & 255;
            img.hole[i] = (mk[i] >>> 24) > 10;
        }
        img.hole = dilate(img.hole, ww, wh, 2);

        Img out = solve(img);
        if (out == null) return null;

        // risultato alla risoluzione della zona, poi fusione morbida con l'originale
        for (int i = 0; i < px.length; i++) px[i] = 0xFF000000 | (clamp(out.r[i]) << 16) | (clamp(out.g[i]) << 8) | clamp(out.b[i]);
        Bitmap filled = Bitmap.createBitmap(px, ww, wh, Bitmap.Config.ARGB_8888);
        Bitmap filledFull = Bitmap.createScaledBitmap(filled, rw, rh, true);

        int[] orig = new int[rw * rh], fill = new int[rw * rh], mm = new int[rw * rh];
        crop.getPixels(orig, 0, rw, 0, 0, rw, rh);
        filledFull.getPixels(fill, 0, rw, 0, 0, rw, rh);
        mcrop.getPixels(mm, 0, rw, 0, 0, rw, rh);
        int[] a = new int[rw * rh];
        for (int i = 0; i < a.length; i++) a[i] = (mm[i] >>> 24) > 10 ? 255 : 0;
        int feather = Math.max(2, Math.round(3 / sc));
        boolean[] ah = new boolean[a.length];
        for (int i = 0; i < a.length; i++) ah[i] = a[i] > 0;
        ah = dilate(ah, rw, rh, feather);
        for (int i = 0; i < a.length; i++) a[i] = ah[i] ? 255 : 0;
        a = boxBlur(a, rw, rh, feather);
        for (int i = 0; i < orig.length; i++) {
            int al = a[i];
            if (al <= 0) continue;
            int o = orig[i], f = fill[i];
            int rr = (((f >> 16) & 255) * al + ((o >> 16) & 255) * (255 - al)) / 255;
            int gg = (((f >> 8) & 255) * al + ((o >> 8) & 255) * (255 - al)) / 255;
            int bb = ((f & 255) * al + (o & 255) * (255 - al)) / 255;
            orig[i] = 0xFF000000 | (rr << 16) | (gg << 8) | bb;
        }
        Bitmap res = src.copy(Bitmap.Config.ARGB_8888, true);
        res.setPixels(orig, 0, rw, reg.left, reg.top, rw, rh);
        return res;
    }

    static Img down(Img a) {
        int w = Math.max(1, a.w / 2), h = Math.max(1, a.h / 2);
        Img o = new Img(w, h);
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int sr = 0, sg = 0, sb = 0, n = 0;
                boolean hl = false;
                for (int dy = 0; dy < 2; dy++)
                    for (int dx = 0; dx < 2; dx++) {
                        int xx = Math.min(a.w - 1, x * 2 + dx), yy = Math.min(a.h - 1, y * 2 + dy);
                        int i = yy * a.w + xx;
                        if (a.hole[i]) hl = true;
                        else { sr += a.r[i]; sg += a.g[i]; sb += a.b[i]; n++; }
                    }
                int j = y * w + x;
                o.hole[j] = hl;
                if (n > 0) { o.r[j] = sr / n; o.g[j] = sg / n; o.b[j] = sb / n; }
            }
        return o;
    }

    static Img solve(Img fine) {
        // piramide
        java.util.ArrayList<Img> pyr = new java.util.ArrayList<>();
        pyr.add(fine);
        while (pyr.size() < 6) {
            Img last = pyr.get(pyr.size() - 1);
            if (Math.min(last.w, last.h) < 48) break;
            pyr.add(down(last));
        }
        Random rnd = new Random(7);
        Img top = pyr.get(pyr.size() - 1);
        diffuse(top);
        int[] nnf = null;
        int prevW = 0;
        for (int L = pyr.size() - 1; L >= 0; L--) {
            Img im = pyr.get(L);
            if (L < pyr.size() - 1) {
                Img c = pyr.get(L + 1);
                for (int y = 0; y < im.h; y++)
                    for (int x = 0; x < im.w; x++) {
                        int i = y * im.w + x;
                        if (!im.hole[i]) continue;
                        int ci = Math.min(c.h - 1, y / 2) * c.w + Math.min(c.w - 1, x / 2);
                        im.r[i] = c.r[ci]; im.g[i] = c.g[ci]; im.b[i] = c.b[ci];
                    }
            }
            int[] r = em(im, rnd, nnf, prevW, L == pyr.size() - 1 ? 6 : 4);
            if (r == null) return null;
            nnf = r;
            prevW = im.w;
        }
        return fine;
    }

    /** Riempimento iniziale "a cipolla" dal bordo verso l'interno */
    static void diffuse(Img im) {
        int w = im.w, h = im.h;
        boolean[] known = new boolean[w * h];
        int unknown = 0;
        for (int i = 0; i < known.length; i++) { known[i] = !im.hole[i]; if (!known[i]) unknown++; }
        int guard = 0;
        while (unknown > 0 && guard++ < w + h) {
            boolean[] nk = known.clone();
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++) {
                    int i = y * w + x;
                    if (known[i]) continue;
                    int sr = 0, sg = 0, sb = 0, n = 0;
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx, yy = y + dy;
                            if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                            int j = yy * w + xx;
                            if (known[j]) { sr += im.r[j]; sg += im.g[j]; sb += im.b[j]; n++; }
                        }
                    if (n > 0) { im.r[i] = sr / n; im.g[i] = sg / n; im.b[i] = sb / n; nk[i] = true; unknown--; }
                }
            known = nk;
        }
    }

    /** Ciclo EM: PatchMatch + voto. Restituisce il campo delle corrispondenze (x | y<<16) */
    static int[] em(Img im, Random rnd, int[] prevNnf, int prevW, int iters) {
        int w = im.w, h = im.h;
        boolean[] dil = dilate(im.hole, w, h, R);
        // sorgenti valide: patch interamente dentro l'immagine e fuori dal buco
        int nValid = 0;
        boolean[] valid = new boolean[w * h];
        for (int y = R; y < h - R; y++)
            for (int x = R; x < w - R; x++) {
                int i = y * w + x;
                if (!dil[i]) { valid[i] = true; nValid++; }
            }
        if (nValid == 0) return null;
        int[] vlist = new int[nValid];
        int k = 0;
        for (int i = 0; i < valid.length; i++) if (valid[i]) vlist[k++] = i;
        // bersagli: pixel la cui patch tocca il buco
        int nT = 0;
        for (boolean d : dil) if (d) nT++;
        int[] tl = new int[nT];
        k = 0;
        for (int i = 0; i < dil.length; i++) if (dil[i]) tl[k++] = i;

        int[] nnf = new int[w * h];
        int[] dist = new int[w * h];
        for (int t : tl) {
            int tx = t % w, ty = t / w;
            int s = -1;
            if (prevNnf != null && prevW > 0) {
                int pw = prevW;
                int ph = prevNnf.length / pw;
                int cx = Math.min(pw - 1, tx / 2), cy = Math.min(ph - 1, ty / 2);
                int v = prevNnf[cy * pw + cx];
                if (v != 0) {
                    int sx = (v & 0xFFFF) * 2 + (tx & 1), sy = (v >>> 16) * 2 + (ty & 1);
                    if (sx >= 0 && sy >= 0 && sx < w && sy < h && valid[sy * w + sx]) s = sy * w + sx;
                }
            }
            if (s < 0) s = vlist[rnd.nextInt(nValid)];
            nnf[t] = (s % w) | ((s / w) << 16);
            dist[t] = patchDist(im, tx, ty, s % w, s / w, Integer.MAX_VALUE);
        }

        int maxR = Math.max(w, h);
        for (int it = 0; it < iters; it++) {
            for (int pass = 0; pass < 2; pass++) {
                boolean fwd = pass == 0;
                for (int q = 0; q < nT; q++) {
                    int t = tl[fwd ? q : nT - 1 - q];
                    int tx = t % w, ty = t / w;
                    int best = nnf[t], bd = dist[t];
                    // propagazione
                    int d1 = fwd ? -1 : 1;
                    for (int c = 0; c < 2; c++) {
                        int nx = c == 0 ? tx + d1 : tx, ny = c == 0 ? ty : ty + d1;
                        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                        int ni = ny * w + nx;
                        if (!dil[ni]) continue;
                        int v = nnf[ni];
                        int sx = (v & 0xFFFF) - (nx - tx), sy = (v >>> 16) - (ny - ty);
                        if (sx < 0 || sy < 0 || sx >= w || sy >= h || !valid[sy * w + sx]) continue;
                        int d = patchDist(im, tx, ty, sx, sy, bd);
                        if (d < bd) { bd = d; best = sx | (sy << 16); }
                    }
                    // ricerca casuale
                    int bx = best & 0xFFFF, by = best >>> 16;
                    for (int rad = maxR; rad >= 1; rad /= 2) {
                        int sx = bx + rnd.nextInt(2 * rad + 1) - rad, sy = by + rnd.nextInt(2 * rad + 1) - rad;
                        if (sx < 0 || sy < 0 || sx >= w || sy >= h || !valid[sy * w + sx]) continue;
                        int d = patchDist(im, tx, ty, sx, sy, bd);
                        if (d < bd) { bd = d; best = sx | (sy << 16); bx = sx; by = sy; }
                    }
                    nnf[t] = best;
                    dist[t] = bd;
                }
            }
            // voto: ogni pixel del buco = media dei pixel suggeriti dalle patch che lo coprono
            int n = w * h;
            int[] sr = new int[n], sg = new int[n], sb = new int[n], cnt = new int[n];
            for (int t : tl) {
                int tx = t % w, ty = t / w, v = nnf[t];
                int sx = v & 0xFFFF, sy = v >>> 16;
                for (int dy = -R; dy <= R; dy++) {
                    int yy = ty + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -R; dx <= R; dx++) {
                        int xx = tx + dx;
                        if (xx < 0 || xx >= w) continue;
                        int hi = yy * w + xx;
                        if (!im.hole[hi]) continue;
                        int si = (sy + dy) * w + (sx + dx);
                        sr[hi] += im.r[si]; sg[hi] += im.g[si]; sb[hi] += im.b[si]; cnt[hi]++;
                    }
                }
            }
            for (int i = 0; i < n; i++)
                if (im.hole[i] && cnt[i] > 0) { im.r[i] = sr[i] / cnt[i]; im.g[i] = sg[i] / cnt[i]; im.b[i] = sb[i] / cnt[i]; }
            for (int t : tl) { int v = nnf[t]; dist[t] = patchDist(im, t % w, t / w, v & 0xFFFF, v >>> 16, Integer.MAX_VALUE); }
        }
        return nnf;
    }

    static int patchDist(Img im, int tx, int ty, int sx, int sy, int limit) {
        int w = im.w, h = im.h, d = 0;
        for (int dy = -R; dy <= R; dy++) {
            int yy = Math.max(0, Math.min(h - 1, ty + dy));
            int so = (sy + dy) * w;
            for (int dx = -R; dx <= R; dx++) {
                int xx = Math.max(0, Math.min(w - 1, tx + dx));
                int ti = yy * w + xx, si = so + sx + dx;
                int a = im.r[ti] - im.r[si], b = im.g[ti] - im.g[si], c = im.b[ti] - im.b[si];
                d += a * a + b * b + c * c;
            }
            if (d >= limit) return d;
        }
        return d;
    }

    static boolean[] dilate(boolean[] m, int w, int h, int r) {
        boolean[] tmp = new boolean[m.length], o = new boolean[m.length];
        for (int y = 0; y < h; y++) {
            int last = -100000;
            for (int x = 0; x < w; x++) if (m[y * w + x]) last = x; else if (x - last <= r) tmp[y * w + x] = true;
            last = 100000;
            for (int x = w - 1; x >= 0; x--) if (m[y * w + x]) { last = x; tmp[y * w + x] = true; } else if (last - x <= r) tmp[y * w + x] = true;
        }
        for (int x = 0; x < w; x++) {
            int last = -100000;
            for (int y = 0; y < h; y++) if (tmp[y * w + x]) { last = y; o[y * w + x] = true; } else if (y - last <= r) o[y * w + x] = true;
            last = 100000;
            for (int y = h - 1; y >= 0; y--) if (tmp[y * w + x]) last = y; else if (last - y <= r) o[y * w + x] = true;
        }
        return o;
    }

    // =====================================================================
    //  RIMASTERIZZA
    // =====================================================================

    public static Bitmap remaster(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight(), n = w * h;
        int[] px = new int[n];
        src.getPixels(px, 0, w, 0, 0, w, h);
        int[] r = new int[n], g = new int[n], b = new int[n];
        long sr = 0, sg = 0, sb = 0;
        int[] hist = new int[256];
        for (int i = 0; i < n; i++) {
            int p = px[i];
            r[i] = (p >> 16) & 255; g[i] = (p >> 8) & 255; b[i] = p & 255;
            sr += r[i]; sg += g[i]; sb += b[i];
            hist[(r[i] * 77 + g[i] * 150 + b[i] * 29) >> 8]++;
        }
        // 1) bilanciamento del bianco (mondo grigio, a metà intensità)
        double ar = sr / (double) n, ag = sg / (double) n, ab = sb / (double) n, gray = (ar + ag + ab) / 3;
        double kr = 1 + 0.5 * (gray / Math.max(1, ar) - 1), kg = 1 + 0.5 * (gray / Math.max(1, ag) - 1), kb = 1 + 0.5 * (gray / Math.max(1, ab) - 1);
        // 2) livelli automatici: punto del nero e del bianco
        int lo = 0, hi = 255, acc = 0;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc > n * 0.004) { lo = i; break; } }
        acc = 0;
        for (int i = 255; i >= 0; i--) { acc += hist[i]; if (acc > n * 0.004) { hi = i; break; } }
        lo = Math.min(lo, 40); hi = Math.max(hi, 200);
        double scale = 255.0 / Math.max(1, hi - lo);
        int[] L = new int[n];
        for (int i = 0; i < n; i++) {
            r[i] = clamp((int) ((r[i] * kr - lo) * scale));
            g[i] = clamp((int) ((g[i] * kg - lo) * scale));
            b[i] = clamp((int) ((b[i] * kb - lo) * scale));
            L[i] = (r[i] * 77 + g[i] * 150 + b[i] * 29) >> 8;
        }
        // 3) contrasto locale (rende la foto più "viva")
        int big = Math.max(4, Math.max(w, h) / 45);
        int[] Lb = boxBlur(L, w, h, big);
        // 4) dettaglio fine (nitidezza con soglia contro il rumore)
        int[] Ls = boxBlur(L, w, h, 1);
        for (int i = 0; i < n; i++) {
            int add = (int) (0.35 * (L[i] - Lb[i]));
            int det = L[i] - Ls[i];
            if (Math.abs(det) > 3) add += (int) (0.8 * det);
            int rr = r[i] + add, gg = g[i] + add, bb = b[i] + add;
            // 5) vividezza: satura di più i colori spenti
            int mx = Math.max(rr, Math.max(gg, bb)), mn = Math.min(rr, Math.min(gg, bb));
            double sat = mx <= 0 ? 0 : (mx - mn) / (double) mx;
            double f = 1 + 0.28 * (1 - sat);
            int l = (rr * 77 + gg * 150 + bb * 29) >> 8;
            rr = (int) (l + (rr - l) * f); gg = (int) (l + (gg - l) * f); bb = (int) (l + (bb - l) * f);
            px[i] = 0xFF000000 | (clamp(rr) << 16) | (clamp(gg) << 8) | clamp(bb);
        }
        Bitmap o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        o.setPixels(px, 0, w, 0, 0, w, h);
        return o;
    }

    /** Sfocatura a scatola separabile, 3 passaggi (≈ gaussiana) */
    static int[] boxBlur(int[] in, int w, int h, int r) {
        int[] a = in.clone(), t = new int[in.length];
        for (int pass = 0; pass < 3; pass++) {
            for (int y = 0; y < h; y++) {
                int o = y * w, s = 0, win = 2 * r + 1;
                for (int x = -r; x <= r; x++) s += a[o + Math.max(0, Math.min(w - 1, x))];
                for (int x = 0; x < w; x++) {
                    t[o + x] = s / win;
                    s += a[o + Math.min(w - 1, x + r + 1)] - a[o + Math.max(0, x - r)];
                }
            }
            for (int x = 0; x < w; x++) {
                int s = 0, win = 2 * r + 1;
                for (int y = -r; y <= r; y++) s += t[Math.max(0, Math.min(h - 1, y)) * w + x];
                for (int y = 0; y < h; y++) {
                    a[y * w + x] = s / win;
                    s += t[Math.min(h - 1, y + r + 1) * w + x] - t[Math.max(0, y - r) * w + x];
                }
            }
        }
        return a;
    }

    static int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    /** Rasterizza un tratto di pennello in una maschera */
    public static Bitmap maskFrom(android.graphics.Path p, float width, int w, int h) {
        Bitmap m = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(m);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(0xFFFFFFFF);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(width);
        pt.setStrokeCap(Paint.Cap.ROUND);
        pt.setStrokeJoin(Paint.Join.ROUND);
        c.drawPath(p, pt);
        // chiude il contorno: se l'utente ha "cerchiato" l'oggetto, riempi anche l'interno
        android.graphics.RectF bnd = new android.graphics.RectF();
        p.computeBounds(bnd, true);
        return m;
    }

    // =====================================================================
    //  SELEZIONE DEI SOGGETTI
    // =====================================================================

    /** Divide una maschera (true = soggetto) in soggetti separati. Restituisce le etichette (0 = sfondo) */
    public static int[] components(boolean[] fg, int w, int h, int[] countOut) {
        int[] lab = new int[w * h];
        int next = 0;
        int min = Math.max(30, w * h / 400);
        int[] q = new int[w * h];
        for (int i = 0; i < fg.length; i++) {
            if (!fg[i] || lab[i] != 0) continue;
            int id = ++next, head = 0, tail = 0;
            q[tail++] = i; lab[i] = id;
            while (head < tail) {
                int c = q[head++], x = c % w, y = c / w;
                if (x > 0 && fg[c - 1] && lab[c - 1] == 0) { lab[c - 1] = id; q[tail++] = c - 1; }
                if (x < w - 1 && fg[c + 1] && lab[c + 1] == 0) { lab[c + 1] = id; q[tail++] = c + 1; }
                if (y > 0 && fg[c - w] && lab[c - w] == 0) { lab[c - w] = id; q[tail++] = c - w; }
                if (y < h - 1 && fg[c + w] && lab[c + w] == 0) { lab[c + w] = id; q[tail++] = c + w; }
            }
            if (tail < min) { for (int k = 0; k < tail; k++) lab[q[k]] = 0; next--; }
        }
        // rinumera in modo compatto
        countOut[0] = next;
        return lab;
    }

    /** Selezione automatica di un oggetto toccato: crescita della regione per colore, fermandosi sui bordi */
    public static boolean[] grow(Bitmap bmp, int sx, int sy) {
        int w = bmp.getWidth(), h = bmp.getHeight(), n = w * h;
        int[] px = new int[n];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        int[] L = new int[n];
        for (int i = 0; i < n; i++) { int p = px[i]; L[i] = (((p >> 16) & 255) * 77 + ((p >> 8) & 255) * 150 + (p & 255) * 29) >> 8; }
        // intensità dei bordi
        int[] edge = new int[n];
        for (int y = 1; y < h - 1; y++)
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                int gx = L[i + 1] - L[i - 1], gy = L[i + w] - L[i - w];
                edge[i] = Math.abs(gx) + Math.abs(gy);
            }
        sx = Math.max(0, Math.min(w - 1, sx)); sy = Math.max(0, Math.min(h - 1, sy));
        int seed = sy * w + sx;
        // colore medio intorno al punto toccato
        long ar = 0, ag = 0, ab = 0; int cnt = 0;
        for (int dy = -3; dy <= 3; dy++) for (int dx = -3; dx <= 3; dx++) {
            int xx = Math.max(0, Math.min(w - 1, sx + dx)), yy = Math.max(0, Math.min(h - 1, sy + dy));
            int p = px[yy * w + xx];
            ar += (p >> 16) & 255; ag += (p >> 8) & 255; ab += p & 255; cnt++;
        }
        double mr = ar / (double) cnt, mg = ag / (double) cnt, mb = ab / (double) cnt;
        boolean[] in = new boolean[n];
        int[] q = new int[n];
        int head = 0, tail = 0, limit = n * 6 / 10;
        q[tail++] = seed; in[seed] = true;
        double tol = 42;
        while (head < tail && tail < limit) {
            int c = q[head++], x = c % w, y = c / w;
            int[] nb = {x > 0 ? c - 1 : -1, x < w - 1 ? c + 1 : -1, y > 0 ? c - w : -1, y < h - 1 ? c + w : -1};
            for (int j : nb) {
                if (j < 0 || in[j]) continue;
                int p = px[j];
                double dr = ((p >> 16) & 255) - mr, dg = ((p >> 8) & 255) - mg, db = (p & 255) - mb;
                double d = Math.sqrt(dr * dr + dg * dg + db * db);
                if (d < tol && edge[j] < 70) {
                    in[j] = true; q[tail++] = j;
                    // il colore medio si adatta lentamente (sfumature dello stesso oggetto)
                    mr += (((p >> 16) & 255) - mr) * 0.002; mg += (((p >> 8) & 255) - mg) * 0.002; mb += ((p & 255) - mb) * 0.002;
                }
            }
        }
        if (tail >= limit) return null; // ha invaso quasi tutta la foto: probabilmente è lo sfondo
        in = fillHoles(in, w, h);
        return dilate(in, w, h, Math.max(2, Math.max(w, h) / 250));
    }

    /** Riempie i "buchi" interni di una selezione */
    public static boolean[] fillHoles(boolean[] m, int w, int h) {
        boolean[] out = new boolean[m.length];
        int[] q = new int[m.length];
        int head = 0, tail = 0;
        for (int x = 0; x < w; x++) { for (int y : new int[]{0, h - 1}) { int i = y * w + x; if (!m[i] && !out[i]) { out[i] = true; q[tail++] = i; } } }
        for (int y = 0; y < h; y++) { for (int x : new int[]{0, w - 1}) { int i = y * w + x; if (!m[i] && !out[i]) { out[i] = true; q[tail++] = i; } } }
        while (head < tail) {
            int c = q[head++], x = c % w, y = c / w;
            int[] nb = {x > 0 ? c - 1 : -1, x < w - 1 ? c + 1 : -1, y > 0 ? c - w : -1, y < h - 1 ? c + w : -1};
            for (int j : nb) if (j >= 0 && !m[j] && !out[j]) { out[j] = true; q[tail++] = j; }
        }
        boolean[] r = new boolean[m.length];
        for (int i = 0; i < m.length; i++) r[i] = !out[i];
        return r;
    }

    /** Maschera booleana → bitmap (bianco = da cancellare) */
    public static Bitmap toMask(boolean[] m, int w, int h) {
        int[] px = new int[w * h];
        for (int i = 0; i < px.length; i++) px[i] = m[i] ? 0xFFFFFFFF : 0;
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        b.setPixels(px, 0, w, 0, 0, w, h);
        return b;
    }

    /** Colora una maschera per mostrarla sopra la foto */
    public static Bitmap tint(boolean[] m, int[] lab, int w, int h, int colorSel, int colorOther) {
        int[] px = new int[w * h];
        for (int i = 0; i < px.length; i++) px[i] = (m != null && m[i]) ? colorSel : (lab != null && lab[i] != 0 ? colorOther : 0);
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        b.setPixels(px, 0, w, 0, 0, w, h);
        return b;
    }

    /** Riempie un contorno disegnato a mano */
    public static Bitmap lassoMask(android.graphics.Path p, float stroke, int w, int h) {
        Bitmap m = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(m);
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(0xFFFFFFFF);
        android.graphics.Path closed = new android.graphics.Path(p);
        closed.close();
        pt.setStyle(Paint.Style.FILL_AND_STROKE);
        pt.setStrokeWidth(stroke);
        c.drawPath(closed, pt);
        return m;
    }
}
