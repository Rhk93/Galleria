package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Scorrimento tra le foto che segue il dito, come su iPhone

import android.animation.ValueAnimator;
import android.content.Context;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

import java.util.ArrayList;

public class Pager extends FrameLayout {

    public interface L {
        void onPage(int index);
        void onDismissDrag(float dx, float dy, float frac);
        void onDismissRelease(boolean close, float vy);
    }

    final Pagina[] pages = new Pagina[3];
    ArrayList<Media.Item> list = new ArrayList<>();
    int index = 0;
    float offset = 0;
    final int gap, slop;
    float x0, y0, lastX;
    boolean dragH = false, dragV = false;
    VelocityTracker vt;
    ValueAnimator settle;
    L l;
    public boolean locked = false;

    public Pager(Context c) {
        super(c);
        gap = Ui.dp(c, 22);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        for (int i = 0; i < 3; i++) {
            pages[i] = new Pagina(c);
            addView(pages[i], new LayoutParams(-1, -1));
        }
    }

    public void setListener(L l) { this.l = l; }

    public Pagina cur() { return pages[1]; }

    public Media.Item item() { return list.isEmpty() ? null : list.get(index); }

    Media.Item at(int i) { return i >= 0 && i < list.size() ? list.get(i) : null; }

    public void setList(ArrayList<Media.Item> l, int idx) {
        list = l;
        jumpTo(idx, true);
    }

    /** Salta a una posizione (full=false: solo miniature, per lo scorrimento veloce) */
    public void jumpTo(int idx, boolean full) {
        if (settle != null) settle.cancel();
        idx = Math.max(0, Math.min(idx, list.size() - 1));
        boolean changed = idx != index || pages[1].item != at(idx);
        if (changed) pages[1].deactivate();
        index = idx;
        offset = 0;
        pages[1].bind(at(index), full);
        pages[0].bind(at(index - 1), full);
        pages[2].bind(at(index + 1), full);
        layoutPages();
        if (full) pages[1].activate();
        if (changed && l != null) l.onPage(index);
    }

    void layoutPages() {
        float w = getWidth() + gap;
        for (int i = 0; i < 3; i++) pages[i].setTranslationX((i - 1) * w + offset);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        layoutPages();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        if (locked) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                x0 = e.getX(); y0 = e.getY(); lastX = x0;
                dragH = dragV = false;
                if (vt != null) vt.recycle();
                vt = VelocityTracker.obtain();
                vt.addMovement(e);
                if (settle != null && settle.isRunning()) {
                    settle.cancel();
                    dragH = true;
                    return true;
                }
                return false;
            case MotionEvent.ACTION_MOVE:
                if (e.getPointerCount() > 1) return false;
                if (vt != null) vt.addMovement(e);
                float dx = e.getX() - x0, dy = e.getY() - y0;
                Pagina p = pages[1];
                if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.1f && p.img.canSwipe(dx)) {
                    dragH = true; lastX = e.getX();
                    return true;
                }
                if (dy > slop && dy > Math.abs(dx) * 1.1f && p.img.zoom() <= 1.02f) {
                    dragV = true;
                    return true;
                }
                return false;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (vt != null) vt.addMovement(e);
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_MOVE) {
            if (dragH) {
                float d = e.getX() - lastX;
                lastX = e.getX();
                boolean edge = (offset + d > 0 && at(index - 1) == null) || (offset + d < 0 && at(index + 1) == null);
                offset += edge ? d * 0.35f : d;
                layoutPages();
            } else if (dragV) {
                float dx = e.getX() - x0, dy = e.getY() - y0;
                float frac = Math.max(0, Math.min(1, dy / (getHeight() * 0.35f)));
                Pagina p = pages[1];
                float s = 1f - 0.35f * Math.max(0, Math.min(1, dy / getHeight()));
                p.setTranslationX(dx);
                p.setTranslationY(dy);
                p.setScaleX(s); p.setScaleY(s);
                if (l != null) l.onDismissDrag(dx, dy, frac);
            }
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            float vx = 0, vy = 0;
            if (vt != null) { vt.computeCurrentVelocity(1000); vx = vt.getXVelocity(); vy = vt.getYVelocity(); vt.recycle(); vt = null; }
            if (dragH) {
                float w = getWidth() + gap;
                int dir = 0;
                if ((offset < -getWidth() / 2f || (vx < -700 && offset < 0)) && at(index + 1) != null) dir = 1;
                else if ((offset > getWidth() / 2f || (vx > 700 && offset > 0)) && at(index - 1) != null) dir = -1;
                settleTo(-dir * w, dir, vx);
            } else if (dragV) {
                float dy = e.getY() - y0;
                boolean close = dy > getHeight() * 0.1f || vy > 900;
                if (l != null) l.onDismissRelease(close, vy);
            }
            dragH = dragV = false;
            return true;
        }
        return true;
    }

    void settleTo(float target, int dir, float vx) {
        if (settle != null) settle.cancel();
        float start = offset;
        float dist = Math.abs(target - start);
        long dur = (long) Math.max(160, Math.min(380, dist / Math.max(1, getWidth()) * 420));
        if (Math.abs(vx) > 1500) dur = Math.max(140, (long) (dur * 0.7f));
        settle = ValueAnimator.ofFloat(start, target);
        settle.setDuration(dur);
        settle.setInterpolator(Ui.EASE);
        settle.addUpdateListener(an -> { offset = (float) an.getAnimatedValue(); layoutPages(); });
        settle.addListener(new android.animation.AnimatorListenerAdapter() {
            boolean cancelled = false;
            @Override public void onAnimationCancel(android.animation.Animator x) { cancelled = true; }
            @Override public void onAnimationEnd(android.animation.Animator x) {
                if (cancelled) return;
                if (dir != 0) shift(dir);
            }
        });
        settle.start();
    }

    /** Avanza/indietreggia ruotando le 3 pagine senza ricaricare */
    void shift(int dir) {
        pages[1].deactivate();
        if (dir > 0) {
            Pagina p0 = pages[0];
            pages[0] = pages[1]; pages[1] = pages[2]; pages[2] = p0;
            index++;
            pages[2].bind(at(index + 1), true);
        } else {
            Pagina p2 = pages[2];
            pages[2] = pages[1]; pages[1] = pages[0]; pages[0] = p2;
            index--;
            pages[0].bind(at(index - 1), true);
        }
        offset = 0;
        layoutPages();
        pages[1].bind(at(index), true);
        pages[1].activate();
        if (l != null) l.onPage(index);
    }

    public void next(boolean animated) {
        if (at(index + 1) == null) return;
        if (animated) settleTo(-(getWidth() + gap), 1, 0);
        else jumpTo(index + 1, true);
    }

    /** Rimuove l'elemento corrente (dopo eliminazione/nascondi) */
    public void removeCurrent() {
        if (list.isEmpty()) return;
        list.remove(index);
        pages[1].item = null;
        if (list.isEmpty()) return;
        jumpTo(Math.min(index, list.size() - 1), true);
        if (l != null) l.onPage(index);
    }

    public void releaseAll() {
        for (Pagina p : pages) p.releaseVideo();
    }
}
