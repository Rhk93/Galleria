package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Visore a tutto schermo stile Foto di iPhone

import android.Manifest;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ViewerActivity extends Activity implements Media.Done {

    static final int REQ_TRASH = 1, REQ_FAV = 2, REQ_RESTORE = 3, REQ_DEL = 4, REQ_EDIT = 5;
    public static final int MODE_NORMAL = 0, MODE_TRASH = 1, MODE_HIDDEN = 2;

    /** Fornito dalla griglia: dove si trova la miniatura di un elemento */
    public interface Rects {
        Rect rect(Media.Item it);
        void reveal(Media.Item it);
    }
    public static Rects rects;

    ArrayList<Media.Item> list;
    int mode;
    String album;
    FrameLayout root;
    View backdrop;
    Pager pager;
    Striscia film;
    LinearLayout top, bottom, videoBar;
    ImageView heart, playBtn, muteBtn;
    SeekBar vSeek;
    TextView title, sub, vTime;
    boolean barsOn = true, sliding = false, fromStrip = false, closing = false, seeking = false;
    int bgColor;
    float bgAlpha = 1f;
    final Handler h = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        list = new ArrayList<>(Media.current);
        if (list.isEmpty()) { finish(); return; }
        int index = Math.max(0, Math.min(getIntent().getIntExtra("index", 0), list.size() - 1));
        mode = getIntent().getIntExtra("mode", MODE_NORMAL);
        album = getIntent().getStringExtra("album");
        bgColor = Ui.BG;

        root = new FrameLayout(this);
        backdrop = new View(this);
        backdrop.setBackgroundColor(bgColor);
        root.addView(backdrop, new FrameLayout.LayoutParams(-1, -1));
        pager = new Pager(this);
        root.addView(pager, new FrameLayout.LayoutParams(-1, -1));

        // ---- barra in alto ----
        top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView back = Ui.circleIcon(this, "back", Ui.TEXT);
        back.setOnClickListener(v -> close());
        top.addView(back);
        LinearLayout tt = new LinearLayout(this);
        tt.setOrientation(LinearLayout.VERTICAL);
        tt.setGravity(Gravity.CENTER);
        title = Ui.text(this, "", 16, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        sub = Ui.text(this, "", 12, Ui.TEXT2, false);
        sub.setGravity(Gravity.CENTER);
        tt.addView(title);
        tt.addView(sub);
        top.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView more = Ui.circleIcon(this, "more", Ui.TEXT);
        more.setOnClickListener(this::moreMenu);
        top.addView(more);
        root.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // ---- parte bassa: comandi video + striscia + pulsanti ----
        bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);

        videoBar = new LinearLayout(this);
        videoBar.setGravity(Gravity.CENTER_VERTICAL);
        int vp = Ui.dp(this, 10);
        videoBar.setPadding(vp, vp / 2, vp, vp / 2);
        videoBar.setBackground(Ui.round(Ui.dark ? 0xCC2C2C2E : 0xE6F2F2F7, Ui.dp(this, 22)));
        playBtn = Ui.icon(this, "pause", Ui.TEXT, 22);
        playBtn.setOnClickListener(v -> { pager.cur().togglePlay(); updateVideoBar(); });
        Ui.press(playBtn);
        videoBar.addView(playBtn);
        vSeek = new SeekBar(this);
        vSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) { if (user) pager.cur().seek(v); }
            @Override public void onStartTrackingTouch(SeekBar s) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { seeking = false; }
        });
        videoBar.addView(vSeek, new LinearLayout.LayoutParams(0, -2, 1f));
        vTime = Ui.text(this, "0:00", 13, Ui.TEXT, true);
        videoBar.addView(vTime);
        muteBtn = Ui.icon(this, Pagina.muted ? "mute" : "volume", Ui.TEXT, 22);
        LinearLayout.LayoutParams ml = (LinearLayout.LayoutParams) muteBtn.getLayoutParams();
        ml.leftMargin = Ui.dp(this, 10);
        muteBtn.setOnClickListener(v -> {
            pager.cur().setMuted(!Pagina.muted);
            muteBtn.setImageDrawable(new Icon(Pagina.muted ? "mute" : "volume", Ui.TEXT));
        });
        Ui.press(muteBtn);
        videoBar.addView(muteBtn);
        LinearLayout.LayoutParams vbl = new LinearLayout.LayoutParams(-1, -2);
        vbl.setMargins(Ui.dp(this, 14), 0, Ui.dp(this, 14), Ui.dp(this, 6));
        bottom.addView(videoBar, vbl);
        videoBar.setVisibility(View.GONE);

        film = new Striscia(this);
        bottom.addView(film, new LinearLayout.LayoutParams(-1, Ui.dp(this, 50)));

        LinearLayout btns = new LinearLayout(this);
        btns.setGravity(Gravity.CENTER_VERTICAL);
        int m = Ui.dp(this, 14);
        btns.setPadding(m, Ui.dp(this, 6), m, Ui.dp(this, 8));
        if (mode == MODE_TRASH) {
            TextView del = Ui.pill(this, "Elimina");
            del.setTextColor(Ui.RED);
            del.setOnClickListener(v -> confirm("Elimina definitivamente", "Questo elemento verrà eliminato per sempre.", "Elimina",
                    () -> Media.deleteForever(this, one(), REQ_DEL)));
            TextView rec = Ui.pill(this, "Recupera");
            rec.setTextColor(Ui.BLUE);
            rec.setOnClickListener(v -> Media.restore(this, one(), REQ_RESTORE));
            btns.addView(del);
            btns.addView(Ui.space(this));
            btns.addView(rec);
        } else {
            ImageView share = Ui.circleIcon(this, "share", Ui.TEXT);
            share.setOnClickListener(v -> Media.share(this, one()));
            heart = Ui.circleIcon(this, "heart", Ui.TEXT);
            heart.setOnClickListener(v -> {
                heart.animate().scaleX(1.25f).scaleY(1.25f).setDuration(110).withEndAction(() ->
                        heart.animate().scaleX(1).scaleY(1).setDuration(260).setInterpolator(new android.view.animation.OvershootInterpolator(3)).start()).start();
                Media.setFavorite(this, one(), !cur().fav, REQ_FAV);
            });
            ImageView info = Ui.circleIcon(this, "info", Ui.TEXT);
            info.setOnClickListener(v -> showInfo());
            ImageView edit = Ui.circleIcon(this, "edit", Ui.TEXT);
            edit.setOnClickListener(v -> edit());
            ImageView trash = Ui.circleIcon(this, "trash", Ui.TEXT);
            trash.setOnClickListener(v -> Media.trash(this, one(), REQ_TRASH));
            View[] vs = {share, heart, info, edit, trash};
            for (int i = 0; i < vs.length; i++) {
                if (i > 0) btns.addView(Ui.space(this));
                btns.addView(vs[i]);
            }
        }
        bottom.addView(btns);
        root.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        root.setOnApplyWindowInsetsListener((v, ins) -> {
            Ui.readInsets(ins);
            applyInsets();
            return ins;
        });
        applyInsets();

        // ---- collegamenti ----
        pager.setListener(new Pager.L() {
            @Override public void onPage(int i) {
                updateTitle();
                if (!fromStrip) film.moveTo(i);
                updateVideoBar();
            }
            @Override public void onDismissDrag(float dx, float dy, float frac) {
                setBg(1f - frac);
                float a = barsOn ? Math.max(0, 1f - frac * 2.5f) : 0;
                top.setAlpha(a); bottom.setAlpha(a);
            }
            @Override public void onDismissRelease(boolean close, float vy) {
                if (close) close();
                else {
                    Pagina p = pager.cur();
                    morph(p, 1, 0, 0, -1, -1, 1, 260, null);
                    top.animate().alpha(barsOn ? 1 : 0).setDuration(200).start();
                    bottom.animate().alpha(barsOn ? 1 : 0).setDuration(200).start();
                }
            }
        });
        for (Pagina p : pager.pages) p.img.setTap(() -> { if (sliding) stopSlide(); else setBars(!barsOn); });
        Pagina.videoCb = p -> updateVideoBar();
        film.setListener(new Striscia.L() {
            @Override public void onScrub(int i) { fromStrip = true; pager.jumpTo(i, false); fromStrip = false; }
            @Override public void onScrubEnd(int i) { fromStrip = true; pager.jumpTo(i, true); fromStrip = false; }
        });

        setContentView(root);
        Ui.edge(this, Ui.dark, false);
        film.setItems(list, index);
        pager.setList(list, index);
        updateTitle();
        updateVideoBar();

        // animazione di apertura dalla miniatura
        int[] r = getIntent().getIntArrayExtra("rect");
        setBg(0);
        top.setAlpha(0); bottom.setAlpha(0);
        pager.setAlpha(0);
        root.post(() -> enter(r == null ? null : new Rect(r[0], r[1], r[2], r[3])));
        if (getIntent().getBooleanExtra("slide", false)) h.postDelayed(this::startSlide, 700);
        h.post(tick);
    }

    void applyInsets() {
        int m = Ui.dp(this, 12);
        top.setPadding(m, Ui.top + Ui.dp(this, 6), m, Ui.dp(this, 8));
        bottom.setPadding(0, Ui.dp(this, 4), 0, Ui.bottom + Ui.dp(this, 4));
    }

    Media.Item cur() { return pager.item(); }

    List<Media.Item> one() { return Collections.singletonList(cur()); }

    // ---------- Sfondo e barre ----------

    void setBg(float a) {
        bgAlpha = a;
        backdrop.setBackgroundColor(bgColor);
        backdrop.setAlpha(a);
    }

    void setBars(boolean on) {
        barsOn = on;
        top.animate().alpha(on ? 1 : 0).setDuration(200).start();
        bottom.animate().alpha(on ? 1 : 0).setDuration(200).start();
        if (on) { top.setVisibility(View.VISIBLE); bottom.setVisibility(View.VISIBLE); }
        h.postDelayed(() -> {
            if (!barsOn) { top.setVisibility(View.INVISIBLE); bottom.setVisibility(View.INVISIBLE); }
        }, 210);
        int from = bgColor, to = on ? Ui.BG : 0xFF000000;
        ValueAnimator va = ValueAnimator.ofObject(new ArgbEvaluator(), from, to);
        va.setDuration(220);
        va.addUpdateListener(a -> { bgColor = (int) a.getAnimatedValue(); backdrop.setBackgroundColor(bgColor); });
        va.start();
        Ui.edge(this, !on || Ui.dark, !on);
    }

    // ---------- Animazioni di apertura e chiusura (stile iOS) ----------

    float clipW = -1, clipH = -1;
    ValueAnimator morphAnim;

    /** Porta la pagina a scala/spostamento/ritaglio indicati. cw/ch = -1: nessun ritaglio */
    void morph(Pagina p, float s1, float tx1, float ty1, float cw1, float ch1, float bg1, long dur, Runnable end) {
        if (morphAnim != null) morphAnim.cancel();
        final float s0 = p.getScaleX(), tx0 = p.getTranslationX(), ty0 = p.getTranslationY(), bg0 = bgAlpha;
        final float W = p.getWidth(), H = p.getHeight();
        final float cw0 = clipW < 0 ? W : clipW, ch0 = clipH < 0 ? H : clipH;
        final float cwT = cw1 < 0 ? W : cw1, chT = ch1 < 0 ? H : ch1;
        morphAnim = ValueAnimator.ofFloat(0, 1);
        morphAnim.setDuration(dur);
        morphAnim.setInterpolator(Ui.EASE);
        morphAnim.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            float s = s0 + (s1 - s0) * t;
            p.setScaleX(s); p.setScaleY(s);
            p.setTranslationX(tx0 + (tx1 - tx0) * t);
            p.setTranslationY(ty0 + (ty1 - ty0) * t);
            clipW = cw0 + (cwT - cw0) * t;
            clipH = ch0 + (chT - ch0) * t;
            p.setClipBounds(new Rect((int) ((W - clipW) / 2), (int) ((H - clipH) / 2), (int) ((W + clipW) / 2), (int) ((H + clipH) / 2)));
            setBg(bg0 + (bg1 - bg0) * t);
        });
        morphAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            boolean c = false;
            @Override public void onAnimationCancel(android.animation.Animator x) { c = true; }
            @Override public void onAnimationEnd(android.animation.Animator x) {
                if (c) return;
                if (cw1 < 0) { p.setClipBounds(null); clipW = clipH = -1; }
                if (end != null) end.run();
            }
        });
        morphAnim.start();
    }

    /** Stato "miniatura" per una pagina: {scala, tx, ty, clipW, clipH} */
    float[] thumbState(Pagina p, Rect t) {
        RectF f = p.img.fitRect();
        if (t == null || f == null || f.width() <= 0 || p.getWidth() == 0) return null;
        int[] loc = new int[2];
        root.getLocationOnScreen(loc);
        Rect r = new Rect(t);
        r.offset(-loc[0], -loc[1]);
        float s = Math.max(r.width() / f.width(), r.height() / f.height());
        float tx = r.exactCenterX() - p.getWidth() / 2f, ty = r.exactCenterY() - p.getHeight() / 2f;
        return new float[]{s, tx, ty, r.width() / s, r.height() / s};
    }

    void enter(Rect t) {
        Pagina p = pager.cur();
        pager.setAlpha(1);
        float[] st = thumbState(p, t);
        if (st == null) {
            p.setScaleX(0.92f); p.setScaleY(0.92f); p.setAlpha(0);
            p.animate().scaleX(1).scaleY(1).alpha(1).setDuration(300).setInterpolator(Ui.EASE).start();
            morph(p, 1, 0, 0, -1, -1, 1, 300, null);
        } else {
            p.setScaleX(st[0]); p.setScaleY(st[0]);
            p.setTranslationX(st[1]); p.setTranslationY(st[2]);
            clipW = st[3]; clipH = st[4];
            morph(p, 1, 0, 0, -1, -1, 1, 420, null);
        }
        top.animate().alpha(1).setDuration(300).start();
        bottom.animate().alpha(1).setDuration(300).start();
    }

    void close() {
        if (closing) return;
        closing = true;
        stopSlide();
        Pagina p = pager.cur();
        p.pauseVideo();
        Media.Item it = cur();
        if (rects != null && it != null) rects.reveal(it);
        top.animate().alpha(0).setDuration(150).start();
        bottom.animate().alpha(0).setDuration(150).start();
        h.postDelayed(() -> {
            Rect t = rects != null && it != null ? rects.rect(it) : null;
            p.img.reset();
            float[] st = thumbState(p, t);
            if (st == null) {
                p.animate().alpha(0).scaleX(p.getScaleX() * 0.85f).scaleY(p.getScaleY() * 0.85f).setDuration(220).start();
                morph(p, p.getScaleX() * 0.85f, p.getTranslationX(), p.getTranslationY(), -1, -1, 0, 230, this::finishNow);
            } else {
                morph(p, st[0], st[1], st[2], st[3], st[4], 0, 340, this::finishNow);
            }
        }, rects != null ? 50 : 0);
    }

    void finishNow() {
        pager.releaseAll();
        finish();
        overridePendingTransition(0, 0);
    }

    @Override public void onBackPressed() { close(); }

    // ---------- Titolo e comandi video ----------

    void updateTitle() {
        Media.Item it = cur();
        if (it == null) return;
        String t;
        if (DateUtils.isToday(it.date)) t = "Oggi";
        else if (DateUtils.isToday(it.date + DateUtils.DAY_IN_MILLIS)) t = "Ieri";
        else if (System.currentTimeMillis() - it.date < 6 * DateUtils.DAY_IN_MILLIS) t = Ui.cap(new SimpleDateFormat("EEEE", Media.IT).format(it.date));
        else t = new SimpleDateFormat("d MMMM yyyy", Media.IT).format(it.date);
        title.setText(t);
        sub.setText(new SimpleDateFormat("HH:mm", Media.IT).format(it.date));
        if (heart != null) heart.setImageDrawable(new Icon(it.fav ? "heartfill" : "heart", it.fav ? Ui.BLUE : Ui.TEXT));
    }

    void updateVideoBar() {
        Media.Item it = cur();
        boolean v = it != null && it.video && mode != MODE_TRASH;
        videoBar.setVisibility(v ? View.VISIBLE : View.GONE);
        if (!v) return;
        Pagina p = pager.cur();
        playBtn.setImageDrawable(new Icon(p.isPlaying() ? "pause" : "play", Ui.TEXT));
        int d = p.duration();
        vSeek.setMax(Math.max(1, d));
        if (!seeking) vSeek.setProgress(p.position());
        vTime.setText(Ui.dur(Math.max(0, d - p.position())));
    }

    final Runnable tick = new Runnable() {
        @Override public void run() {
            Media.Item it = cur();
            if (it != null && it.video && !isFinishing()) {
                Pagina p = pager.cur();
                if (!seeking) vSeek.setProgress(p.position());
                vTime.setText(Ui.dur(Math.max(0, p.duration() - p.position())));
                playBtn.setImageDrawable(new Icon(p.isPlaying() ? "pause" : "play", Ui.TEXT));
            }
            h.postDelayed(this, 250);
        }
    };

    @Override protected void onPause() {
        super.onPause();
        if (pager != null) pager.cur().pauseVideo();
    }

    // ---------- Presentazione ----------

    final Runnable slideStep = new Runnable() {
        @Override public void run() {
            if (!sliding) return;
            int n = pager.index + 1 >= list.size() ? 0 : pager.index + 1;
            Pagina old = pager.cur();
            old.animate().cancel();
            old.setScaleX(1); old.setScaleY(1);
            pager.jumpTo(n, true);
            Pagina p = pager.cur();
            p.setAlpha(0f);
            p.setScaleX(1f); p.setScaleY(1f);
            p.animate().alpha(1).setDuration(700).start();
            kenBurns(p);
            h.postDelayed(this, 3800);
        }
    };

    void kenBurns(Pagina p) {
        ValueAnimator k = ValueAnimator.ofFloat(1f, 1.1f);
        k.setDuration(4200);
        k.setInterpolator(new LinearInterpolator());
        k.addUpdateListener(a -> {
            if (!sliding) { a.cancel(); return; }
            float s = (float) a.getAnimatedValue();
            p.setScaleX(s); p.setScaleY(s);
        });
        k.start();
    }

    void startSlide() {
        if (sliding) return;
        sliding = true;
        pager.locked = true;
        setBars(false);
        kenBurns(pager.cur());
        h.postDelayed(slideStep, 3800);
        Toast.makeText(this, "Presentazione: tocca per fermare", Toast.LENGTH_SHORT).show();
    }

    void stopSlide() {
        if (!sliding) return;
        sliding = false;
        pager.locked = false;
        h.removeCallbacks(slideStep);
        Pagina p = pager.cur();
        p.animate().scaleX(1).scaleY(1).alpha(1).setDuration(250).start();
        setBars(true);
    }

    // ---------- Menu ----------

    void moreMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu mn = pm.getMenu();
        if (mode != MODE_TRASH) {
            mn.add(0, 1, 0, "Presentazione");
            mn.add(0, 2, 0, "Aggiungi ad album");
            if (album != null) mn.add(0, 3, 0, "Rimuovi dall'album");
            mn.add(0, 4, 0, mode == MODE_HIDDEN ? "Mostra" : "Nascondi");
            mn.add(0, 5, 0, "Duplica");
            if (!cur().video) mn.add(0, 6, 0, "Usa come sfondo");
            mn.add(0, 7, 0, "Apri con…");
        }
        mn.add(0, 8, 0, "Informazioni");
        pm.setOnMenuItemClickListener(mi -> {
            switch (mi.getItemId()) {
                case 1: startSlide(); break;
                case 2: pickAlbum(this, one(), null); break;
                case 3:
                    Media.removeFromAlbum(this, album, one());
                    removeCurrent();
                    break;
                case 4:
                    Media.setHidden(this, one(), mode != MODE_HIDDEN);
                    Toast.makeText(this, mode == MODE_HIDDEN ? "Mostrato nella Libreria" : "Spostato in Nascosti", Toast.LENGTH_SHORT).show();
                    removeCurrent();
                    break;
                case 5: duplicate(); break;
                case 6: {
                    Intent i = new Intent(Intent.ACTION_ATTACH_DATA);
                    i.setDataAndType(cur().uri, cur().mime.isEmpty() ? "image/*" : cur().mime);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(i, "Usa come")); } catch (Exception ignored) { }
                    break;
                }
                case 7: {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(cur().uri, cur().mime.isEmpty() ? "*/*" : cur().mime);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(i, "Apri con")); } catch (Exception ignored) { }
                    break;
                }
                case 8: showInfo(); break;
            }
            return true;
        });
        pm.show();
    }

    /** Scegli o crea un album dell'app e aggiungi gli elementi */
    public static void pickAlbum(Activity a, List<Media.Item> items, Runnable after) {
        ArrayList<String> names = Media.albumNames(a);
        names.add("+ Nuovo album…");
        new AlertDialog.Builder(a)
                .setTitle("Aggiungi ad album")
                .setItems(names.toArray(new String[0]), (d, w) -> {
                    if (w == names.size() - 1) {
                        newAlbum(a, n -> {
                            Media.addToAlbum(a, n, items);
                            Toast.makeText(a, "Aggiunto a \"" + n + "\"", Toast.LENGTH_SHORT).show();
                            if (after != null) after.run();
                        });
                    } else {
                        Media.addToAlbum(a, names.get(w), items);
                        Toast.makeText(a, "Aggiunto a \"" + names.get(w) + "\"", Toast.LENGTH_SHORT).show();
                        if (after != null) after.run();
                    }
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    public interface Named { void got(String name); }

    public static void newAlbum(Activity a, Named cb) {
        EditText et = new EditText(a);
        et.setHint("Titolo");
        et.setSingleLine(true);
        FrameLayout f = new FrameLayout(a);
        int p = Ui.dp(a, 20);
        f.setPadding(p, Ui.dp(a, 8), p, 0);
        f.addView(et);
        new AlertDialog.Builder(a)
                .setTitle("Nuovo album")
                .setMessage("Inserisci un nome per questo album.")
                .setView(f)
                .setPositiveButton("Salva", (d, w) -> {
                    String n = et.getText().toString().trim();
                    if (n.isEmpty()) return;
                    Media.createAlbum(a, n);
                    if (cb != null) cb.got(n);
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    void confirm(String t, String msg, String ok, Runnable r) {
        new AlertDialog.Builder(this).setTitle(t).setMessage(msg)
                .setPositiveButton(ok, (d, w) -> r.run())
                .setNegativeButton("Annulla", null).show();
    }

    void removeCurrent() {
        Media.dirty = true;
        Pagina p = pager.cur();
        p.animate().alpha(0).scaleX(0.8f).scaleY(0.8f).setDuration(220).withEndAction(() -> {
            p.setAlpha(1); p.setScaleX(1); p.setScaleY(1);
            pager.removeCurrent();
            if (list.isEmpty()) { finishNow(); return; }
            film.setItems(list, pager.index);
            updateTitle();
            updateVideoBar();
        }).start();
    }

    void duplicate() {
        Media.Item it = cur();
        Thumbs.async(() -> {
            boolean ok = false;
            try {
                ContentValues cv = new ContentValues();
                String name = it.name.contains(".") ? it.name.substring(0, it.name.lastIndexOf('.')) + "_copia" + it.name.substring(it.name.lastIndexOf('.')) : it.name + "_copia";
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, it.mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, it.video ? "Movies/Galleria" : "Pictures/Galleria");
                cv.put(MediaStore.MediaColumns.DATE_TAKEN, it.date);
                cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri coll = it.video ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri out = getContentResolver().insert(coll, cv);
                if (out != null) {
                    try (InputStream in = getContentResolver().openInputStream(it.uri);
                         OutputStream os = getContentResolver().openOutputStream(out)) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(out, done, null, null);
                    ok = true;
                }
            } catch (Exception ignored) { }
            final boolean fok = ok;
            h.post(() -> {
                Media.dirty = true;
                Toast.makeText(this, fok ? "Duplicato" : "Impossibile duplicare", Toast.LENGTH_SHORT).show();
            });
        });
    }

    void edit() {
        Media.Item it = cur();
        if (it.video) { Toast.makeText(this, "La modifica è disponibile per le foto", Toast.LENGTH_SHORT).show(); return; }
        Intent i = new Intent(this, EditorActivity.class);
        i.setData(it.uri);
        i.putExtra("name", it.name);
        startActivityForResult(i, REQ_EDIT);
    }

    // ---------- Informazioni ----------

    void showInfo() {
        Media.Item it = cur();
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 20);
        box.setPadding(p, Ui.dp(this, 12), p, p);
        sv.addView(box);
        box.addView(Ui.text(this, Ui.cap(new SimpleDateFormat("EEEE d MMMM yyyy • HH:mm", Media.IT).format(it.date)), 16, Ui.TEXT, true));
        box.addView(Ui.text(this, it.name, 14, Ui.TEXT2, false));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.round(Ui.BG2, Ui.dp(this, 12)));
        int cp = Ui.dp(this, 14);
        card.setPadding(cp, cp, cp, cp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, 14);
        box.addView(card, lp);
        TextView cam = Ui.text(this, it.video ? "Video" : "Foto", 15, Ui.TEXT, true);
        card.addView(cam);
        String mp = it.w > 0 ? String.format(Media.IT, "%.0f MP • %d × %d", it.w * (double) it.h / 1e6, it.w, it.h) : "";
        TextView det = Ui.text(this, mp + (mp.isEmpty() ? "" : " • ") + String.format(Media.IT, "%.1f MB", it.size / 1048576.0)
                + (it.video ? " • " + Ui.dur(it.duration) : ""), 14, Ui.TEXT2, false);
        card.addView(det);
        TextView ex = Ui.text(this, "", 14, Ui.TEXT2, false);
        card.addView(ex);
        TextView folder = Ui.text(this, "Album: " + (it.bucket.isEmpty() ? "—" : it.bucket) + "\n" + it.path, 13, Ui.TEXT2, false);
        folder.setPadding(0, Ui.dp(this, 10), 0, 0);
        box.addView(folder);
        TextView map = Ui.pill(this, "Apri in Mappe");
        map.setTextColor(Ui.BLUE);
        map.setVisibility(View.GONE);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-2, -2);
        mlp.topMargin = Ui.dp(this, 14);
        box.addView(map, mlp);

        AlertDialog dlg = new AlertDialog.Builder(this).setView(sv).setPositiveButton("Fine", null).create();
        dlg.show();

        if (!it.video) {
            Thumbs.async(() -> {
                String cameraName = "", exif = "";
                float[] ll = null;
                try {
                    Uri u = it.uri;
                    if (checkSelfPermission(Manifest.permission.ACCESS_MEDIA_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        try { u = MediaStore.setRequireOriginal(it.uri); } catch (Exception ignored) { }
                    }
                    try (InputStream in = getContentResolver().openInputStream(u)) {
                        ExifInterface e = new ExifInterface(in);
                        String make = e.getAttribute(ExifInterface.TAG_MAKE), model = e.getAttribute(ExifInterface.TAG_MODEL);
                        if (model != null) cameraName = (make != null && !model.toLowerCase().startsWith(make.toLowerCase()) ? make + " " : "") + model;
                        ArrayList<String> parts = new ArrayList<>();
                        String iso = e.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS);
                        if (iso != null) parts.add("ISO " + iso);
                        double fl = e.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0);
                        if (fl > 0) parts.add(String.format(Media.IT, "%.1f mm", fl));
                        double fn = e.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0);
                        if (fn > 0) parts.add(String.format(Media.IT, "ƒ%.1f", fn));
                        double et = e.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0);
                        if (et > 0) parts.add(et >= 1 ? String.format(Media.IT, "%.1f s", et) : "1/" + Math.round(1 / et) + " s");
                        exif = String.join(" • ", parts);
                        float[] tmp = new float[2];
                        if (e.getLatLong(tmp)) ll = tmp;
                    }
                } catch (Exception ignored) { }
                final String fc = cameraName, fe = exif;
                final float[] fll = ll;
                h.post(() -> {
                    if (!fc.isEmpty()) cam.setText(fc);
                    ex.setText(fe);
                    if (fll != null) {
                        map.setText(String.format(Media.IT, "📍 %.5f, %.5f  •  Apri in Mappe", fll[0], fll[1]));
                        map.setVisibility(View.VISIBLE);
                        map.setOnClickListener(v -> {
                            try {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + fll[0] + "," + fll[1] + "?q=" + fll[0] + "," + fll[1])));
                            } catch (Exception ignored) { }
                        });
                    }
                });
            });
        }
    }

    // ---------- Risultati ----------

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK) return;
        done(req);
    }

    @Override
    public void done(int req) {
        Media.dirty = true;
        switch (req) {
            case REQ_TRASH:
            case REQ_DEL:
            case REQ_RESTORE:
                if (req == REQ_RESTORE) Toast.makeText(this, "Recuperato", Toast.LENGTH_SHORT).show();
                removeCurrent();
                break;
            case REQ_FAV:
                cur().fav = !cur().fav;
                updateTitle();
                break;
            case REQ_EDIT:
                Toast.makeText(this, "Salvata come nuova foto in \"Galleria\"", Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        if (pager != null) pager.releaseAll();
        Pagina.videoCb = null;
    }
}
