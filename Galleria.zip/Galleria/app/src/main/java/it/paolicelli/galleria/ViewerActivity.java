package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Visore a tutto schermo stile Foto di iPhone

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ViewerActivity extends Activity implements Media.Done {

    static final int REQ_TRASH = 1, REQ_FAV = 2, REQ_RESTORE = 3, REQ_DEL = 4, REQ_EDIT = 5;
    public static final int MODE_NORMAL = 0, MODE_TRASH = 1, MODE_HIDDEN = 2;

    ArrayList<Media.Item> list;
    int index, mode;
    String album;
    FrameLayout root;
    ZoomImageView img;
    VideoView video;
    ImageView play, heart;
    LinearLayout top, bottom;
    TextView title, sub;
    boolean barsOn = true, sliding = false;
    final Handler h = new Handler(Looper.getMainLooper());
    int loadToken = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        list = new ArrayList<>(Media.current);
        if (list.isEmpty()) { finish(); return; }
        index = Math.max(0, Math.min(getIntent().getIntExtra("index", 0), list.size() - 1));
        mode = getIntent().getIntExtra("mode", MODE_NORMAL);
        album = getIntent().getStringExtra("album");

        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        img = new ZoomImageView(this);
        root.addView(img, new FrameLayout.LayoutParams(-1, -1));

        video = new VideoView(this);
        video.setVisibility(View.GONE);
        root.addView(video, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

        play = new ImageView(this);
        play.setImageDrawable(new Icon("play", 0xFFFFFFFF));
        int pp = Ui.dp(this, 20);
        play.setPadding(pp + Ui.dp(this, 4), pp, pp, pp);
        play.setBackground(Ui.round(0x88000000, Ui.dp(this, 40)));
        int ps = Ui.dp(this, 80);
        root.addView(play, new FrameLayout.LayoutParams(ps, ps, Gravity.CENTER));
        play.setOnClickListener(v -> playVideo());

        // barra in alto
        top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        int m = Ui.dp(this, 12);
        top.setPadding(m, Ui.dp(this, 8), m, Ui.dp(this, 8));
        ImageView back = Ui.circleIcon(this, "back", Ui.TEXT);
        back.setOnClickListener(v -> close());
        top.addView(back);
        LinearLayout tt = new LinearLayout(this);
        tt.setOrientation(LinearLayout.VERTICAL);
        tt.setGravity(Gravity.CENTER);
        title = Ui.text(this, "", 16, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        sub = Ui.text(this, "", 12, Ui.TEXT2, false);
        sub.setGravity(Gravity.CENTER);
        tt.addView(title);
        tt.addView(sub);
        tt.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(tt);
        ImageView more = Ui.circleIcon(this, "more", Ui.TEXT);
        more.setOnClickListener(this::moreMenu);
        top.addView(more);
        root.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // barra in basso
        bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(m, Ui.dp(this, 8), m, Ui.dp(this, 14));
        if (mode == MODE_TRASH) {
            TextView del = Ui.pill(this, "Elimina");
            del.setTextColor(Ui.RED);
            del.setOnClickListener(v -> confirm("Elimina definitivamente", "Questo elemento verrà eliminato per sempre.", "Elimina",
                    () -> Media.deleteForever(this, one(), REQ_DEL)));
            TextView rec = Ui.pill(this, "Recupera");
            rec.setTextColor(Ui.BLUE);
            rec.setOnClickListener(v -> Media.restore(this, one(), REQ_RESTORE));
            bottom.addView(del);
            bottom.addView(Ui.space(this));
            bottom.addView(rec);
        } else {
            ImageView share = Ui.circleIcon(this, "share", Ui.TEXT);
            share.setOnClickListener(v -> Media.share(this, one()));
            heart = Ui.circleIcon(this, "heart", Ui.TEXT);
            heart.setOnClickListener(v -> Media.setFavorite(this, one(), !cur().fav, REQ_FAV));
            ImageView info = Ui.circleIcon(this, "info", Ui.TEXT);
            info.setOnClickListener(v -> showInfo());
            ImageView edit = Ui.circleIcon(this, "edit", Ui.TEXT);
            edit.setOnClickListener(v -> edit());
            ImageView trash = Ui.circleIcon(this, "trash", Ui.TEXT);
            trash.setOnClickListener(v -> Media.trash(this, one(), REQ_TRASH));
            View[] vs = {share, heart, info, edit, trash};
            for (int i = 0; i < vs.length; i++) {
                if (i > 0) bottom.addView(Ui.space(this));
                bottom.addView(vs[i]);
            }
        }
        root.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        img.setListener(new ZoomImageView.L() {
            @Override public void onTap() { if (sliding) stopSlide(); else setBars(!barsOn); }
            @Override public void onNext() { if (index < list.size() - 1) show(index + 1, 1); else bounce(); }
            @Override public void onPrev() { if (index > 0) show(index - 1, -1); else bounce(); }
            @Override public void onClose() { close(); }
            @Override public void onDrag(float f) {
                top.setAlpha(1 - f); bottom.setAlpha(1 - f);
                root.setBackgroundColor(blend(barsOn ? Ui.BG : 0xFF000000, f));
            }
            @Override public void onDragEnd() {
                top.setAlpha(1); bottom.setAlpha(1);
                root.setBackgroundColor(barsOn ? Ui.BG : 0xFF000000);
            }
        });

        setContentView(root);
        Ui.bars(this, Ui.BG, Ui.dark);
        show(index, 0);
        if (getIntent().getBooleanExtra("slide", false)) h.postDelayed(this::startSlide, 400);
    }

    int blend(int c, float f) {
        int a = (int) (255 * (1 - f * 0.85f));
        return (a << 24) | (c & 0xFFFFFF);
    }

    Media.Item cur() { return list.get(index); }

    List<Media.Item> one() { return Collections.singletonList(cur()); }

    void bounce() { img.animate().translationX(0).setDuration(200).start(); }

    void show(int i, int dir) {
        stopVideo();
        index = i;
        Media.Item it = cur();
        final int token = ++loadToken;
        if (dir != 0) {
            float w = root.getWidth();
            img.animate().cancel();
            img.setTranslationX(dir * w * 0.35f);
            img.setAlpha(0.4f);
            img.animate().translationX(0).alpha(1).setDuration(200).start();
        }
        img.setTranslationY(0); img.setScaleX(1); img.setScaleY(1);
        Bitmap ph = Thumbs.cached(it, 512);
        if (ph == null) ph = Thumbs.cached(it, 256);
        if (ph != null) img.setBitmap(ph); else img.setImageDrawable(null);
        play.setVisibility(it.video && mode != MODE_TRASH ? View.VISIBLE : View.GONE);
        updateTitle();
        final int maxSide = Math.min(3072, Math.max(root.getResources().getDisplayMetrics().widthPixels,
                root.getResources().getDisplayMetrics().heightPixels) * 2);
        Thumbs.async(() -> {
            Drawable anim = null;
            Bitmap full = null;
            if (it.video) {
                full = Thumbs.thumbNow(this, it, 1024);
            } else if ("image/gif".equals(it.mime) || "image/webp".equals(it.mime)) {
                try {
                    anim = ImageDecoder.decodeDrawable(ImageDecoder.createSource(getContentResolver(), it.uri));
                } catch (Exception ignored) { }
            }
            if (!it.video && anim == null) full = Thumbs.full(this, it.uri, maxSide);
            final Bitmap fb = full;
            final Drawable fa = anim;
            h.post(() -> {
                if (token != loadToken || isFinishing()) return;
                if (fa != null) {
                    img.setDrawableFit(fa);
                    if (fa instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) fa).start();
                } else if (fb != null) img.setBitmap(fb);
            });
        });
        // precarica le miniature vicine
        for (int k = -2; k <= 2; k++) {
            int j = i + k;
            if (k != 0 && j >= 0 && j < list.size()) {
                final Media.Item n = list.get(j);
                Thumbs.async(() -> Thumbs.thumbNow(this, n, 512));
            }
        }
    }

    void updateTitle() {
        Media.Item it = cur();
        String t;
        if (DateUtils.isToday(it.date)) t = "Oggi";
        else if (DateUtils.isToday(it.date + DateUtils.DAY_IN_MILLIS)) t = "Ieri";
        else if (System.currentTimeMillis() - it.date < 6 * DateUtils.DAY_IN_MILLIS) t = Ui.cap(new SimpleDateFormat("EEEE", Media.IT).format(it.date));
        else t = new SimpleDateFormat("d MMMM yyyy", Media.IT).format(it.date);
        title.setText(t);
        sub.setText(new SimpleDateFormat("HH:mm", Media.IT).format(it.date) + "   " + (index + 1) + " di " + list.size());
        if (heart != null) {
            heart.setImageDrawable(new Icon(it.fav ? "heartfill" : "heart", it.fav ? Ui.BLUE : Ui.TEXT));
        }
    }

    void setBars(boolean on) {
        barsOn = on;
        top.animate().alpha(on ? 1 : 0).setDuration(180).start();
        bottom.animate().alpha(on ? 1 : 0).setDuration(180).start();
        top.setVisibility(View.VISIBLE);
        bottom.setVisibility(View.VISIBLE);
        h.postDelayed(() -> {
            if (!barsOn) { top.setVisibility(View.GONE); bottom.setVisibility(View.GONE); }
        }, 200);
        root.setBackgroundColor(on ? Ui.BG : 0xFF000000);
        View d = getWindow().getDecorView();
        if (on) {
            Ui.bars(this, Ui.BG, Ui.dark);
        } else {
            getWindow().setStatusBarColor(0xFF000000);
            getWindow().setNavigationBarColor(0xFF000000);
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    void close() {
        stopSlide();
        stopVideo();
        finish();
        overridePendingTransition(0, android.R.anim.fade_out);
    }

    @Override public void onBackPressed() { close(); }

    // ---------- Video ----------

    void playVideo() {
        Media.Item it = cur();
        if (!it.video) return;
        play.setVisibility(View.GONE);
        video.setVisibility(View.VISIBLE);
        MediaController mc = new MediaController(this);
        mc.setAnchorView(video);
        video.setMediaController(mc);
        video.setVideoURI(it.uri);
        video.setOnPreparedListener(mp -> { video.start(); mc.show(2500); });
        video.setOnCompletionListener(mp -> { stopVideo(); play.setVisibility(View.VISIBLE); });
        video.setOnErrorListener((mp, w, e) -> { Toast.makeText(this, "Impossibile riprodurre il video", Toast.LENGTH_SHORT).show(); stopVideo(); return true; });
    }

    void stopVideo() {
        if (video != null && video.getVisibility() == View.VISIBLE) {
            try { video.stopPlayback(); } catch (Exception ignored) { }
            video.setVisibility(View.GONE);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (video != null && video.isPlaying()) video.pause();
    }

    // ---------- Presentazione ----------

    final Runnable slideStep = new Runnable() {
        @Override public void run() {
            if (!sliding) return;
            int n = index + 1 >= list.size() ? 0 : index + 1;
            img.animate().alpha(0).setDuration(350).withEndAction(() -> {
                show(n, 0);
                img.setAlpha(0f);
                img.animate().alpha(1).setDuration(450).start();
            }).start();
            h.postDelayed(this, 3500);
        }
    };

    void startSlide() {
        sliding = true;
        setBars(false);
        h.postDelayed(slideStep, 3000);
        Toast.makeText(this, "Presentazione: tocca per fermare", Toast.LENGTH_SHORT).show();
    }

    void stopSlide() {
        if (!sliding) return;
        sliding = false;
        h.removeCallbacks(slideStep);
        setBars(true);
    }

    // ---------- Menu ----------

    void moreMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu mn = pm.getMenu();
        if (mode != MODE_TRASH) {
            mn.add(0, 1, 0, "Presentazione");
            mn.add(0, 2, 0, "Aggiungi ad album");
            if (album != null) mn.add(0, 3, 0, "Rimuovi dall'album");
            mn.add(0, 4, 0, mode == MODE_HIDDEN ? "Mostra" : "Nascondi");
            mn.add(0, 5, 0, "Duplica");
            if (!cur().video) mn.add(0, 6, 0, "Usa come sfondo");
            mn.add(0, 7, 0, "Apri con…");
        }
        mn.add(0, 8, 0, "Informazioni");
        pm.setOnMenuItemClickListener(mi -> {
            switch (mi.getItemId()) {
                case 1: startSlide(); break;
                case 2: pickAlbum(this, one(), null); break;
                case 3:
                    Media.removeFromAlbum(this, album, one());
                    Media.dirty = true;
                    removeCurrent();
                    break;
                case 4:
                    Media.setHidden(this, one(), mode != MODE_HIDDEN);
                    Toast.makeText(this, mode == MODE_HIDDEN ? "Mostrato nella Libreria" : "Spostato in Nascosti", Toast.LENGTH_SHORT).show();
                    removeCurrent();
                    break;
                case 5: duplicate(); break;
                case 6: {
                    Intent i = new Intent(Intent.ACTION_ATTACH_DATA);
                    i.setDataAndType(cur().uri, cur().mime.isEmpty() ? "image/*" : cur().mime);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(i, "Usa come")); } catch (Exception ignored) { }
                    break;
                }
                case 7: {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(cur().uri, cur().mime.isEmpty() ? "*/*" : cur().mime);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(i, "Apri con")); } catch (Exception ignored) { }
                    break;
                }
                case 8: showInfo(); break;
            }
            return true;
        });
        pm.show();
    }

    /** Scegli o crea un album dell'app e aggiungi gli elementi */
    public static void pickAlbum(Activity a, List<Media.Item> items, Runnable after) {
        ArrayList<String> names = Media.albumNames(a);
        names.add("+ Nuovo album…");
        new AlertDialog.Builder(a)
                .setTitle("Aggiungi ad album")
                .setItems(names.toArray(new String[0]), (d, w) -> {
                    if (w == names.size() - 1) {
                        newAlbum(a, n -> {
                            Media.addToAlbum(a, n, items);
                            Toast.makeText(a, "Aggiunto a \"" + n + "\"", Toast.LENGTH_SHORT).show();
                            if (after != null) after.run();
                        });
                    } else {
                        Media.addToAlbum(a, names.get(w), items);
                        Toast.makeText(a, "Aggiunto a \"" + names.get(w) + "\"", Toast.LENGTH_SHORT).show();
                        if (after != null) after.run();
                    }
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    public interface Named { void got(String name); }

    public static void newAlbum(Activity a, Named cb) {
        EditText et = new EditText(a);
        et.setHint("Titolo");
        et.setSingleLine(true);
        FrameLayout f = new FrameLayout(a);
        int p = Ui.dp(a, 20);
        f.setPadding(p, Ui.dp(a, 8), p, 0);
        f.addView(et);
        new AlertDialog.Builder(a)
                .setTitle("Nuovo album")
                .setMessage("Inserisci un nome per questo album.")
                .setView(f)
                .setPositiveButton("Salva", (d, w) -> {
                    String n = et.getText().toString().trim();
                    if (n.isEmpty()) return;
                    Media.createAlbum(a, n);
                    if (cb != null) cb.got(n);
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    void confirm(String t, String msg, String ok, Runnable r) {
        new AlertDialog.Builder(this).setTitle(t).setMessage(msg)
                .setPositiveButton(ok, (d, w) -> r.run())
                .setNegativeButton("Annulla", null).show();
    }

    void removeCurrent() {
        list.remove(index);
        Media.dirty = true;
        if (list.isEmpty()) { close(); return; }
        show(Math.min(index, list.size() - 1), 0);
    }

    void duplicate() {
        Media.Item it = cur();
        Thumbs.async(() -> {
            boolean ok = false;
            try {
                ContentValues cv = new ContentValues();
                String name = it.name.contains(".") ? it.name.substring(0, it.name.lastIndexOf('.')) + "_copia" + it.name.substring(it.name.lastIndexOf('.')) : it.name + "_copia";
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, it.mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, it.video ? "Movies/Galleria" : "Pictures/Galleria");
                cv.put(MediaStore.MediaColumns.DATE_TAKEN, it.date);
                cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri coll = it.video ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri out = getContentResolver().insert(coll, cv);
                if (out != null) {
                    try (InputStream in = getContentResolver().openInputStream(it.uri);
                         OutputStream os = getContentResolver().openOutputStream(out)) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(out, done, null, null);
                    ok = true;
                }
            } catch (Exception ignored) { }
            final boolean fok = ok;
            h.post(() -> {
                Media.dirty = true;
                Toast.makeText(this, fok ? "Duplicato" : "Impossibile duplicare", Toast.LENGTH_SHORT).show();
            });
        });
    }

    void edit() {
        Media.Item it = cur();
        if (it.video) { Toast.makeText(this, "La modifica è disponibile per le foto", Toast.LENGTH_SHORT).show(); return; }
        Intent i = new Intent(this, EditorActivity.class);
        i.setData(it.uri);
        i.putExtra("name", it.name);
        startActivityForResult(i, REQ_EDIT);
    }

    // ---------- Informazioni ----------

    void showInfo() {
        Media.Item it = cur();
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 20);
        box.setPadding(p, Ui.dp(this, 12), p, p);
        sv.addView(box);
        box.addView(Ui.text(this, Ui.cap(new SimpleDateFormat("EEEE d MMMM yyyy • HH:mm", Media.IT).format(it.date)), 16, Ui.TEXT, true));
        box.addView(Ui.text(this, it.name, 14, Ui.TEXT2, false));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.round(Ui.BG2, Ui.dp(this, 12)));
        int cp = Ui.dp(this, 14);
        card.setPadding(cp, cp, cp, cp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, 14);
        box.addView(card, lp);
        TextView cam = Ui.text(this, it.video ? "Video" : "Foto", 15, Ui.TEXT, true);
        card.addView(cam);
        String mp = it.w > 0 ? String.format(Media.IT, "%.0f MP • %d × %d", it.w * (double) it.h / 1e6, it.w, it.h) : "";
        TextView det = Ui.text(this, mp + (mp.isEmpty() ? "" : " • ") + String.format(Media.IT, "%.1f MB", it.size / 1048576.0)
                + (it.video ? " • " + Ui.dur(it.duration) : ""), 14, Ui.TEXT2, false);
        card.addView(det);
        TextView ex = Ui.text(this, "", 14, Ui.TEXT2, false);
        card.addView(ex);
        TextView folder = Ui.text(this, "Album: " + (it.bucket.isEmpty() ? "—" : it.bucket) + "\n" + it.path, 13, Ui.TEXT2, false);
        folder.setPadding(0, Ui.dp(this, 10), 0, 0);
        box.addView(folder);
        TextView map = Ui.pill(this, "Apri in Mappe");
        map.setTextColor(Ui.BLUE);
        map.setVisibility(View.GONE);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-2, -2);
        ml.topMargin = Ui.dp(this, 14);
        box.addView(map, ml);

        AlertDialog dlg = new AlertDialog.Builder(this).setView(sv).setPositiveButton("Fine", null).create();
        dlg.show();

        if (!it.video) {
            Thumbs.async(() -> {
                String cameraName = "", exif = "";
                float[] ll = null;
                try {
                    Uri u = it.uri;
                    if (checkSelfPermission(Manifest.permission.ACCESS_MEDIA_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        try { u = MediaStore.setRequireOriginal(it.uri); } catch (Exception ignored) { }
                    }
                    try (InputStream in = getContentResolver().openInputStream(u)) {
                        ExifInterface e = new ExifInterface(in);
                        String make = e.getAttribute(ExifInterface.TAG_MAKE), model = e.getAttribute(ExifInterface.TAG_MODEL);
                        if (model != null) cameraName = (make != null && !model.toLowerCase().startsWith(make.toLowerCase()) ? make + " " : "") + model;
                        ArrayList<String> parts = new ArrayList<>();
                        String iso = e.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS);
                        if (iso != null) parts.add("ISO " + iso);
                        double fl = e.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0);
                        if (fl > 0) parts.add(String.format(Media.IT, "%.1f mm", fl));
                        double fn = e.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0);
                        if (fn > 0) parts.add(String.format(Media.IT, "ƒ%.1f", fn));
                        double et = e.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0);
                        if (et > 0) parts.add(et >= 1 ? String.format(Media.IT, "%.1f s", et) : "1/" + Math.round(1 / et) + " s");
                        exif = String.join(" • ", parts);
                        float[] tmp = new float[2];
                        if (e.getLatLong(tmp)) ll = tmp;
                    }
                } catch (Exception ignored) { }
                final String fc = cameraName, fe = exif;
                final float[] fll = ll;
                h.post(() -> {
                    if (!fc.isEmpty()) cam.setText(fc);
                    ex.setText(fe);
                    if (fll != null) {
                        map.setText(String.format(Media.IT, "📍 %.5f, %.5f  •  Apri in Mappe", fll[0], fll[1]));
                        map.setVisibility(View.VISIBLE);
                        map.setOnClickListener(v -> {
                            try {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + fll[0] + "," + fll[1] + "?q=" + fll[0] + "," + fll[1])));
                            } catch (Exception ignored) { }
                        });
                    }
                });
            });
        }
    }

    // ---------- Risultati ----------

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK) return;
        done(req);
    }

    @Override
    public void done(int req) {
        Media.dirty = true;
        switch (req) {
            case REQ_TRASH:
            case REQ_DEL:
            case REQ_RESTORE:
                if (req == REQ_RESTORE) Toast.makeText(this, "Recuperato", Toast.LENGTH_SHORT).show();
                removeCurrent();
                break;
            case REQ_FAV:
                cur().fav = !cur().fav;
                updateTitle();
                break;
            case REQ_EDIT:
                Toast.makeText(this, "Salvata come nuova foto in \"Galleria\"", Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
    }
}
