package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Icone disegnate a mano, stile SF Symbols

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

public class Icon extends Drawable {
    private final String t;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int color;

    public Icon(String type, int color) {
        this.t = type;
        this.color = color;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        f.setStyle(Paint.Style.FILL);
    }

    public void setColor(int c) { color = c; invalidateSelf(); }

    private Path heart() {
        Path h = new Path();
        h.moveTo(12, 20.5f);
        h.cubicTo(5, 15.5f, 2.5f, 11.8f, 2.5f, 8.4f);
        h.cubicTo(2.5f, 5.7f, 4.6f, 3.6f, 7.2f, 3.6f);
        h.cubicTo(9.1f, 3.6f, 10.9f, 4.7f, 12, 6.4f);
        h.cubicTo(13.1f, 4.7f, 14.9f, 3.6f, 16.8f, 3.6f);
        h.cubicTo(19.4f, 3.6f, 21.5f, 5.7f, 21.5f, 8.4f);
        h.cubicTo(21.5f, 11.8f, 19, 15.5f, 12, 20.5f);
        h.close();
        return h;
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float s = Math.min(b.width(), b.height()) / 24f;
        c.save();
        c.translate(b.left + (b.width() - 24 * s) / 2f, b.top + (b.height() - 24 * s) / 2f);
        c.scale(s, s);
        p.setColor(color);
        f.setColor(color);
        Path path = new Path();
        switch (t) {
            case "library":
                c.drawRoundRect(new RectF(3, 5, 21, 19), 2.5f, 2.5f, p);
                c.drawCircle(8.5f, 9.5f, 1.6f, p);
                path.moveTo(3.5f, 17); path.lineTo(9, 12.5f); path.lineTo(12.5f, 15.5f); path.lineTo(16, 12); path.lineTo(20.5f, 16.5f);
                c.drawPath(path, p);
                break;
            case "foryou":
                c.drawRoundRect(new RectF(3, 3, 21, 21), 4, 4, p);
                c.save(); c.translate(12, 12.4f); c.scale(0.45f, 0.45f); c.translate(-12, -12);
                c.drawPath(heart(), f); c.restore();
                break;
            case "albums":
                c.drawRoundRect(new RectF(3.5f, 8.5f, 20.5f, 20.5f), 2.5f, 2.5f, p);
                c.drawLine(6, 5.5f, 18, 5.5f, p);
                c.drawLine(8, 2.8f, 16, 2.8f, p);
                break;
            case "search":
                c.drawCircle(10.5f, 10.5f, 6.5f, p);
                c.drawLine(15.5f, 15.5f, 20.5f, 20.5f, p);
                break;
            case "share":
                path.moveTo(8.5f, 9.5f); path.lineTo(6, 9.5f); path.lineTo(6, 21); path.lineTo(18, 21); path.lineTo(18, 9.5f); path.lineTo(15.5f, 9.5f);
                c.drawPath(path, p);
                c.drawLine(12, 2.5f, 12, 14.5f, p);
                Path a = new Path(); a.moveTo(8.5f, 6); a.lineTo(12, 2.5f); a.lineTo(15.5f, 6);
                c.drawPath(a, p);
                break;
            case "heart":
                c.drawPath(heart(), p);
                break;
            case "heartfill":
                c.drawPath(heart(), f);
                break;
            case "info":
                c.drawCircle(12, 12, 9.5f, p);
                c.drawCircle(12, 7.6f, 1.1f, f);
                c.drawLine(12, 11, 12, 17, p);
                break;
            case "trash":
                c.drawLine(4, 6.5f, 20, 6.5f, p);
                path.moveTo(9, 6.5f); path.lineTo(9, 4); path.lineTo(15, 4); path.lineTo(15, 6.5f);
                path.moveTo(6, 6.5f); path.lineTo(7, 20.5f); path.lineTo(17, 20.5f); path.lineTo(18, 6.5f);
                c.drawPath(path, p);
                c.drawLine(10, 10, 10, 17, p);
                c.drawLine(14, 10, 14, 17, p);
                break;
            case "edit":
                c.drawLine(3, 6, 21, 6, p); c.drawLine(3, 12, 21, 12, p); c.drawLine(3, 18, 21, 18, p);
                c.drawCircle(8, 6, 2.3f, f); c.drawCircle(16, 12, 2.3f, f); c.drawCircle(10, 18, 2.3f, f);
                break;
            case "back":
                path.moveTo(15, 4); path.lineTo(7, 12); path.lineTo(15, 20);
                p.setStrokeWidth(2.4f); c.drawPath(path, p); p.setStrokeWidth(1.8f);
                break;
            case "chevron":
                path.moveTo(9, 5); path.lineTo(16, 12); path.lineTo(9, 19);
                c.drawPath(path, p);
                break;
            case "more":
                c.drawCircle(6, 12, 1.7f, f); c.drawCircle(12, 12, 1.7f, f); c.drawCircle(18, 12, 1.7f, f);
                break;
            case "play":
                path.moveTo(7, 4); path.lineTo(20, 12); path.lineTo(7, 20); path.close();
                c.drawPath(path, f);
                break;
            case "plus":
                c.drawLine(12, 4, 12, 20, p); c.drawLine(4, 12, 20, 12, p);
                break;
            case "video":
                c.drawRoundRect(new RectF(2.5f, 6, 15.5f, 18), 2.5f, 2.5f, p);
                path.moveTo(15.5f, 10.5f); path.lineTo(21.5f, 7); path.lineTo(21.5f, 17); path.lineTo(15.5f, 13.5f);
                c.drawPath(path, p);
                break;
            case "screenshot":
                c.drawRoundRect(new RectF(6, 2.5f, 18, 21.5f), 2.5f, 2.5f, p);
                c.drawLine(10, 5.5f, 14, 5.5f, p);
                break;
            case "pano":
                path.moveTo(2.5f, 7); path.quadTo(12, 4, 21.5f, 7); path.lineTo(21.5f, 17); path.quadTo(12, 14, 2.5f, 17); path.close();
                c.drawPath(path, p);
                break;
            case "gif":
                c.drawRoundRect(new RectF(3, 5, 21, 19), 3, 3, p);
                c.drawCircle(9, 12, 2.5f, p); c.drawLine(14, 9, 14, 15, p); c.drawLine(17, 9, 17, 15, p); c.drawLine(17, 9, 19.5f, 9, p);
                break;
            case "hidden":
                path.moveTo(2.5f, 12); path.quadTo(12, 3, 21.5f, 12); path.quadTo(12, 21, 2.5f, 12);
                c.drawPath(path, p);
                c.drawCircle(12, 12, 3, p);
                c.drawLine(4, 20, 20, 4, p);
                break;
            case "duplicate":
                c.drawRoundRect(new RectF(7.5f, 7.5f, 20.5f, 20.5f), 2.5f, 2.5f, p);
                path.moveTo(16.5f, 4.5f); path.lineTo(16.5f, 3.5f); path.lineTo(3.5f, 3.5f); path.lineTo(3.5f, 16.5f); path.lineTo(4.5f, 16.5f);
                c.drawPath(path, p);
                break;
            case "check":
                c.drawCircle(12, 12, 10, f);
                Paint w = new Paint(p); w.setColor(0xFFFFFFFF); w.setStrokeWidth(2.2f);
                path.moveTo(7, 12.5f); path.lineTo(10.5f, 16); path.lineTo(17, 8.5f);
                c.drawPath(path, w);
                break;
            case "ring":
                Paint r = new Paint(p); r.setColor(0xFFFFFFFF); r.setStrokeWidth(1.6f);
                Paint sh = new Paint(f); sh.setColor(0x33000000);
                c.drawCircle(12, 12, 10, sh);
                c.drawCircle(12, 12, 10, r);
                break;
            case "rotate":
                c.drawRoundRect(new RectF(4, 10, 16, 21), 2, 2, p);
                path.moveTo(10, 6); path.quadTo(18, 4, 19.5f, 11);
                c.drawPath(path, p);
                Path ar = new Path(); ar.moveTo(17, 9.5f); ar.lineTo(19.5f, 11.5f); ar.lineTo(21.5f, 8.8f);
                c.drawPath(ar, p);
                break;
            case "flip":
                c.drawLine(12, 2.5f, 12, 21.5f, p);
                path.moveTo(9, 6); path.lineTo(3, 18); path.lineTo(9, 18); path.close();
                path.moveTo(15, 6); path.lineTo(21, 18); path.lineTo(15, 18); path.close();
                c.drawPath(path, p);
                break;
            case "lock":
                c.drawRoundRect(new RectF(5, 10.5f, 19, 21), 2.5f, 2.5f, p);
                path.moveTo(8, 10.5f); path.lineTo(8, 7.5f); path.quadTo(8, 3, 12, 3); path.quadTo(16, 3, 16, 7.5f); path.lineTo(16, 10.5f);
                c.drawPath(path, p);
                break;
            case "person":
                c.drawCircle(12, 8, 4, p);
                path.moveTo(4, 21); path.quadTo(4, 14, 12, 14); path.quadTo(20, 14, 20, 21);
                c.drawPath(path, p);
                break;
            default:
                c.drawCircle(12, 12, 8, p);
        }
        c.restore();
    }

    @Override public void setAlpha(int a) { p.setAlpha(a); f.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter cf) { p.setColorFilter(cf); f.setColorFilter(cf); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
