package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli

import android.app.Activity;
import android.app.PendingIntent;
import android.app.RecoverableSecurityException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class Media {

    public static class Item {
        public long id;
        public Uri uri;
        public boolean video;
        public String name = "", mime = "", bucket = "", path = "";
        public long date, size, duration;
        public int w, h;
        public boolean fav;
        String search;

        int y, mo, d;
        public int year() { return y; }
        public int month() { return mo; }
        public int day() { return d; }
    }

    public static final Locale IT = Locale.ITALIAN;
    /** Tutti gli elementi visibili, dal più vecchio al più recente (come su iPhone) */
    public static ArrayList<Item> all = new ArrayList<>();
    public static ArrayList<Item> hiddenItems = new ArrayList<>();
    /** Lista aperta nel visore */
    public static ArrayList<Item> current = new ArrayList<>();
    public static boolean dirty = true;

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("galleria", Context.MODE_PRIVATE);
    }

    static Set<String> set(Context c, String key) {
        return new HashSet<>(prefs(c).getStringSet(key, new HashSet<>()));
    }

    static void putSet(Context c, String key, Set<String> s) {
        prefs(c).edit().putStringSet(key, s).apply();
    }

    private static String[] projection() {
        ArrayList<String> p = new ArrayList<>();
        p.add(MediaStore.Files.FileColumns._ID);
        p.add(MediaStore.Files.FileColumns.MEDIA_TYPE);
        p.add(MediaStore.MediaColumns.DISPLAY_NAME);
        p.add(MediaStore.MediaColumns.MIME_TYPE);
        p.add(MediaStore.MediaColumns.DATE_TAKEN);
        p.add(MediaStore.MediaColumns.DATE_ADDED);
        p.add(MediaStore.MediaColumns.SIZE);
        p.add(MediaStore.MediaColumns.WIDTH);
        p.add(MediaStore.MediaColumns.HEIGHT);
        p.add(MediaStore.MediaColumns.DURATION);
        p.add(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME);
        p.add(MediaStore.MediaColumns.RELATIVE_PATH);
        if (Build.VERSION.SDK_INT >= 30) p.add(MediaStore.MediaColumns.IS_FAVORITE);
        return p.toArray(new String[0]);
    }

    private static final String SEL = MediaStore.Files.FileColumns.MEDIA_TYPE + "=" + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
            + " OR " + MediaStore.Files.FileColumns.MEDIA_TYPE + "=" + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;

    private static ArrayList<Item> read(Context ctx, Cursor cur) {
        ArrayList<Item> out = new ArrayList<>();
        if (cur == null) return out;
        Set<String> localFav = set(ctx, "fav");
        Calendar cal = Calendar.getInstance();
        try {
            int cId = cur.getColumnIndex(MediaStore.Files.FileColumns._ID);
            int cType = cur.getColumnIndex(MediaStore.Files.FileColumns.MEDIA_TYPE);
            int cName = cur.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
            int cMime = cur.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE);
            int cTaken = cur.getColumnIndex(MediaStore.MediaColumns.DATE_TAKEN);
            int cAdded = cur.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED);
            int cSize = cur.getColumnIndex(MediaStore.MediaColumns.SIZE);
            int cW = cur.getColumnIndex(MediaStore.MediaColumns.WIDTH);
            int cH = cur.getColumnIndex(MediaStore.MediaColumns.HEIGHT);
            int cDur = cur.getColumnIndex(MediaStore.MediaColumns.DURATION);
            int cBucket = cur.getColumnIndex(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME);
            int cPath = cur.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
            int cFav = Build.VERSION.SDK_INT >= 30 ? cur.getColumnIndex(MediaStore.MediaColumns.IS_FAVORITE) : -1;
            while (cur.moveToNext()) {
                Item it = new Item();
                it.id = cur.getLong(cId);
                it.video = cur.getInt(cType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
                it.uri = ContentUris.withAppendedId(it.video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI, it.id);
                it.name = str(cur, cName);
                it.mime = str(cur, cMime);
                long taken = cTaken >= 0 ? cur.getLong(cTaken) : 0;
                long added = cAdded >= 0 ? cur.getLong(cAdded) * 1000L : 0;
                it.date = taken > 0 ? taken : added;
                cal.setTimeInMillis(it.date);
                it.y = cal.get(Calendar.YEAR); it.mo = cal.get(Calendar.MONTH); it.d = cal.get(Calendar.DAY_OF_MONTH);
                it.size = cSize >= 0 ? cur.getLong(cSize) : 0;
                it.w = cW >= 0 ? cur.getInt(cW) : 0;
                it.h = cH >= 0 ? cur.getInt(cH) : 0;
                it.duration = cDur >= 0 ? cur.getLong(cDur) : 0;
                it.bucket = str(cur, cBucket);
                it.path = str(cur, cPath);
                it.fav = cFav >= 0 ? cur.getInt(cFav) == 1 : localFav.contains(String.valueOf(it.id));
                out.add(it);
            }
        } finally {
            cur.close();
        }
        Collections.sort(out, (a, b) -> Long.compare(a.date, b.date));
        return out;
    }

    private static String str(Cursor c, int i) {
        if (i < 0) return "";
        String s = c.getString(i);
        return s == null ? "" : s;
    }

    public static synchronized void load(Context c) {
        ArrayList<Item> list;
        try {
            Cursor cur = c.getContentResolver().query(MediaStore.Files.getContentUri("external"), projection(), SEL, null, null);
            list = read(c, cur);
        } catch (Exception e) {
            list = new ArrayList<>();
        }
        Set<String> hid = set(c, "hidden");
        ArrayList<Item> vis = new ArrayList<>(), hidden = new ArrayList<>();
        for (Item it : list) {
            if (hid.contains(String.valueOf(it.id))) hidden.add(it);
            else vis.add(it);
        }
        all = vis;
        hiddenItems = hidden;
        dirty = false;
    }

    public static ArrayList<Item> loadTrashed(Context c) {
        if (Build.VERSION.SDK_INT < 30) return new ArrayList<>();
        try {
            Bundle q = new Bundle();
            q.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, SEL);
            q.putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY);
            Cursor cur = c.getContentResolver().query(MediaStore.Files.getContentUri("external"), projection(), q, null);
            return read(c, cur);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    // ---------- Raccolte ----------

    public static ArrayList<Item> filter(java.util.function.Predicate<Item> p) {
        ArrayList<Item> o = new ArrayList<>();
        for (Item it : all) if (p.test(it)) o.add(it);
        return o;
    }

    public static ArrayList<Item> favorites() { return filter(i -> i.fav); }
    public static ArrayList<Item> videos() { return filter(i -> i.video); }
    public static ArrayList<Item> screenshots() {
        return filter(i -> !i.video && (i.bucket.toLowerCase(IT).contains("screenshot") || i.name.toLowerCase(IT).startsWith("screenshot")));
    }
    public static ArrayList<Item> screenRecordings() {
        return filter(i -> i.video && (i.bucket.toLowerCase(IT).contains("screen") || i.name.toLowerCase(IT).contains("screen")));
    }
    public static ArrayList<Item> selfies() {
        return filter(i -> i.bucket.toLowerCase(IT).contains("selfie") || i.name.toLowerCase(IT).contains("selfie"));
    }
    public static ArrayList<Item> panoramas() {
        return filter(i -> !i.video && i.w > 0 && i.h > 0 && (Math.max(i.w, i.h) / (float) Math.min(i.w, i.h)) >= 2.4f);
    }
    public static ArrayList<Item> gifs() { return filter(i -> "image/gif".equals(i.mime)); }

    public static ArrayList<Item> duplicates() {
        HashMap<String, ArrayList<Item>> m = new HashMap<>();
        for (Item it : all) {
            if (it.size <= 0) continue;
            String k = it.size + "_" + it.w + "x" + it.h + "_" + it.video;
            ArrayList<Item> l = m.get(k);
            if (l == null) { l = new ArrayList<>(); m.put(k, l); }
            l.add(it);
        }
        ArrayList<Item> o = new ArrayList<>();
        for (ArrayList<Item> l : m.values()) if (l.size() > 1) o.addAll(l);
        Collections.sort(o, (a, b) -> Long.compare(a.date, b.date));
        return o;
    }

    /** Cartelle del dispositivo, ordinate per numero di elementi */
    public static LinkedHashMap<String, ArrayList<Item>> buckets() {
        HashMap<String, ArrayList<Item>> m = new HashMap<>();
        for (Item it : all) {
            String b = it.bucket.isEmpty() ? "Altro" : it.bucket;
            ArrayList<Item> l = m.get(b);
            if (l == null) { l = new ArrayList<>(); m.put(b, l); }
            l.add(it);
        }
        ArrayList<Map.Entry<String, ArrayList<Item>>> e = new ArrayList<>(m.entrySet());
        Collections.sort(e, (a, b) -> b.getValue().size() - a.getValue().size());
        LinkedHashMap<String, ArrayList<Item>> o = new LinkedHashMap<>();
        for (Map.Entry<String, ArrayList<Item>> x : e) o.put(x.getKey(), x.getValue());
        return o;
    }

    // ---------- Album creati nell'app ----------

    public static ArrayList<String> albumNames(Context c) {
        ArrayList<String> l = new ArrayList<>(set(c, "albums"));
        Collections.sort(l, String.CASE_INSENSITIVE_ORDER);
        return l;
    }

    public static void createAlbum(Context c, String name) {
        Set<String> s = set(c, "albums");
        s.add(name);
        putSet(c, "albums", s);
    }

    public static void deleteAlbum(Context c, String name) {
        Set<String> s = set(c, "albums");
        s.remove(name);
        putSet(c, "albums", s);
        prefs(c).edit().remove("album_" + name).apply();
    }

    public static ArrayList<Item> album(Context c, String name) {
        Set<String> ids = set(c, "album_" + name);
        return filter(i -> ids.contains(String.valueOf(i.id)));
    }

    public static void addToAlbum(Context c, String name, List<Item> items) {
        Set<String> ids = set(c, "album_" + name);
        for (Item it : items) ids.add(String.valueOf(it.id));
        putSet(c, "album_" + name, ids);
    }

    public static void removeFromAlbum(Context c, String name, List<Item> items) {
        Set<String> ids = set(c, "album_" + name);
        for (Item it : items) ids.remove(String.valueOf(it.id));
        putSet(c, "album_" + name, ids);
    }

    public static void setHidden(Context c, List<Item> items, boolean hide) {
        Set<String> ids = set(c, "hidden");
        for (Item it : items) {
            if (hide) ids.add(String.valueOf(it.id));
            else ids.remove(String.valueOf(it.id));
        }
        putSet(c, "hidden", ids);
        dirty = true;
    }

    // ---------- Ricerca ----------

    public static String dayLabel(long ms) {
        return new SimpleDateFormat("EEEE d MMMM yyyy", IT).format(ms);
    }

    public static ArrayList<Item> search(String q) {
        q = q.trim().toLowerCase(IT);
        ArrayList<Item> o = new ArrayList<>();
        if (q.isEmpty()) return o;
        String[] toks = q.split("\\s+");
        for (Item it : all) {
            if (it.search == null) {
                it.search = (it.name + " " + it.bucket + " " + it.path + " " + dayLabel(it.date) + " "
                        + new SimpleDateFormat("dd/MM/yyyy", IT).format(it.date)
                        + (it.video ? " video filmato" : " foto immagine")
                        + (it.fav ? " preferiti preferito" : "")
                        + ("image/gif".equals(it.mime) ? " gif animate" : "")).toLowerCase(IT);
            }
            boolean ok = true;
            for (String t : toks) if (!it.search.contains(t)) { ok = false; break; }
            if (ok) o.add(it);
        }
        return o;
    }

    public static String countLabel(List<Item> l) {
        int v = 0;
        for (Item it : l) if (it.video) v++;
        int f = l.size() - v;
        String s = "";
        if (f > 0) s += String.format(IT, "%,d", f).replace(',', '.') + (f == 1 ? " foto" : " foto");
        if (v > 0) s += (s.isEmpty() ? "" : ", ") + String.format(IT, "%,d", v).replace(',', '.') + " video";
        if (s.isEmpty()) s = "Nessun elemento";
        return s;
    }

    // ---------- Azioni ----------

    public static ArrayList<Uri> uris(List<Item> items) {
        ArrayList<Uri> u = new ArrayList<>();
        for (Item it : items) u.add(it.uri);
        return u;
    }

    public static void share(Activity a, List<Item> items) {
        if (items.isEmpty()) return;
        Intent i;
        if (items.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, items.get(0).uri);
            i.setType(items.get(0).mime.isEmpty() ? "image/*" : items.get(0).mime);
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris(items));
            i.setType("*/*");
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        a.startActivity(Intent.createChooser(i, "Condividi"));
    }

    private static void send(Activity a, PendingIntent pi, int req) {
        try {
            a.startIntentSenderForResult(pi.getIntentSender(), req, null, 0, 0, 0);
        } catch (Exception e) {
            Toast.makeText(a, "Operazione non riuscita", Toast.LENGTH_SHORT).show();
        }
    }

    /** Sposta in "Eliminati di recente" (Android 11+) o elimina */
    public static void trash(Activity a, List<Item> items, int req) {
        if (items.isEmpty()) return;
        ContentResolver cr = a.getContentResolver();
        if (Build.VERSION.SDK_INT >= 30) {
            send(a, MediaStore.createTrashRequest(cr, uris(items), true), req);
            return;
        }
        for (Item it : items) {
            try {
                cr.delete(it.uri, null, null);
            } catch (RecoverableSecurityException e) {
                try {
                    a.startIntentSenderForResult(e.getUserAction().getActionIntent().getIntentSender(), req, null, 0, 0, 0);
                } catch (Exception ignored) { }
                return;
            } catch (Exception ignored) { }
        }
        dirty = true;
        if (a instanceof Done) ((Done) a).done(req);
    }

    public static void restore(Activity a, List<Item> items, int req) {
        if (Build.VERSION.SDK_INT >= 30 && !items.isEmpty())
            send(a, MediaStore.createTrashRequest(a.getContentResolver(), uris(items), false), req);
    }

    public static void deleteForever(Activity a, List<Item> items, int req) {
        if (Build.VERSION.SDK_INT >= 30 && !items.isEmpty())
            send(a, MediaStore.createDeleteRequest(a.getContentResolver(), uris(items)), req);
        else trash(a, items, req);
    }

    public static void setFavorite(Activity a, List<Item> items, boolean fav, int req) {
        if (items.isEmpty()) return;
        if (Build.VERSION.SDK_INT >= 30) {
            send(a, MediaStore.createFavoriteRequest(a.getContentResolver(), uris(items), fav), req);
        } else {
            Set<String> s = set(a, "fav");
            for (Item it : items) {
                if (fav) s.add(String.valueOf(it.id)); else s.remove(String.valueOf(it.id));
            }
            putSet(a, "fav", s);
            if (a instanceof Done) ((Done) a).done(req);
        }
    }

    /** Chiamato quando un'azione termina senza bisogno di conferma di sistema */
    public interface Done { void done(int req); }
}
