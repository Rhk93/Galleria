package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Foto: galleria in stile iPhone (Libreria, Per te, Album, Cerca)

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.function.Supplier;

public class MainActivity extends Activity implements Media.Done {

    static final int REQ_PERM = 100, R_TRASH = 11, R_RESTORE = 12, R_DEL = 13, R_FAV = 14;
    static final String[] TABS = {"Libreria", "Per te", "Album", "Cerca"};
    static final String[] TAB_ICONS = {"library", "foryou", "albums", "search"};
    static final String[] MESI = {"Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"};

    FrameLayout root, content;
    FrameLayout tabBar;
    LinearLayout tabRow;
    View tabInd;
    int tab = 0;
    int libMode = 3; // 0 Anni, 1 Mesi, 2 Giorni, 3 Tutte
    final ArrayList<Supplier<View>> stackB = new ArrayList<>();
    final ArrayList<View> stackV = new ArrayList<>();
    GridScreen active;
    final Handler h = new Handler(Looper.getMainLooper());
    boolean loading = false, permAsked = false;
    String query = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        content = new FrameLayout(this);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        tabBar = buildTabBar();
        root.addView(tabBar, tabLp());
        setContentView(root);
        Ui.edge(this, Ui.dark, false);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            if (Ui.readInsets(ins)) {
                tabBar.setLayoutParams(tabLp());
                if (hasPerm() && !Media.all.isEmpty()) refreshAll();
            }
            return ins;
        });
        if (hasPerm()) reload();
        else { permPage(); askPerm(); }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasPerm() && Media.dirty) reload();
    }

    // ---------- Permessi ----------

    boolean hasPerm() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) return true;
            return Build.VERSION.SDK_INT >= 34 && checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    void askPerm() {
        permAsked = true;
        ArrayList<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            p.add(Manifest.permission.READ_MEDIA_IMAGES);
            p.add(Manifest.permission.READ_MEDIA_VIDEO);
            if (Build.VERSION.SDK_INT >= 34) p.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);
        } else p.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        p.add(Manifest.permission.ACCESS_MEDIA_LOCATION);
        requestPermissions(p.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (hasPerm()) reload();
        else permPage();
    }

    void permPage() {
        content.removeAllViews();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        int p = Ui.dp(this, 32);
        l.setPadding(p, p, p, p);
        ImageView ic = Ui.icon(this, "library", Ui.BLUE, 64);
        l.addView(ic);
        TextView t = Ui.text(this, "Accedi alle tue foto", 22, Ui.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 8));
        l.addView(t);
        TextView s = Ui.text(this, "Foto ha bisogno dell'accesso a foto e video per mostrarti la tua libreria.", 15, Ui.TEXT2, false);
        s.setGravity(Gravity.CENTER);
        l.addView(s);
        TextView btn = Ui.pill(this, "Consenti accesso");
        btn.setTextColor(0xFFFFFFFF);
        btn.setBackground(Ui.round(Ui.BLUE, Ui.dp(this, 24)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = Ui.dp(this, 24);
        l.addView(btn, lp);
        btn.setOnClickListener(v -> {
            if (permAsked && !shouldShowRequestPermissionRationale(Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE)) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else askPerm();
        });
        content.addView(l, new FrameLayout.LayoutParams(-1, -1));
    }

    // ---------- Dati ----------

    void reload() {
        if (loading) return;
        loading = true;
        if (Media.all.isEmpty() && content.getChildCount() == 0) {
            TextView t = Ui.text(this, "Caricamento…", 15, Ui.TEXT2, false);
            t.setGravity(Gravity.CENTER);
            content.addView(t, new FrameLayout.LayoutParams(-1, -1));
        }
        new Thread(() -> {
            Media.load(getApplicationContext());
            h.post(() -> { loading = false; refreshAll(); });
        }).start();
    }

    void refreshAll() {
        showTab(tab);
        for (int i = 0; i < stackB.size(); i++) {
            FrameLayout box = (FrameLayout) stackV.get(i);
            View nv = stackB.get(i).get();
            box.removeViewAt(0);
            box.addView(nv, 0, new FrameLayout.LayoutParams(-1, -1));
        }
    }

    @Override
    public void done(int req) {
        Media.dirty = true;
        if (req == R_RESTORE) Toast.makeText(this, "Recuperato", Toast.LENGTH_SHORT).show();
        if (active != null) active.grid.setSelecting(false);
        reload();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res == RESULT_OK) done(req);
    }

    // ---------- Navigazione ----------

    int bottomSpace() { return Ui.bottom + Ui.dp(this, 96); }

    FrameLayout.LayoutParams tabLp() {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, Ui.dp(this, 64), Gravity.BOTTOM);
        lp.setMargins(Ui.dp(this, 18), 0, Ui.dp(this, 18), Ui.bottom + Ui.dp(this, 10));
        return lp;
    }

    /** Barra a capsula fluttuante, stile iOS 26 */
    FrameLayout buildTabBar() {
        FrameLayout bar = new FrameLayout(this);
        bar.setBackground(Ui.round(Ui.dark ? 0xF21C1C1E : 0xF7FFFFFF, Ui.dp(this, 32)));
        bar.setElevation(Ui.dp(this, 10));
        int pad = Ui.dp(this, 5);
        bar.setPadding(pad, pad, pad, pad);
        tabInd = new View(this);
        tabInd.setBackground(Ui.round(Ui.dark ? 0xFF3A3A3C : 0xFFEDEDF2, Ui.dp(this, 27)));
        bar.addView(tabInd, new FrameLayout.LayoutParams(0, -1));
        tabRow = new LinearLayout(this);
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setGravity(Gravity.CENTER);
            ImageView iv = Ui.icon(this, TAB_ICONS[i], Ui.TEXT2, 24);
            t.addView(iv);
            TextView l = Ui.text(this, TABS[i], 11, Ui.TEXT2, true);
            l.setSingleLine(true);
            l.setIncludeFontPadding(true);
            l.setGravity(Gravity.CENTER);
            t.addView(l, new LinearLayout.LayoutParams(-2, -2));
            t.setOnClickListener(v -> {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                while (!stackV.isEmpty()) popPage(false);
                if (tab == k && k == 0) libMode = 3;
                showTab(k);
            });
            Ui.press(t);
            tabRow.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
        }
        bar.addView(tabRow, new FrameLayout.LayoutParams(-1, -1));
        bar.addOnLayoutChangeListener((v, l, tp, r, bt, ol, ot, or, ob) -> placeInd(false));
        return bar;
    }

    void placeInd(boolean anim) {
        int w = tabRow.getWidth() / TABS.length;
        if (w <= 0) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) tabInd.getLayoutParams();
        if (lp.width != w) { lp.width = w; tabInd.setLayoutParams(lp); }
        float x = tab * w;
        if (anim) tabInd.animate().translationX(x).setDuration(320).setInterpolator(Ui.EASE).start();
        else tabInd.setTranslationX(x);
    }

    void colorTabs() {
        for (int i = 0; i < tabRow.getChildCount(); i++) {
            LinearLayout t = (LinearLayout) tabRow.getChildAt(i);
            int c = i == tab ? Ui.BLUE : Ui.TEXT;
            ((Icon) ((ImageView) t.getChildAt(0)).getDrawable()).setColor(c);
            ((TextView) t.getChildAt(1)).setTextColor(c);
        }
        placeInd(true);
    }

    void showTabBar(boolean show) {
        tabBar.animate().translationY(show ? 0 : tabBar.getHeight() + Ui.bottom + Ui.dp(this, 20))
                .alpha(show ? 1 : 0).setDuration(260).setInterpolator(Ui.EASE).start();
    }

    void showTab(int t) {
        if (!hasPerm()) { permPage(); return; }
        tab = t;
        active = null;
        showTabBar(true);
        content.removeAllViews();
        View v;
        if (t == 0) v = library();
        else if (t == 1) v = forYou();
        else if (t == 2) v = albums();
        else v = search();
        content.addView(v, new FrameLayout.LayoutParams(-1, -1));
        v.setAlpha(0f);
        v.animate().alpha(1f).setDuration(180).start();
        colorTabs();
    }

    View under() { return stackV.isEmpty() ? content : stackV.get(stackV.size() - 1); }

    /** Apre una pagina scorrendo da destra, con effetto profondità come su iPhone */
    void pushPage(Supplier<View> b) {
        View v = b.get();
        View under = under();
        FrameLayout box = new FrameLayout(this);
        box.setBackgroundColor(Ui.BG);
        box.setElevation(Ui.dp(this, 6));
        box.addView(v, new FrameLayout.LayoutParams(-1, -1));
        // bordo sinistro: trascina per tornare indietro
        View edgeStrip = new View(this);
        box.addView(edgeStrip, new FrameLayout.LayoutParams(Ui.dp(this, 22), -1, Gravity.START));
        edgeStrip.setOnTouchListener(new View.OnTouchListener() {
            float x0; android.view.VelocityTracker vt;
            @Override public boolean onTouch(View s, android.view.MotionEvent e) {
                float w = root.getWidth();
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        x0 = e.getRawX(); vt = android.view.VelocityTracker.obtain(); vt.addMovement(e);
                        return true;
                    case android.view.MotionEvent.ACTION_MOVE: {
                        vt.addMovement(e);
                        float dx = Math.max(0, e.getRawX() - x0);
                        box.setTranslationX(dx);
                        under.setTranslationX(-w * 0.3f * (1 - dx / w));
                        return true;
                    }
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL: {
                        vt.addMovement(e);
                        vt.computeCurrentVelocity(1000);
                        float vx = vt.getXVelocity();
                        vt.recycle();
                        float dx = e.getRawX() - x0;
                        if (dx > w / 3f || vx > 900) popPage(true);
                        else {
                            box.animate().translationX(0).setDuration(250).setInterpolator(Ui.EASE).start();
                            under.animate().translationX(-w * 0.3f).setDuration(250).setInterpolator(Ui.EASE).start();
                        }
                        return true;
                    }
                }
                return true;
            }
        });
        stackB.add(b);
        stackV.add(box);
        root.addView(box, root.indexOfChild(tabBar), new FrameLayout.LayoutParams(-1, -1));
        float w = root.getWidth();
        box.setTranslationX(w);
        box.animate().translationX(0).setDuration(420).setInterpolator(Ui.EASE).start();
        under.animate().translationX(-w * 0.3f).alpha(0.9f).setDuration(420).setInterpolator(Ui.EASE).start();
    }

    void popPage(boolean anim) {
        if (stackV.isEmpty()) return;
        View v = stackV.remove(stackV.size() - 1);
        stackB.remove(stackB.size() - 1);
        active = null;
        showTabBar(true);
        View under = under();
        if (anim) {
            v.animate().translationX(root.getWidth()).setDuration(340).setInterpolator(Ui.EASE).withEndAction(() -> root.removeView(v)).start();
            under.animate().translationX(0).alpha(1f).setDuration(340).setInterpolator(Ui.EASE).start();
        } else {
            root.removeView(v);
            under.animate().cancel();
            under.setTranslationX(0);
            under.setAlpha(1f);
        }
    }

    @Override
    public void onBackPressed() {
        if (active != null && active.grid.selecting) { active.grid.setSelecting(false); return; }
        if (!stackV.isEmpty()) { popPage(true); return; }
        if (tab != 0) { showTab(0); return; }
        super.onBackPressed();
    }

    /** Apre il visore; la foto "cresce" dalla miniatura toccata */
    void openViewer(ArrayList<Media.Item> list, int idx, int mode, String album, boolean slide, GrigliaView grid, View src) {
        Media.current = list;
        Intent i = new Intent(this, ViewerActivity.class);
        i.putExtra("index", idx);
        i.putExtra("mode", mode);
        if (album != null) i.putExtra("album", album);
        i.putExtra("slide", slide);
        android.graphics.Rect r = null;
        if (grid != null) r = grid.rectOf(list.get(idx));
        else if (src != null) {
            int[] loc = new int[2];
            src.getLocationOnScreen(loc);
            r = new android.graphics.Rect(loc[0], loc[1], loc[0] + src.getWidth(), loc[1] + src.getHeight());
        }
        if (r != null) i.putExtra("rect", new int[]{r.left, r.top, r.right, r.bottom});
        ViewerActivity.rects = grid == null ? null : new ViewerActivity.Rects() {
            @Override public android.graphics.Rect rect(Media.Item it) { return grid.rectOf(it); }
            @Override public void reveal(Media.Item it) { if (grid.rectOf(it) == null) grid.scrollToItem(it); }
        };
        startActivity(i);
        overridePendingTransition(0, 0);
    }

    // ---------- Schermata griglia (riusata da Libreria, album, ricerca) ----------

    class GridScreen {
        final LinearLayout view = new LinearLayout(MainActivity.this);
        final GrigliaView grid = new GrigliaView(MainActivity.this);
        final FrameLayout area = new FrameLayout(MainActivity.this);
        final LinearLayout header = new LinearLayout(MainActivity.this);
        final LinearLayout selBar = new LinearLayout(MainActivity.this);
        TextView selBtn, titleTv, subTv, countTv, emptyTv;
        final int vmode;
        final String album;
        final boolean isRoot;
        ArrayList<Media.Item> list = new ArrayList<>();

        GridScreen(String title, String back, int vmode, String album, boolean isRoot) {
            this.vmode = vmode;
            this.album = album;
            this.isRoot = isRoot;
            Activity a = MainActivity.this;
            view.setOrientation(LinearLayout.VERTICAL);
            view.setBackgroundColor(Ui.BG);
            view.setClickable(true);

            header.setOrientation(LinearLayout.VERTICAL);
            int p = Ui.dp(a, 16);
            header.setPadding(p, Ui.top + Ui.dp(a, 8), p, Ui.dp(a, 6));
            LinearLayout r1 = new LinearLayout(a);
            r1.setGravity(Gravity.CENTER_VERTICAL);
            r1.setMinimumHeight(Ui.dp(a, 40));
            if (back != null) {
                LinearLayout bk = new LinearLayout(a);
                bk.setGravity(Gravity.CENTER_VERTICAL);
                bk.addView(Ui.icon(a, "back", Ui.BLUE, 22));
                bk.addView(Ui.text(a, back, 17, Ui.BLUE, false));
                bk.setOnClickListener(v -> popPage(true));
                r1.addView(bk);
            }
            r1.addView(Ui.space(a));
            selBtn = Ui.pill(a, "Seleziona");
            selBtn.setOnClickListener(v -> grid.setSelecting(!grid.selecting));
            r1.addView(selBtn);
            header.addView(r1);
            titleTv = Ui.text(a, title, 30, Ui.TEXT, true);
            header.addView(titleTv);
            subTv = Ui.text(a, "", 14, Ui.TEXT2, false);
            header.addView(subTv);
            view.addView(header);

            area.addView(grid, new FrameLayout.LayoutParams(-1, -1));
            grid.setBottomPadding(bottomSpace());
            emptyTv = Ui.text(a, "Nessuna foto o video", 17, Ui.TEXT2, true);
            emptyTv.setGravity(Gravity.CENTER);
            emptyTv.setVisibility(View.GONE);
            area.addView(emptyTv, new FrameLayout.LayoutParams(-1, -1));
            view.addView(area, new LinearLayout.LayoutParams(-1, 0, 1f));

            buildSelBar();
            view.addView(selBar);

            grid.setCb(new GrigliaView.Cb() {
                @Override public void open(ArrayList<Media.Item> l, int index) { openViewer(l, index, GridScreen.this.vmode, GridScreen.this.album, false, grid, null); }
                @Override public void selChanged(int count) { updateSel(); }
            });
        }

        void buildSelBar() {
            Activity a = MainActivity.this;
            selBar.setVisibility(View.GONE);
            selBar.setOrientation(LinearLayout.VERTICAL);
            selBar.setBackgroundColor(Ui.dark ? 0xFF121214 : 0xFFF9F9F9);
            selBar.addView(Ui.sep(a));
            LinearLayout r = new LinearLayout(a);
            r.setGravity(Gravity.CENTER_VERTICAL);
            int p = Ui.dp(a, 16);
            r.setPadding(p, Ui.dp(a, 10), p, Ui.bottom + Ui.dp(a, 12));
            countTv = Ui.text(a, "Seleziona elementi", 15, Ui.TEXT, true);
            countTv.setGravity(Gravity.CENTER);
            if (vmode == ViewerActivity.MODE_TRASH) {
                TextView del = Ui.text(a, "Elimina", 17, Ui.RED, false);
                del.setOnClickListener(v -> {
                    ArrayList<Media.Item> s = grid.selectedItems();
                    if (s.isEmpty()) s = new ArrayList<>(list);
                    final ArrayList<Media.Item> fs = s;
                    new AlertDialog.Builder(a).setMessage("Questi elementi verranno eliminati per sempre.")
                            .setPositiveButton("Elimina " + fs.size(), (d, w) -> Media.deleteForever(a, fs, R_DEL))
                            .setNegativeButton("Annulla", null).show();
                });
                TextView rec = Ui.text(a, "Recupera", 17, Ui.BLUE, false);
                rec.setOnClickListener(v -> {
                    ArrayList<Media.Item> s = grid.selectedItems();
                    if (s.isEmpty()) s = new ArrayList<>(list);
                    Media.restore(a, s, R_RESTORE);
                });
                r.addView(del);
                r.addView(countTv, new LinearLayout.LayoutParams(0, -2, 1f));
                r.addView(rec);
            } else {
                ImageView share = Ui.icon(a, "share", Ui.BLUE, 26);
                share.setOnClickListener(v -> Media.share(a, grid.selectedItems()));
                ImageView more = Ui.icon(a, "more", Ui.BLUE, 26);
                more.setOnClickListener(this::selMenu);
                ImageView trash = Ui.icon(a, "trash", Ui.BLUE, 26);
                trash.setOnClickListener(v -> {
                    ArrayList<Media.Item> s = grid.selectedItems();
                    if (!s.isEmpty()) Media.trash(a, s, R_TRASH);
                });
                r.addView(share);
                r.addView(countTv, new LinearLayout.LayoutParams(0, -2, 1f));
                r.addView(more);
                View gap = new View(a);
                r.addView(gap, new LinearLayout.LayoutParams(Ui.dp(a, 22), 1));
                r.addView(trash);
            }
            selBar.addView(r);
        }

        void selMenu(View anchor) {
            ArrayList<Media.Item> s = grid.selectedItems();
            if (s.isEmpty()) return;
            PopupMenu pm = new PopupMenu(MainActivity.this, anchor);
            Menu m = pm.getMenu();
            boolean allFav = true;
            for (Media.Item it : s) if (!it.fav) { allFav = false; break; }
            final boolean fav = !allFav;
            m.add(0, 1, 0, "Aggiungi ad album");
            m.add(0, 2, 0, fav ? "Aggiungi ai preferiti" : "Rimuovi dai preferiti");
            m.add(0, 3, 0, vmode == ViewerActivity.MODE_HIDDEN ? "Mostra" : "Nascondi");
            if (album != null) m.add(0, 4, 0, "Rimuovi dall'album");
            pm.setOnMenuItemClickListener(mi -> {
                switch (mi.getItemId()) {
                    case 1:
                        ViewerActivity.pickAlbum(MainActivity.this, s, () -> grid.setSelecting(false));
                        break;
                    case 2:
                        Media.setFavorite(MainActivity.this, s, fav, R_FAV);
                        break;
                    case 3:
                        Media.setHidden(MainActivity.this, s, vmode != ViewerActivity.MODE_HIDDEN);
                        done(0);
                        break;
                    case 4:
                        Media.removeFromAlbum(MainActivity.this, album, s);
                        done(0);
                        break;
                }
                return true;
            });
            pm.show();
        }

        void updateSel() {
            active = this;
            boolean s = grid.selecting;
            selBar.setVisibility(s || vmode == ViewerActivity.MODE_TRASH ? View.VISIBLE : View.GONE);
            selBtn.setText(s ? "Annulla" : "Seleziona");
            int n = grid.selected.size();
            if (vmode == ViewerActivity.MODE_TRASH && !s) countTv.setText(list.size() + " elementi");
            else countTv.setText(n == 0 ? "Seleziona elementi" : (n == 1 ? "1 elemento selezionato" : n + " elementi selezionati"));
            showTabBar(!s);
        }

        void setList(ArrayList<Media.Item> l, int mode) {
            list = l;
            grid.setItems(l, mode);
            subTv.setText(Media.countLabel(l));
            emptyTv.setVisibility(l.isEmpty() ? View.VISIBLE : View.GONE);
            grid.scrollToEnd();
            if (vmode == ViewerActivity.MODE_TRASH) {
                selBar.setVisibility(View.VISIBLE);
                countTv.setText(l.size() + " elementi");
                subTv.setText("Gli elementi vengono eliminati definitivamente dopo 30 giorni.");
            }
        }
    }

    View albumPage(String title, String back, Supplier<ArrayList<Media.Item>> src, int vmode, String album) {
        GridScreen gs = new GridScreen(title, back, vmode, album, false);
        gs.setList(src.get(), GrigliaView.TUTTE);
        return gs.view;
    }

    // ---------- Libreria ----------

    View library() {
        GridScreen gs = new GridScreen("Libreria", null, ViewerActivity.MODE_NORMAL, null, true);
        ArrayList<Media.Item> all = Media.all;
        if (!all.isEmpty()) {
            String from = new SimpleDateFormat("MMM yyyy", Media.IT).format(all.get(0).date);
            String to = new SimpleDateFormat("MMM yyyy", Media.IT).format(all.get(all.size() - 1).date);
            gs.titleTv.setText("Libreria");
            gs.subTv.setText(Media.countLabel(all) + (from.equals(to) ? "" : "  •  " + from + " – " + to));
        }
        ListView cards = new ListView(this);
        cards.setDivider(null);
        cards.setSelector(new android.graphics.drawable.ColorDrawable(0));
        cards.setClipToPadding(false);
        cards.setPadding(0, 0, 0, bottomSpace() + Ui.dp(this, 50));
        cards.setVisibility(View.GONE);
        gs.area.addView(cards, new FrameLayout.LayoutParams(-1, -1));
        gs.grid.setBottomPadding(bottomSpace() + Ui.dp(this, 50));

        // controllo segmentato Anni / Mesi / Giorni / Tutte
        FrameLayout segWrap = new FrameLayout(this);
        int sp = Ui.dp(this, 3), segW = Ui.dp(this, 74);
        segWrap.setPadding(sp, sp, sp, sp);
        segWrap.setBackground(Ui.round(Ui.dark ? 0xF22C2C2E : 0xF2E5E5EA, Ui.dp(this, 22)));
        segWrap.setElevation(Ui.dp(this, 6));
        View segInd = new View(this);
        segInd.setBackground(Ui.round(Ui.dark ? 0xFF636366 : 0xFFFFFFFF, Ui.dp(this, 19)));
        segWrap.addView(segInd, new FrameLayout.LayoutParams(segW, -1));
        LinearLayout seg = new LinearLayout(this);
        segWrap.addView(seg, new FrameLayout.LayoutParams(-2, -1));
        String[] lbl = {"Anni", "Mesi", "Giorni", "Tutte"};
        FrameLayout.LayoutParams segLp = new FrameLayout.LayoutParams(-2, Ui.dp(this, 42), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        segLp.bottomMargin = Ui.bottom + Ui.dp(this, 86);
        gs.area.addView(segWrap, segLp);

        Runnable[] apply = new Runnable[1];
        for (int i = 0; i < lbl.length; i++) {
            final int k = i;
            TextView t = Ui.text(this, lbl[i], 14, Ui.TEXT, true);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> {
                if (libMode == k) return;
                v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                libMode = k;
                apply[0].run();
            });
            seg.addView(t, new LinearLayout.LayoutParams(segW, -1));
        }
        segInd.setTranslationX(libMode * segW);
        apply[0] = () -> {
            segInd.animate().translationX(libMode * segW).setDuration(300).setInterpolator(Ui.EASE).start();
            View shown = libMode >= 2 ? gs.grid : cards;
            shown.setAlpha(0f);
            shown.setScaleX(0.97f); shown.setScaleY(0.97f);
            shown.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(Ui.EASE).start();
            gs.grid.setSelecting(false);
            if (libMode >= 2) {
                cards.setVisibility(View.GONE);
                gs.grid.setVisibility(View.VISIBLE);
                gs.selBtn.setVisibility(View.VISIBLE);
                gs.setList(all, libMode == 2 ? GrigliaView.GIORNI : GrigliaView.TUTTE);
            } else {
                gs.grid.setVisibility(View.GONE);
                gs.emptyTv.setVisibility(View.GONE);
                gs.selBtn.setVisibility(View.GONE);
                cards.setVisibility(View.VISIBLE);
                cards.setAdapter(new CardAdapter(libMode == 0 ? yearCards(all, cards, apply[0]) : monthCards(all, gs)));
                cards.post(() -> cards.setSelection(Math.max(0, cards.getCount() - 1)));
            }
        };
        apply[0].run();
        return gs.view;
    }

    static class Card {
        String title, sub;
        Media.Item cover;
        Runnable click;
        Card(String t, String s, Media.Item c, Runnable r) { title = t; sub = s; cover = c; click = r; }
    }

    static Media.Item pickCover(ArrayList<Media.Item> l) {
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).fav && !l.get(i).video) return l.get(i);
        Media.Item best = l.get(l.size() / 2);
        for (int k = l.size() / 2; k < l.size(); k++) if (!l.get(k).video) return l.get(k);
        return best;
    }

    ArrayList<Card> yearCards(ArrayList<Media.Item> all, ListView cards, Runnable apply) {
        LinkedHashMap<Integer, ArrayList<Media.Item>> m = new LinkedHashMap<>();
        for (Media.Item it : all) {
            ArrayList<Media.Item> l = m.get(it.year());
            if (l == null) { l = new ArrayList<>(); m.put(it.year(), l); }
            l.add(it);
        }
        ArrayList<Card> o = new ArrayList<>();
        for (Map.Entry<Integer, ArrayList<Media.Item>> e : m.entrySet()) {
            final int y = e.getKey();
            o.add(new Card(String.valueOf(y), Media.countLabel(e.getValue()), pickCover(e.getValue()), () -> {
                libMode = 1;
                apply.run();
                // scorri al primo mese di quell'anno
                cards.post(() -> {
                    BaseAdapter ad = (BaseAdapter) cards.getAdapter();
                    for (int i = 0; i < ad.getCount(); i++) {
                        Card c = (Card) ad.getItem(i);
                        if (c.title.endsWith(String.valueOf(y))) { cards.setSelection(i); break; }
                    }
                });
            }));
        }
        return o;
    }

    ArrayList<Card> monthCards(ArrayList<Media.Item> all, GridScreen gs) {
        LinkedHashMap<Integer, ArrayList<Media.Item>> m = new LinkedHashMap<>();
        for (Media.Item it : all) {
            int k = it.year() * 12 + it.month();
            ArrayList<Media.Item> l = m.get(k);
            if (l == null) { l = new ArrayList<>(); m.put(k, l); }
            l.add(it);
        }
        ArrayList<Card> o = new ArrayList<>();
        for (Map.Entry<Integer, ArrayList<Media.Item>> e : m.entrySet()) {
            int k = e.getKey();
            final Media.Item first = e.getValue().get(0);
            o.add(new Card(MESI[k % 12] + " " + (k / 12), Media.countLabel(e.getValue()), pickCover(e.getValue()), () -> {
                // apri la vista Tutte sul primo elemento del mese
                LinearLayout seg = null;
                libMode = 3;
                showTab(0);
                if (content.getChildCount() > 0 && active == null) {
                    View v = content.getChildAt(0);
                    GrigliaView g = findGrid(v);
                    if (g != null) g.postDelayed(() -> g.scrollToItem(first), 120);
                }
            }));
        }
        return o;
    }

    GrigliaView findGrid(View v) {
        if (v instanceof GrigliaView) return (GrigliaView) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                GrigliaView r = findGrid(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    class CardAdapter extends BaseAdapter {
        final ArrayList<Card> cards;
        CardAdapter(ArrayList<Card> c) { cards = c; }
        @Override public int getCount() { return cards.size(); }
        @Override public Object getItem(int p) { return cards.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int pos, View cv, ViewGroup parent) {
            Card c = cards.get(pos);
            FrameLayout f;
            if (cv instanceof FrameLayout) f = (FrameLayout) cv;
            else {
                FrameLayout outer = new FrameLayout(MainActivity.this);
                int m = Ui.dp(MainActivity.this, 12);
                outer.setPadding(m, m / 2, m, m / 2);
                FrameLayout box = new FrameLayout(MainActivity.this);
                box.setBackground(Ui.round(Ui.BG2, Ui.dp(MainActivity.this, 16)));
                box.setClipToOutline(true);
                ImageView iv = new ImageView(MainActivity.this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                box.addView(iv, new FrameLayout.LayoutParams(-1, -1));
                View shade = new View(MainActivity.this);
                shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x88000000, 0x00000000, 0x00000000}));
                box.addView(shade, new FrameLayout.LayoutParams(-1, -1));
                LinearLayout txt = new LinearLayout(MainActivity.this);
                txt.setOrientation(LinearLayout.VERTICAL);
                int p = Ui.dp(MainActivity.this, 16);
                txt.setPadding(p, p, p, p);
                txt.addView(Ui.text(MainActivity.this, "", 26, 0xFFFFFFFF, true));
                txt.addView(Ui.text(MainActivity.this, "", 14, 0xEEFFFFFF, false));
                box.addView(txt, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
                outer.addView(box, new FrameLayout.LayoutParams(-1, Ui.dp(MainActivity.this, 230)));
                outer.setLayoutParams(new AbsListView.LayoutParams(-1, -2));
                Ui.press(outer);
                f = outer;
            }
            FrameLayout box = (FrameLayout) f.getChildAt(0);
            ImageView iv = (ImageView) box.getChildAt(0);
            LinearLayout txt = (LinearLayout) box.getChildAt(2);
            ((TextView) txt.getChildAt(0)).setText(c.title);
            ((TextView) txt.getChildAt(1)).setText(c.sub);
            if (c.cover != null) Thumbs.load(MainActivity.this, c.cover, iv, 640);
            f.setOnClickListener(v -> c.click.run());
            return f;
        }
    }

    // ---------- Per te ----------

    static ArrayList<Media.Item> sample(ArrayList<Media.Item> l, int n) {
        ArrayList<Media.Item> img = new ArrayList<>();
        for (Media.Item it : l) if (!it.video) img.add(it);
        if (img.isEmpty()) img = l;
        if (img.size() <= n) return new ArrayList<>(img);
        ArrayList<Media.Item> o = new ArrayList<>();
        for (int i = 0; i < n; i++) o.add(img.get((int) ((long) i * img.size() / n)));
        return o;
    }

    View forYou() {
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, Ui.top + Ui.dp(this, 8), 0, bottomSpace());
        sv.addView(col);
        col.addView(bigTitle("Per te", null));

        ArrayList<Object[]> mem = new ArrayList<>();
        Calendar now = Calendar.getInstance();
        int y = now.get(Calendar.YEAR), mo = now.get(Calendar.MONTH), d = now.get(Calendar.DAY_OF_MONTH);
        ArrayList<Media.Item> otd = Media.filter(i -> i.day() == d && i.month() == mo && i.year() < y);
        if (!otd.isEmpty()) mem.add(new Object[]{"In questo giorno", d + " " + MESI[mo].toLowerCase(Media.IT) + " negli anni passati", otd});
        long monthAgo = System.currentTimeMillis() - 30L * 86400000L;
        ArrayList<Media.Item> recent = Media.filter(i -> i.date > monthAgo);
        if (recent.size() >= 6) mem.add(new Object[]{"Ultimo mese", Media.countLabel(recent), sample(recent, 40)});
        LinkedHashMap<Integer, ArrayList<Media.Item>> years = new LinkedHashMap<>();
        for (Media.Item it : Media.all) {
            ArrayList<Media.Item> l = years.get(it.year());
            if (l == null) { l = new ArrayList<>(); years.put(it.year(), l); }
            l.add(it);
        }
        ArrayList<Integer> ys = new ArrayList<>(years.keySet());
        Collections.reverse(ys);
        int count = 0;
        for (int yy : ys) {
            ArrayList<Media.Item> l = years.get(yy);
            ArrayList<Media.Item> summer = new ArrayList<>();
            ArrayList<Media.Item> favs = new ArrayList<>();
            for (Media.Item it : l) {
                if (it.month() >= 5 && it.month() <= 7) summer.add(it);
                if (it.fav) favs.add(it);
            }
            if (summer.size() >= 10) mem.add(new Object[]{"Estate " + yy, Media.countLabel(summer), sample(summer, 40)});
            if (l.size() >= 10) mem.add(new Object[]{"Il meglio del " + yy, Media.countLabel(l), favs.size() >= 8 ? favs : sample(l, 50)});
            if (++count >= 6) break;
        }

        if (mem.isEmpty()) {
            TextView t = Ui.text(this, "I ricordi compariranno qui quando avrai più foto.", 15, Ui.TEXT2, false);
            t.setPadding(Ui.dp(this, 16), Ui.dp(this, 20), Ui.dp(this, 16), 0);
            col.addView(t);
        } else {
            col.addView(section("Ricordi"));
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout row = new LinearLayout(this);
            row.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 12), 0);
            hs.addView(row);
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.78f);
            for (Object[] o : mem) {
                @SuppressWarnings("unchecked") ArrayList<Media.Item> l = (ArrayList<Media.Item>) o[2];
                FrameLayout card = new FrameLayout(this);
                card.setBackground(Ui.round(Ui.BG2, Ui.dp(this, 18)));
                card.setClipToOutline(true);
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                card.addView(iv, new FrameLayout.LayoutParams(-1, -1));
                Thumbs.load(this, pickCover(l), iv, 720);
                View shade = new View(this);
                shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0xAA000000, 0x00000000, 0x00000000}));
                card.addView(shade, new FrameLayout.LayoutParams(-1, -1));
                LinearLayout tx = new LinearLayout(this);
                tx.setOrientation(LinearLayout.VERTICAL);
                tx.setGravity(Gravity.CENTER_HORIZONTAL);
                int p = Ui.dp(this, 18);
                tx.setPadding(p, p, p, p);
                TextView t1 = Ui.text(this, (String) o[0], 26, 0xFFFFFFFF, true);
                t1.setGravity(Gravity.CENTER);
                TextView t2 = Ui.text(this, ((String) o[1]).toUpperCase(Media.IT), 11, 0xDDFFFFFF, true);
                t2.setGravity(Gravity.CENTER);
                tx.addView(t1);
                tx.addView(t2);
                card.addView(tx, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
                ImageView pl = Ui.icon(this, "play", 0xFFFFFFFF, 18);
                FrameLayout.LayoutParams pll = new FrameLayout.LayoutParams(Ui.dp(this, 18), Ui.dp(this, 18), Gravity.TOP | Gravity.END);
                pll.setMargins(0, Ui.dp(this, 14), Ui.dp(this, 14), 0);
                card.addView(pl, pll);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, (int) (w * 1.25f));
                lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
                row.addView(card, lp);
                card.setOnClickListener(v -> openViewer(new ArrayList<>(l), 0, ViewerActivity.MODE_NORMAL, null, true, null, null));
                Ui.press(card);
            }
            col.addView(hs);
        }

        // Foto in evidenza
        ArrayList<Media.Item> imgs = Media.filter(i -> !i.video);
        if (!imgs.isEmpty()) {
            col.addView(section("Foto in evidenza"));
            ArrayList<Media.Item> pick = new ArrayList<>(imgs);
            Collections.shuffle(pick, new Random(y * 1000L + now.get(Calendar.DAY_OF_YEAR)));
            final ArrayList<Media.Item> feat = new ArrayList<>(pick.subList(0, Math.min(6, pick.size())));
            int gap = Ui.dp(this, 3);
            int cell = (getResources().getDisplayMetrics().widthPixels - Ui.dp(this, 24) - gap * 2) / 3;
            LinearLayout g = new LinearLayout(this);
            g.setOrientation(LinearLayout.VERTICAL);
            g.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 12), 0);
            for (int r = 0; r * 3 < feat.size(); r++) {
                LinearLayout row = new LinearLayout(this);
                for (int c = 0; c < 3; c++) {
                    final int idx = r * 3 + c;
                    if (idx >= feat.size()) break;
                    ImageView iv = new ImageView(this);
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    iv.setBackground(Ui.round(Ui.BG2, Ui.dp(this, 8)));
                    iv.setClipToOutline(true);
                    Thumbs.load(this, feat.get(idx), iv, 384);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cell, cell);
                    if (c > 0) lp.leftMargin = gap;
                    lp.bottomMargin = gap;
                    row.addView(iv, lp);
                    iv.setOnClickListener(v -> openViewer(feat, idx, ViewerActivity.MODE_NORMAL, null, false, null, v));
                }
                g.addView(row);
            }
            col.addView(g);
        }
        return sv;
    }

    // ---------- Album ----------

    LinearLayout bigTitle(String t, View right) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 16);
        r.setPadding(p, Ui.dp(this, 12), p, Ui.dp(this, 4));
        r.addView(Ui.text(this, t, 32, Ui.TEXT, true));
        r.addView(Ui.space(this));
        if (right != null) r.addView(right);
        return r;
    }

    TextView section(String t) {
        TextView s = Ui.text(this, t, 21, Ui.TEXT, true);
        s.setPadding(Ui.dp(this, 16), Ui.dp(this, 22), Ui.dp(this, 16), Ui.dp(this, 10));
        return s;
    }

    View albumTile(String name, ArrayList<Media.Item> l, Runnable open, Runnable longPress) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        int s = Ui.dp(this, 150);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(Ui.round(Ui.BG2, Ui.dp(this, 10)));
        iv.setClipToOutline(true);
        if (!l.isEmpty()) Thumbs.load(this, l.get(l.size() - 1), iv, 384);
        else {
            iv.setImageDrawable(new Icon("library", Ui.TEXT2));
            int pd = Ui.dp(this, 50);
            iv.setPadding(pd, pd, pd, pd);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        }
        t.addView(iv, new LinearLayout.LayoutParams(s, s));
        TextView n = Ui.text(this, name, 15, Ui.TEXT, false);
        n.setSingleLine(true);
        n.setPadding(0, Ui.dp(this, 6), 0, 0);
        t.addView(n, new LinearLayout.LayoutParams(s, -2));
        t.addView(Ui.text(this, String.format(Media.IT, "%,d", l.size()), 14, Ui.TEXT2, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 8), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> open.run());
        Ui.press(t);
        if (longPress != null) t.setOnLongClickListener(v -> { longPress.run(); return true; });
        return t;
    }

    View listRow(String icon, String name, String count, Runnable open) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 16);
        r.setPadding(p, Ui.dp(this, 12), p, Ui.dp(this, 12));
        r.addView(Ui.icon(this, icon, Ui.BLUE, 24));
        TextView n = Ui.text(this, name, 17, Ui.BLUE, false);
        n.setPadding(Ui.dp(this, 14), 0, 0, 0);
        r.addView(n, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(Ui.text(this, count, 16, Ui.TEXT2, false));
        r.addView(Ui.icon(this, "chevron", Ui.TEXT2, 18));
        r.setOnClickListener(v -> open.run());
        return r;
    }

    void addRow(LinearLayout col, String icon, String name, Supplier<ArrayList<Media.Item>> src, boolean always) {
        ArrayList<Media.Item> l = src.get();
        if (l.isEmpty() && !always) return;
        if (col.getChildCount() > 0) col.addView(Ui.sep(this));
        col.addView(listRow(icon, name, String.format(Media.IT, "%,d", l.size()), () ->
                pushPage(() -> albumPage(name, "Album", src, ViewerActivity.MODE_NORMAL, null))));
    }

    View albums() {
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, Ui.top + Ui.dp(this, 8), 0, bottomSpace());
        sv.addView(col);
        ImageView plus = Ui.icon(this, "plus", Ui.BLUE, 26);
        plus.setOnClickListener(v -> ViewerActivity.newAlbum(this, n -> showTab(2)));
        col.addView(bigTitle("Album", plus));

        col.addView(section("I miei album"));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 12), 0);
        hs.addView(row);
        row.addView(albumTile("Recenti", Media.all, () -> pushPage(() -> albumPage("Recenti", "Album", () -> Media.all, ViewerActivity.MODE_NORMAL, null)), null));
        row.addView(albumTile("Preferiti", Media.favorites(), () -> pushPage(() -> albumPage("Preferiti", "Album", Media::favorites, ViewerActivity.MODE_NORMAL, null)), null));
        for (String name : Media.albumNames(this)) {
            row.addView(albumTile(name, Media.album(this, name),
                    () -> pushPage(() -> albumPage(name, "Album", () -> Media.album(this, name), ViewerActivity.MODE_NORMAL, name)),
                    () -> new AlertDialog.Builder(this).setTitle("Elimina album \"" + name + "\"?")
                            .setMessage("Le foto non verranno eliminate dalla libreria.")
                            .setPositiveButton("Elimina", (d, w) -> { Media.deleteAlbum(this, name); showTab(2); })
                            .setNegativeButton("Annulla", null).show()));
        }
        col.addView(hs);

        LinkedHashMap<String, ArrayList<Media.Item>> buckets = Media.buckets();
        if (!buckets.isEmpty()) {
            col.addView(section("Cartelle del dispositivo"));
            HorizontalScrollView hs2 = new HorizontalScrollView(this);
            hs2.setHorizontalScrollBarEnabled(false);
            LinearLayout row2 = new LinearLayout(this);
            row2.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 12), 0);
            hs2.addView(row2);
            for (Map.Entry<String, ArrayList<Media.Item>> e : buckets.entrySet()) {
                final String bn = e.getKey();
                row2.addView(albumTile(bn, e.getValue(), () -> pushPage(() -> albumPage(bn, "Album",
                        () -> Media.filter(i -> (i.bucket.isEmpty() ? "Altro" : i.bucket).equals(bn)), ViewerActivity.MODE_NORMAL, null)), null));
            }
            col.addView(hs2);
        }

        col.addView(section("Tipi di media"));
        LinearLayout types = new LinearLayout(this);
        types.setOrientation(LinearLayout.VERTICAL);
        addRow(types, "video", "Video", Media::videos, true);
        addRow(types, "person", "Selfie", Media::selfies, false);
        addRow(types, "pano", "Panoramiche", Media::panoramas, false);
        addRow(types, "screenshot", "Screenshot", Media::screenshots, false);
        addRow(types, "video", "Registrazioni schermo", Media::screenRecordings, false);
        addRow(types, "gif", "GIF animate", Media::gifs, false);
        col.addView(types);

        col.addView(section("Altro"));
        LinearLayout util = new LinearLayout(this);
        util.setOrientation(LinearLayout.VERTICAL);
        addRow(util, "duplicate", "Duplicati", Media::duplicates, true);
        util.addView(Ui.sep(this));
        util.addView(listRow("hidden", "Nascosti", "🔒", () -> auth("Album Nascosti", () ->
                pushPage(() -> albumPage("Nascosti", "Album", () -> Media.hiddenItems, ViewerActivity.MODE_HIDDEN, null)))));
        if (Build.VERSION.SDK_INT >= 30) {
            util.addView(Ui.sep(this));
            util.addView(listRow("trash", "Eliminati di recente", "🔒", () -> auth("Eliminati di recente", () ->
                    pushPage(() -> albumPage("Eliminati di recente", "Album", () -> Media.loadTrashed(this), ViewerActivity.MODE_TRASH, null)))));
        }
        col.addView(util);
        return sv;
    }

    /** Sblocco con impronta / volto / PIN, come Face ID su iPhone */
    void auth(String title, Runnable ok) {
        try {
            BiometricPrompt bp = new BiometricPrompt.Builder(this)
                    .setTitle(title)
                    .setSubtitle("Sblocca per vedere questo album")
                    .setDeviceCredentialAllowed(true)
                    .build();
            bp.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { ok.run(); }
                @Override public void onAuthenticationError(int code, CharSequence msg) {
                    if (code == BiometricPrompt.BIOMETRIC_ERROR_HW_NOT_PRESENT || code == BiometricPrompt.BIOMETRIC_ERROR_HW_UNAVAILABLE
                            || code == BiometricPrompt.BIOMETRIC_ERROR_NO_BIOMETRICS || code == BiometricPrompt.BIOMETRIC_ERROR_NO_DEVICE_CREDENTIAL)
                        ok.run();
                }
            });
        } catch (Exception e) {
            ok.run();
        }
    }

    // ---------- Cerca ----------

    View search() {
        GridScreen gs = new GridScreen("Cerca", null, ViewerActivity.MODE_NORMAL, null, true);
        LinearLayout extra = new LinearLayout(this);
        extra.setOrientation(LinearLayout.VERTICAL);
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(Ui.round(Ui.BG2, Ui.dp(this, 12)));
        box.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        box.addView(Ui.icon(this, "search", Ui.TEXT2, 20));
        EditText et = new EditText(this);
        et.setHint("Luoghi, date, album e altro");
        et.setHintTextColor(Ui.TEXT2);
        et.setTextColor(Ui.TEXT);
        et.setBackground(null);
        et.setSingleLine(true);
        et.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        et.setTextSize(17);
        box.addView(et, new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f));
        TextView clear = Ui.text(this, "✕", 16, Ui.TEXT2, true);
        clear.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8));
        clear.setOnClickListener(v -> et.setText(""));
        box.addView(clear);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
        bl.topMargin = Ui.dp(this, 10);
        extra.addView(box, bl);

        // suggerimenti
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 4));
        hs.addView(chips);
        ArrayList<String> sug = new ArrayList<>();
        sug.add("Preferiti");
        sug.add("Video");
        sug.add("Screenshot");
        ArrayList<Integer> years = new ArrayList<>();
        for (int i = Media.all.size() - 1; i >= 0 && years.size() < 6; i--) {
            int y = Media.all.get(i).year();
            if (!years.contains(y)) years.add(y);
        }
        for (int y : years) sug.add(String.valueOf(y));
        int bc = 0;
        for (String b : Media.buckets().keySet()) { if (bc++ >= 6) break; sug.add(b); }
        for (String s : sug) {
            TextView c = Ui.text(this, s, 14, Ui.BLUE, true);
            c.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
            c.setBackground(Ui.round(Ui.BG2, Ui.dp(this, 16)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Ui.dp(this, 8);
            c.setOnClickListener(v -> { et.setText(s); et.setSelection(s.length()); });
            chips.addView(c, lp);
        }
        extra.addView(hs);
        gs.header.addView(extra);
        gs.subTv.setText("Cerca per nome, data (es. \"luglio 2024\", \"sabato\"), album o tipo.");

        Runnable run = () -> {
            ArrayList<Media.Item> r = Media.search(query);
            gs.setList(r, GrigliaView.TUTTE);
            if (query.trim().isEmpty()) {
                gs.subTv.setText("Cerca per nome, data (es. \"luglio 2024\", \"sabato\"), album o tipo.");
                gs.emptyTv.setText("Cerca nella tua libreria");
            } else gs.emptyTv.setText("Nessun risultato per \"" + query + "\"");
            gs.emptyTv.setVisibility(r.isEmpty() ? View.VISIBLE : View.GONE);
        };
        et.setText(query);
        run.run();
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                query = s.toString();
                h.removeCallbacks(run);
                h.postDelayed(run, 250);
            }
        });
        et.setOnEditorActionListener((v, id, e) -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(et.getWindowToken(), 0);
            return true;
        });
        return gs.view;
    }
}
