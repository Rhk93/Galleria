package it.paolicelli.galleria;

// Copyright © Ignazio Paolicelli
// Striscia di miniature per scorrere velocemente tra le foto (come su iPhone)

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.ArrayList;

public class Striscia extends View {

    public interface L {
        void onScrub(int index);
        void onScrubEnd(int index);
    }

    ArrayList<Media.Item> items = new ArrayList<>();
    float pos = 0;
    int last = -1;
    final int itemW, itemH, gap, slop;
    final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    final Paint ph = new Paint();
    final Rect src = new Rect();
    final RectF dst = new RectF();
    VelocityTracker vt;
    ValueAnimator anim;
    float downX, lastX;
    boolean dragging = false;
    L l;

    public Striscia(Context c) {
        super(c);
        itemW = Ui.dp(c, 22);
        itemH = Ui.dp(c, 40);
        gap = Ui.dp(c, 2);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        ph.setColor(Ui.dark ? 0xFF2C2C2E : 0xFFD1D1D6);
    }

    public void setListener(L l) { this.l = l; }

    public void setItems(ArrayList<Media.Item> l, int idx) {
        items = l;
        pos = idx;
        last = idx;
        invalidate();
    }

    /** Il visore è cambiato pagina: allinea la striscia con animazione */
    public void moveTo(int idx) {
        if (dragging) return;
        last = idx;
        animateTo(idx, false);
    }

    float widthOf(int i) {
        float d = Math.abs(i - pos);
        if (d >= 1) return itemW;
        Media.Item it = items.get(i);
        float ar = it.w > 0 && it.h > 0 ? it.w / (float) it.h : 1f;
        float big = Math.max(itemW, Math.min(itemH * 1.8f, itemH * ar));
        return itemW + (big - itemW) * (1 - d);
    }

    @Override
    protected void onDraw(Canvas c) {
        if (items.isEmpty()) return;
        float cx = getWidth() / 2f;
        float top = (getHeight() - itemH) / 2f;
        int f = Math.max(0, Math.min(items.size() - 1, (int) Math.floor(pos)));
        float wf = widthOf(f);
        float left = cx - wf / 2f - (pos - f) * (wf + gap);
        // verso destra
        float x = left;
        for (int i = f; i < items.size() && x < getWidth(); i++) {
            float w = widthOf(i);
            drawItem(c, i, x, top, w);
            x += w + gap;
        }
        // verso sinistra
        x = left;
        for (int i = f - 1; i >= 0 && x > 0; i--) {
            float w = widthOf(i);
            x -= w + gap;
            drawItem(c, i, x, top, w);
        }
    }

    void drawItem(Canvas c, int i, float x, float top, float w) {
        Media.Item it = items.get(i);
        dst.set(x, top, x + w, top + itemH);
        Bitmap b = Thumbs.cached(it, 128);
        if (b == null) b = Thumbs.anyCached(it);
        if (b == null) {
            c.drawRect(dst, ph);
            Thumbs.request(getContext(), it, 128, this::invalidate);
            return;
        }
        // ritaglio centrale
        float ar = w / itemH, bar = b.getWidth() / (float) b.getHeight();
        if (bar > ar) {
            int sw = (int) (b.getHeight() * ar);
            src.set((b.getWidth() - sw) / 2, 0, (b.getWidth() + sw) / 2, b.getHeight());
        } else {
            int sh = (int) (b.getWidth() / ar);
            src.set(0, (b.getHeight() - sh) / 2, b.getWidth(), (b.getHeight() + sh) / 2);
        }
        c.drawBitmap(b, src, dst, p);
    }

    void report(boolean end) {
        int r = Math.round(pos);
        r = Math.max(0, Math.min(items.size() - 1, r));
        if (r != last) { last = r; if (l != null) l.onScrub(r); }
        if (end && l != null) l.onScrubEnd(r);
    }

    void animateTo(float target, boolean notify) {
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(pos, target);
        anim.setDuration(notify ? 420 : 260);
        anim.setInterpolator(Ui.EASE);
        anim.addUpdateListener(a -> {
            pos = (float) a.getAnimatedValue();
            invalidate();
            if (notify) report(false);
        });
        if (notify) anim.addListener(new android.animation.AnimatorListenerAdapter() {
            boolean cancelled = false;
            @Override public void onAnimationCancel(android.animation.Animator x) { cancelled = true; }
            @Override public void onAnimationEnd(android.animation.Animator x) { if (!cancelled) report(true); }
        });
        anim.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (items.isEmpty()) return false;
        if (vt == null) vt = VelocityTracker.obtain();
        vt.addMovement(e);
        float step = itemW + gap;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (anim != null) anim.cancel();
                downX = lastX = e.getX();
                dragging = false;
                getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!dragging && Math.abs(e.getX() - downX) > slop) dragging = true;
                if (dragging) {
                    pos -= (e.getX() - lastX) / step;
                    pos = Math.max(0, Math.min(items.size() - 1, pos));
                    lastX = e.getX();
                    invalidate();
                    report(false);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                vt.computeCurrentVelocity(1000);
                float v = vt.getXVelocity();
                vt.recycle(); vt = null;
                if (!dragging) {
                    // tocco su una miniatura: vai lì
                    float target = pos + (e.getX() - getWidth() / 2f) / step;
                    target = Math.round(Math.max(0, Math.min(items.size() - 1, target)));
                    animateTo(target, true);
                } else {
                    float target = Math.round(Math.max(0, Math.min(items.size() - 1, pos - v * 0.18f / step)));
                    animateTo(target, true);
                }
                dragging = false;
                return true;
        }
        return true;
    }
}
